/**
 * We can use this index file to export all the APIs inside common folder.
 * Common folder will have all APIs that are commonly used for browser and desktop app.
 */
module.exports = {

};
