(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[75],{

/***/ 17871:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ArtemisBlanketState; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1601);
/* harmony import */ var _constants_ArtemisBlanketStateConstants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(17872);




class ArtemisBlanketState extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super();
  }

  render() {
    const artemisBlanketStore = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('ArtemisBlanketStore'),
    blanketIdentifier = artemisBlanketStore.identifier,
    BlanketComponent = _constants_ArtemisBlanketStateConstants__WEBPACK_IMPORTED_MODULE_2__["default"][blanketIdentifier];

    if (BlanketComponent) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(BlanketComponent,
        artemisBlanketStore.state));


    }
  }}

/***/ }),

/***/ 17872:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _collaboration_components_workspace_artemis_WorkspaceJoin__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(17873);
/* harmony import */ var _collaboration_components_workspace_artemis_WorkspaceNotFound__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17874);
/* harmony import */ var _collaboration_components_workspace_artemis_ShareEntityWorkspace__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(17875);
/* harmony import */ var _collaboration_components_workspace_artemis_ErrorState__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(17876);





const ArtemisBlanketStateConstants = {
  'unjoinedWorkspace': _collaboration_components_workspace_artemis_WorkspaceJoin__WEBPACK_IMPORTED_MODULE_0__["default"],
  'workspaceNotFound': _collaboration_components_workspace_artemis_WorkspaceNotFound__WEBPACK_IMPORTED_MODULE_1__["default"],
  'entityShare': _collaboration_components_workspace_artemis_ShareEntityWorkspace__WEBPACK_IMPORTED_MODULE_2__["default"],
  'error': _collaboration_components_workspace_artemis_ErrorState__WEBPACK_IMPORTED_MODULE_3__["default"] };


/* harmony default export */ __webpack_exports__["default"] = (ArtemisBlanketStateConstants);

/***/ }),

/***/ 17873:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return WorkspaceJoin; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1595);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2325);
/* harmony import */ var _services_DashboardService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8869);
/* harmony import */ var _js_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1846);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1601);
/* harmony import */ var _js_modules_model_event__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1600);
/* harmony import */ var _js_services_WorkspaceSwitchService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1844);









class WorkspaceJoin extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      isJoining: false };


    this.handleBrowseWorkspace = this.handleBrowseWorkspace.bind(this);
    this.handleWorkspaceJoin = this.handleWorkspaceJoin.bind(this);
  }

  handleBrowseWorkspace() {
    Object(_services_DashboardService__WEBPACK_IMPORTED_MODULE_3__["openWorkspace"])(this.props.workspaceId);
  }

  handleWorkspaceJoin() {
    if (!this.props.workspaceId) {
      return;
    }

    let joinWorkspaceEvent = Object(_js_modules_model_event__WEBPACK_IMPORTED_MODULE_6__["createEvent"])('join', 'workspace', { model: 'workspace', workspace: { id: this.props.workspaceId } });

    this.setState({
      isJoining: true });


    Object(_js_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_4__["default"])(joinWorkspaceEvent).
    then(() => {
      // This is done because after join it takes time for workspace to be hydrated in local DB
      this.workspaceStoreReaction = Object(mobx__WEBPACK_IMPORTED_MODULE_1__["reaction"])(() => {
        return Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('WorkspaceStore').find(this.props.workspaceId);
      }, (workspace) => {
        if (_.isEmpty(workspace)) {
          this.setState({ isJoining: false });
          return this.workspaceStoreReaction && this.workspaceStoreReaction();
        }

        // Close the tab and set joining as false once workspace is present in DB
        this.setState({
          isJoining: false },
        () => {
          _js_services_WorkspaceSwitchService__WEBPACK_IMPORTED_MODULE_7__["default"].switchWorkspace(workspace.id).then(() => {
            Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('ArtemisBlanketStore').clearState();
            return this.workspaceStoreReaction && this.workspaceStoreReaction();
          });
        });
      }, {
        fireImmediately: true });

    }).
    catch((e) => {
      this.setState({
        isJoining: false });

    });
  }

  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "artemis-workspace-join" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "artemis-workspace-join__background" }), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "artemis-workspace-join__title" }, "加入此工作区"), /*#__PURE__*/



      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "artemis-workspace-join__description" }, "要使用此工作区中的任何项目,请首先加入工作区."), /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
        className: "artemis-workspace-join__join-btn",
        type: "primary",
        onClick: this.handleWorkspaceJoin,
        disabled: this.state.isJoining }, "加入工作区"), /*#__PURE__*/



      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_2__["Button"], {
        className: "artemis-workspace-join__browse-btn",
        type: "text",
        onClick: this.handleBrowseWorkspace }, "浏览工作区")));





  }}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 17874:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return WorkspaceNotFound; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2325);
/* harmony import */ var _services_DashboardService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8869);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1601);





class WorkspaceNotFound extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleViewWorkspaces = this.handleViewWorkspaces.bind(this);
  }

  handleViewWorkspaces() {
    let type = !_.get(Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('CurrentUserStore'), 'organizations.[0]') ? 'personal' : 'team';

    Object(_services_DashboardService__WEBPACK_IMPORTED_MODULE_2__["openWorkspaces"])(type);
  }

  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "artemis-workspace-not-found" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "artemis-workspace-not-found__background" }), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "artemis-workspace-not-found__title" }, "找不到工作区"), /*#__PURE__*/



      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "artemis-workspace-not-found__description" }, "我们找不到此工作区, 请确保它不是私有/个人工作区或者尚未删除."), /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
        className: "artemis-workspace-not-found__view-workspaces-btn",
        type: "primary",
        onClick: this.handleViewWorkspaces }, "查看所有工作区")));





  }}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 17875:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ShareEntityWorkspace; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1595);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2293);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2325);
/* harmony import */ var _js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2845);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1601);
/* harmony import */ var _js_components_base_Icons_designSystemIcons_Icon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2347);
/* harmony import */ var _js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2322);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _js_modules_model_event__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1600);
/* harmony import */ var _js_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1846);
/* harmony import */ var _constants_workspace__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7154);
/* harmony import */ var _js_services_WorkspaceDependencyService__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1797);
var _class, _class2;function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) {var desc = {};Object.keys(descriptor).forEach(function (key) {desc[key] = descriptor[key];});desc.enumerable = !!desc.enumerable;desc.configurable = !!desc.configurable;if ('value' in desc || desc.initializer) {desc.writable = true;}desc = decorators.slice().reverse().reduce(function (desc, decorator) {return decorator(target, property, desc) || desc;}, desc);if (context && desc.initializer !== void 0) {desc.value = desc.initializer ? desc.initializer.call(context) : void 0;desc.initializer = undefined;}if (desc.initializer === void 0) {Object.defineProperty(target, property, desc);desc = null;}return desc;}











let


ShareEntityWorkspace = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = (_class2 = class ShareEntityWorkspace extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      selectedWorkspace: null,
      isJoining: false,
      isSharing: false,
      joiningWorkspaceId: '' };


    this.workspaceStore = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('WorkspaceStore');

    this.handleWorkspaceJoin = this.handleWorkspaceJoin.bind(this);
    this.handleWorkspaceSelect = this.handleWorkspaceSelect.bind(this);
    this.handleShareEntity = this.handleShareEntity.bind(this);
    this.handleViewEntity = this.handleViewEntity.bind(this);
    this.postJoinWorkspace = this.postJoinWorkspace.bind(this);
  }


  postJoinWorkspace(workspaceId) {
    let workspace = _.find(Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('ArtemisBlanketStore').state.workspaces, ['id', workspaceId]);

    // set membership true as it has become true now
    _.set(workspace, 'state.isMember', true);
  }

  handleWorkspaceJoin(workspaceId) {
    if (!workspaceId) {
      return;
    }

    let joinWorkspaceEvent = Object(_js_modules_model_event__WEBPACK_IMPORTED_MODULE_9__["createEvent"])('join', 'workspace', { model: 'workspace', workspace: { id: workspaceId } });

    this.setState({
      isJoining: true,
      joiningWorkspaceId: workspaceId });


    Object(_js_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_10__["default"])(joinWorkspaceEvent).
    then(() => {
      this.setState({
        isJoining: false,
        joiningWorkspaceId: '' },
      () => {
        return this.postJoinWorkspace(workspaceId);
      });
    }).
    catch((e) => {
      this.setState({
        isJoining: false,
        joiningWorkspaceId: '' });

    });
  }

  handleWorkspaceSelect(workspace) {
    this.setState({ selectedWorkspace: _.find(this.props.workspaces, { 'id': workspace }) });
  }

  handleShareEntity() {
    this.setState({ isSharing: true });

    let workspaceId = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('ActiveWorkspaceStore').id,
    addEntity = [{
      entityType: this.props.entityType,
      entityId: this.props.entityId,
      workspaceId: workspaceId }];


    return _js_services_WorkspaceDependencyService__WEBPACK_IMPORTED_MODULE_12__["default"].modifyDependencies(addEntity, null, null, { fromId: _.get(Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('ActiveWorkspaceStore'), 'id') }).
    then(() => {
      return Promise.resolve().
      then(() => {
        return _.isFunction(this.props.postShareHandler) ? this.props.postShareHandler(this.props.entityId, workspaceId) :
        this.props.viewEntityHandler(this.props.entityId, workspaceId);
      }).
      then(() => {
        return this.setState({ isSharing: false });
      }).
      catch((e) => {
        return this.setState({ isSharing: false });
      });
    }).
    catch((e) => {
      return this.setState({ isSharing: false });
    });
  }

  handleViewEntity() {
    return _.isFunction(this.props.viewEntityHandler) && this.props.viewEntityHandler(this.props.entityId, _.get(this.state.selectedWorkspace, 'id'));
  }

  render() {
    const entityType = _constants_workspace__WEBPACK_IMPORTED_MODULE_11__["ENTITY_MAP"][this.props.entityType],
    entityName = this.props.entityName,
    workspaceName = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('ActiveWorkspaceStore').name,

    // This will be false right now. Once client foundation enable this we will have correct logic in place
    isCanonicalURL = this.props.isCanonicalURL;

    if (this.props.workspaces && isCanonicalURL && this.props.workspaces.length === 1) {
      _.isFunction(this.props.viewEntityHandler) && this.props.viewEntityHandler(this.props.entityId, _.get(this.props.workspaces, '[0].id'));
      return null;
    }

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "artemis-workspace-share-entity" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "artemis-workspace-share-entity__background" }),

      !this.props.isCanonicalURL && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "artemis-workspace-share-entity__title" },
      entityType, "不在此工作区中"), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "artemis-workspace-share-entity__description" }, "该", /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", { className: "artemis-workspace-share-entity__description-entity-name" }, entityName, " "),
      entityType, "不存在于", /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", { className: "artemis-workspace-share-entity__description-workspace-name" }, " ", workspaceName), "工作区中."), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_3__["Button"], {
        className: "artemis-workspace-share-entity__share-btn",
        type: "primary",
        onClick: this.handleShareEntity },


      this.state.isSharing ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_7__["default"], null) : `将${entityType}共享到此工作区`)),






      !_.isEmpty(this.props.workspaces) && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "artemis-workspace-share-entity__workspace-action" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "artemis-workspace-share-entity__workspace-action-text" }, "或", /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("br", null), "查看",
      entityType, "在一个", isCanonicalURL ? '' : 'different ', "workspace"), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "artemis-workspace-share-entity__workspace-action-actions" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_4__["Dropdown"], {
        className: "artemis-workspace-share-entity__dropdown",
        onSelect: this.handleWorkspaceSelect }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_4__["DropdownButton"], {
        className: "artemis-workspace-share-entity__dropdown-btn",
        type: "secondary",
        size: "small" }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_3__["Button"], null, _.get(this.state.selectedWorkspace, 'name', '选择工作区'))), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_4__["DropdownMenu"], {
        fluid: true,
        className: "artemis-workspace-share-entity__dropdown-menu" },


      _.map(this.props.workspaces, (workspace) => {
        let isWorkspaceUnjoined = !_.get(workspace, 'state.isMember', false);

        return /*#__PURE__*/(
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_4__["MenuItem"], {
            className: "artemis-workspace-share-entity__workspace-item",
            key: workspace.id,
            refKey: workspace.id,
            disabled: isWorkspaceUnjoined }, /*#__PURE__*/

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
            className: classnames__WEBPACK_IMPORTED_MODULE_8___default()('artemis-workspace-share-entity__workspace-list', { 'unjoined': isWorkspaceUnjoined }) }, /*#__PURE__*/

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: classnames__WEBPACK_IMPORTED_MODULE_8___default()('artemis-workspace-share-entity__workspace', { 'unjoined': isWorkspaceUnjoined }) }, /*#__PURE__*/
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Icons_designSystemIcons_Icon__WEBPACK_IMPORTED_MODULE_6__["default"], {
            icon: "icon-entity-workspaces-stroke" }), /*#__PURE__*/

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "artemis-workspace-share-entity__workspace-name" },
          workspace.name)),



          isWorkspaceUnjoined && (
          this.state.isJoining && workspace.id === this.state.joiningWorkspaceId ? /*#__PURE__*/
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_7__["default"], null) : /*#__PURE__*/
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_3__["Button"], {
            className: "artemis-workspace-share-entity__join-btn",
            type: "text",
            onClick: () => {this.handleWorkspaceJoin(workspace.id);} }, "加入")))));








      }))), /*#__PURE__*/



      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_3__["Button"], {
        className: "artemis-workspace-share-entity__view-btn",
        type: "secondary",
        onClick: this.handleViewEntity }, "查看",

      entityType)))));






  }}, (_applyDecoratedDescriptor(_class2.prototype, "postJoinWorkspace", [mobx__WEBPACK_IMPORTED_MODULE_1__["action"]], Object.getOwnPropertyDescriptor(_class2.prototype, "postJoinWorkspace"), _class2.prototype)), _class2)) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 17876:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ErrorState; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2325);
/* harmony import */ var _js_services_NavigationService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1801);
/* harmony import */ var _navigation_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1808);





/**
 * Handles switching of workspace to default workspace
 */
function handleWorkspaces() {
  return _js_services_NavigationService__WEBPACK_IMPORTED_MODULE_2__["default"].transitionTo(_navigation_constants__WEBPACK_IMPORTED_MODULE_3__["ALL_WORKSPACES_IDENTIFIER"]);
}

/**
 * Generic Error state presentational component
 */
function ErrorState() {
  return /*#__PURE__*/(
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "artemis-workspace-error-state" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "artemis-workspace-error-state__background" }), /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "artemis-workspace-error-state__title" }, "出了些问题"), /*#__PURE__*/


    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "artemis-workspace-error-state__description" }, "Postman遇到错误. 如果此问题仍然存在,请通过help@postman.com与我们联系"), /*#__PURE__*/


    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
      className: "artemis-workspace-error-state__switch-btn",
      type: "primary",
      onClick: handleWorkspaces }, "前往工作区")));





}

/***/ })

}]);