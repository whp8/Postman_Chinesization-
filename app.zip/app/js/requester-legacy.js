(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[11],{

/***/ 9016:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9);
/* harmony import */ var _modules_persistent_storage_BroadcastChannelPolyfill__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(514);
/* harmony import */ var _styles_requester_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8851);
/* harmony import */ var _styles_requester_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_requester_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _init__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9017);
/* harmony import */ var _utils_TelemetryHelpers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8853);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1812);
/* harmony import */ var _components_empty_states_CrashHandler__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2895);
/* harmony import */ var _shared_ThemeContext__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2345);
/* harmony import */ var _shared_init__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8953);
/* harmony import */ var _containers_apps_requester_Requester__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8854);






// Adding the polyfill here so that if any other modules imported after this use persistent storage
// in the top level code, it is able to find BroadcastChannel
window.BroadcastChannel = window.BroadcastChannel || _modules_persistent_storage_BroadcastChannelPolyfill__WEBPACK_IMPORTED_MODULE_3__["default"];











// Reload page if loaded from bfcache.
window.onpageshow = function (event) {
  if (event.persisted) {
    window.location.reload();
  }
};

// Ensure requester init is singleton
let _requesterInitialized = false;

/**
 * Shims requestIdleCallback in case a browser doesn't support it.
 */
window.requestIdleCallback = window.requestIdleCallback ||
function (cb) {
  return setTimeout(function () {
    var start = Date.now();
    cb({
      didTimeout: false,
      timeRemaining: function () {
        return Math.max(0, 50 - (Date.now() - start));
      } });

  }, 1);
};

window.cancelIdleCallback = window.cancelIdleCallback ||
function (id) {
  clearTimeout(id);
};

/**
 * Hides the placeholder loading state
 */
function hideLoadingState() {
  let loader = document.getElementsByClassName('pm-loader')[0];
  loader && loader.classList.add('is-hidden');
}

/**
 * requester-legacy.css is not needed for homepage. So it is preloaded to speedup page paint.
 * But styles in requester-legacy.css necessary for all other pages so when we do soft redirect from home we want to activate this stylesheet
 */
function activateRequesterCSS() {
  let elem = document.getElementById('requester-styles');
  if (elem.getAttribute('rel') === 'preload') {
    elem.setAttribute('rel', 'stylesheet');
    elem.setAttribute('type', 'text/css');
  }
}

const rootEl = document.getElementById('app-root');

/** */
function renderRequesterUI(err) {

  activateRequesterCSS();

  // We hide the loading state just before the point when we are rendering the requester. Earlier,
  // this was happening while initializing ThemeDomDelegator. This was causing an issue where there
  // was a blank white screen rendered after the loader was hidden and before the requester got
  // rendered. This was resulting in a jarring experience while loading the app.
  hideLoadingState();

  if (err) {
    Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["render"])( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_empty_states_CrashHandler__WEBPACK_IMPORTED_MODULE_8__["default"], { showError: true }), rootEl);
    return;
  }

  Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["render"])( /*#__PURE__*/
  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_empty_states_CrashHandler__WEBPACK_IMPORTED_MODULE_8__["default"], null, /*#__PURE__*/
  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_shared_ThemeContext__WEBPACK_IMPORTED_MODULE_9__["Theme"], null, /*#__PURE__*/
  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_2__["ToastProvider"], null, /*#__PURE__*/
  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_apps_requester_Requester__WEBPACK_IMPORTED_MODULE_11__["default"], null)))),



  rootEl,
  () => {
    let loadTime = Object(_utils_TelemetryHelpers__WEBPACK_IMPORTED_MODULE_6__["getWindowLoadTime"])();
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_7__["default"].addEvent('app_performance_metric', 'requester_window_loaded', null, null, { load_time: loadTime });
  });

}

/**
 * Initializes and renders requester content
 */
/* harmony default export */ __webpack_exports__["default"] = (function (cb) {
  if (!_requesterInitialized) {
    _shared_init__WEBPACK_IMPORTED_MODULE_10__["default"].init(() => {
      _init__WEBPACK_IMPORTED_MODULE_5__["default"].init(() => {
        _requesterInitialized = true;
        renderRequesterUI();
        cb && cb();
      });
    });
  }
});

/***/ }),

/***/ 9017:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var async_series__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(523);
/* harmony import */ var async_series__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(async_series__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _boot_bootConfig__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(570);
/* harmony import */ var _boot_bootMessaging__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(781);
/* harmony import */ var _boot_bootWLModels__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(948);
/* harmony import */ var _runtime_repl_boot_RuntimeInterface__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1531);
/* harmony import */ var _billing_PlanFeaturesInterface__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8635);
/* harmony import */ var _boot_bootDBWatcher__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8636);
/* harmony import */ var _boot_bootAppModels__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8637);
/* harmony import */ var _boot_bootSettings__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8641);
/* harmony import */ var _boot_bootTelemetry__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8644);
/* harmony import */ var _boot_bootCrashReporter__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8646);
/* harmony import */ var _boot_bootIndependentServices__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8681);
/* harmony import */ var _boot_bootWindowConfig__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8689);
/* harmony import */ var _boot_bootRequester__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8690);
/* harmony import */ var _boot_booted__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8746);
/* harmony import */ var _boot_bootThemeManager__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8747);
/* harmony import */ var _boot_bootWorkbenchService__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(8755);
/* harmony import */ var _boot_bootConfigurations__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(8756);
/* harmony import */ var _utils_DisableProcessThrottling__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(8764);
/* harmony import */ var postman_collection__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(2389);
/* harmony import */ var postman_collection__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(postman_collection__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _modules_model_event__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(1600);
/* harmony import */ var _boot_initializeNavigationForDomains__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(8767);
/* harmony import */ var _modules_services_PostLoginService__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(1871);
/* harmony import */ var _modules_controllers_CurrentUserController__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(1626);
/* harmony import */ var _utils_UserOfflineNotifier__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(9018);
/* harmony import */ var _boot_bootContextBarRegistry__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(8779);
/* harmony import */ var _boot_bootShared_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(8780);
/* harmony import */ var _runtime_repl_boot_CookiesBootHelper__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(8845);
/* harmony import */ var _boot_bootSharedRuntimeListeners__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(8846);
/* harmony import */ var _utils_ScratchpadUtils__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(1612);
/* harmony import */ var _services_ScratchpadService__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(2160);
/* harmony import */ var _modules_initialize_db_initialize__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(8847);


































const windowConfig = {
  process: 'requester',
  ui: true };


window.pm = window.pm || {};
window.process = {};

/* harmony default export */ __webpack_exports__["default"] = ({
  init: (done) => {
    _.assign(window.pm, { windowConfig });

    const initSequence = [
    _boot_bootShared_js__WEBPACK_IMPORTED_MODULE_26__["default"],
    _boot_initializeNavigationForDomains__WEBPACK_IMPORTED_MODULE_21__["initializeNavigationForDomains"],
    _boot_bootWindowConfig__WEBPACK_IMPORTED_MODULE_12__["bootWindowConfig"],
    _boot_bootIndependentServices__WEBPACK_IMPORTED_MODULE_11__["default"],
    _runtime_repl_boot_RuntimeInterface__WEBPACK_IMPORTED_MODULE_4__["default"],
    _runtime_repl_boot_CookiesBootHelper__WEBPACK_IMPORTED_MODULE_27__["cleanupCookies"],
    _runtime_repl_boot_CookiesBootHelper__WEBPACK_IMPORTED_MODULE_27__["initializeCommunicationForCookies"],
    _boot_bootDBWatcher__WEBPACK_IMPORTED_MODULE_6__["default"],
    _boot_bootThemeManager__WEBPACK_IMPORTED_MODULE_15__["default"],
    _boot_bootWorkbenchService__WEBPACK_IMPORTED_MODULE_16__["default"],
    _boot_bootContextBarRegistry__WEBPACK_IMPORTED_MODULE_25__["default"],
    _boot_bootRequester__WEBPACK_IMPORTED_MODULE_13__["default"],
    _boot_bootSharedRuntimeListeners__WEBPACK_IMPORTED_MODULE_28__["default"],
    _billing_PlanFeaturesInterface__WEBPACK_IMPORTED_MODULE_5__["default"]];


    async_series__WEBPACK_IMPORTED_MODULE_0___default()(initSequence, (err) => {
      Object(_boot_booted__WEBPACK_IMPORTED_MODULE_14__["default"])(err);

      let queryParams = postman_collection__WEBPACK_IMPORTED_MODULE_19___default.a.Url.parse(location.href).query;

      // if access_token is present in the URL
      // do the post-authentication flow
      if (_.find(queryParams, { key: 'access_token' })) {
        console.log('Found access token in URL, logging user in...', queryParams);
        let paramsMap = _.mapValues(_.keyBy(queryParams, 'key'), 'value'),
        userData = {
          email: paramsMap.email,
          id: paramsMap.user_id,
          name: paramsMap.name,
          username: paramsMap.username,
          auth: { access_token: paramsMap.access_token } };

        pm.eventBus.channel('auth-handler-events').
        publish(Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_20__["createEvent"])('authenticated', 'authentication', { userData, hasAccounts: false }));
      }

      if (err) {
        pm.logger.error('Error in requester boot sequence', err);
      }

      // Disabling throttling for this process. This is to prevent electron from
      // throttling actions for this process even if it is running in the background
      Object(_utils_DisableProcessThrottling__WEBPACK_IMPORTED_MODULE_18__["default"])();


      // Clearing the offline seeded workspace in case of browser during init
      // This offline workspace is seed during the init process. We need it in App for scratchpad functionality
      // but do not need it for browser. In future we can have separate seeding based on env.
      return _modules_services_PostLoginService__WEBPACK_IMPORTED_MODULE_22__["default"].deleteOfflineWorkspace().
      catch((e) => {
        pm.logger.warn('Requester~init: Error while deleting default offline workspace', e);
      }).
      then(() => {

        // Setting up a reaction to listen for changes in the sync socket connection status. This
        // is currently used to notify the user when the app is offline (on Artemis) that their
        // changes might not be applied properly
        Object(_utils_UserOfflineNotifier__WEBPACK_IMPORTED_MODULE_24__["setupSocketStatusReaction"])();

        done && done(err);
      });
    });
  } });
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 9018:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setupSocketStatusReaction", function() { return setupSocketStatusReaction; });
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1595);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1601);
/* harmony import */ var _controllers_InfobarBridge__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2210);
/* harmony import */ var _constants_InAppMessageConstants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2209);





const USER_OFFLINE_BANNER_ID = 'userOffline',
USER_OFFLINE_MESSAGE = 'You seem to be offline. Data in this workspace might not be up to date.',

// Debounce interval to listen for changes in sync socket connection status and show the offline
// banner.
SOCKET_DEBOUNCE_INTERVAL = 1000;

/**
 * This function sets up a mobx reaction that listens to changes in the status of the sync socket
 * connection. This is to notify the users that the app is in an offline state and any changes they
 * make during this time might not be reflected properly.
 * We notify the user by showing them a banner telling them that they are offline. Once the socket
 * is connected we dismiss the banner.
 */
function setupSocketStatusReaction() {
  let handleSocketStatusChange = function (isOnline) {

    // Case when the socket is disconnected, we show the banner
    // and make sure the banner is only shown in the private/public workspaces
    // and no other page such as public profile / explore
    if (!isOnline) {
      _controllers_InfobarBridge__WEBPACK_IMPORTED_MODULE_2__["default"].trigger({
        id: USER_OFFLINE_BANNER_ID,
        message: USER_OFFLINE_MESSAGE,
        meta: {
          targets: [
          _constants_InAppMessageConstants__WEBPACK_IMPORTED_MODULE_3__["WORKSPACE_PRIVATE"],
          _constants_InAppMessageConstants__WEBPACK_IMPORTED_MODULE_3__["WORKSPACE_PERSONAL"],
          _constants_InAppMessageConstants__WEBPACK_IMPORTED_MODULE_3__["WORKSPACE_TEAM"],
          _constants_InAppMessageConstants__WEBPACK_IMPORTED_MODULE_3__["WORKSPACE_PUBLIC"]] } });



    }

    // Case when the socket is connected
    else {
      _controllers_InfobarBridge__WEBPACK_IMPORTED_MODULE_2__["default"].dismiss(USER_OFFLINE_BANNER_ID);
    }
  };

  Object(mobx__WEBPACK_IMPORTED_MODULE_0__["reaction"])(
  () => Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('SyncStatusStore').isSocketConnected,
  _.debounce(handleSocketStatusChange, SOCKET_DEBOUNCE_INTERVAL, { leading: false, trailing: true }));

}


/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ })

}]);