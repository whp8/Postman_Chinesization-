(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[42],{

/***/ 9735:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionChangelog; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _js_components_collections_browser_CollectionBrowserActivityFeed__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9736);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1601);
/* harmony import */ var _js_utils_util__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1628);
/* harmony import */ var _js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2856);
/* harmony import */ var _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1812);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2293);
var _class;








/**
 * Collection Changelog
 *
 * @param {Object} props
 */let

CollectionChangelog = Object(mobx_react__WEBPACK_IMPORTED_MODULE_6__["observer"])(_class = class CollectionChangelog extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  componentDidMount() {
    _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_5__["default"].addEventV2({
      category: 'collection',
      action: 'view_changelog',
      label: 'collection_context_bar',
      entityId: _.get(this.props, 'contextData.collectionUid') });

  }

  render() {
    const { id } = this.props.contextData,
    collection = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('CollectionStore').find(id),
    currentUser = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('CurrentUserStore'),
    canRestore = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('PermissionStore').can('restore', 'collection', id),
    isProUser = _js_utils_util__WEBPACK_IMPORTED_MODULE_3__["default"].isProUser(currentUser),
    isSocketConnected = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('SyncStatusStore').isSocketConnected;

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_4__["default"], { identifier: "activityFeed" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_collections_browser_CollectionBrowserActivityFeed__WEBPACK_IMPORTED_MODULE_1__["default"], {
        canAddVersionTag: collection && collection.isEditable && currentUser.isLoggedIn,
        collectionUid: collection.uid,
        enableRestore: isProUser && canRestore,
        key: collection.uid,
        title: this.props.title,
        isOffline: !isSocketConnected,
        isLoggedIn: currentUser.isLoggedIn,
        onClose: this.props.onClose })));



  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 9736:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionBrowserActivityFeed; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _postman_date_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2304);
/* harmony import */ var _postman_date_helper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_postman_date_helper__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _activity_feed_ActivityFeed__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9737);
/* harmony import */ var _modules_services_AuthHandlerService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3770);
/* harmony import */ var _activity_feed_AddVersionTagModal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9745);
/* harmony import */ var _stores_CollectionActivityFeedStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8449);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1812);
/* harmony import */ var _modules_model_event__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1600);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1601);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_9__);












class CollectionBrowserActivityFeed extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      collectionRestoreTarget: null,
      openVersionTagModal: false,
      isRemovingTag: false,
      isRestored: false };


    this.handleLoadNew = this.handleLoadNew.bind(this);
    this.handleLoadMore = this.handleLoadMore.bind(this);
    this.handleSignIn = this.handleSignIn.bind(this);
    this.handleRestore = this.handleRestore.bind(this);
    this.handleRetry = this.handleRetry.bind(this);
    this.handleAddVersionTag = this.handleAddVersionTag.bind(this);
    this.handleRemoveVersionTag = this.handleRemoveVersionTag.bind(this);
    this.handleVersionTagModalClose = this.handleVersionTagModalClose.bind(this);
  }

  UNSAFE_componentWillMount() {
    this.store = new _stores_CollectionActivityFeedStore__WEBPACK_IMPORTED_MODULE_5__["default"]();

    if (!this.props.isOffline) {
      this.initializeFeeds();
    }

    this.subscribeToCollectionRestore();
  }

  componentWillUnmount() {
    this.unsubscribe && typeof this.unsubscribe === 'function' && this.unsubscribe();
  }

  initializeFeeds() {
    let collectionUid = this.props.collectionUid;
    this.store.initialize(collectionUid);
  }

  handleLoadNew() {
    return this.store.loadNew().
    then((isNewFeedLoaded) => {
      return Promise.resolve(isNewFeedLoaded);
    });
  }

  handleLoadMore() {
    this.store.loadMore();
  }

  handleSignIn() {
    _modules_services_AuthHandlerService__WEBPACK_IMPORTED_MODULE_3__["default"].initiateLogin();
  }

  isWorkspaceMember() {
    return Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_8__["getStore"])('ActiveWorkspaceStore').isMember;
  }

  /**
   * Note: If user is not a member of active workspace, action will be blocked by a modal
   * asking user to join the workspace first.
   */
  handleAddVersionTag(revisionId) {
    // If the user is not a part of the workspace, then
    if (!this.isWorkspaceMember()) {
      return pm.mediator.trigger('openUnjoinedWorkspaceModal');
    }

    // Add analytics event to track initial version tag create
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__["default"].addEventV2({
      category: 'collection',
      action: 'initiate_version_tag_create',
      label: 'collection_changelog',
      entityId: this.props.collectionUid });


    this.setState({
      openVersionTagModal: !this.state.openVersionTagModal,
      revisionId: revisionId });

  }

  /**
   * Note: If user is not a member of active workspace, action will be blocked by a modal
   * asking user to join the workspace first.
   */
  handleRemoveVersionTag(revisionId, tagId) {
    if (!this.isWorkspaceMember()) {
      return pm.mediator.trigger('openUnjoinedWorkspaceModal');
    }

    this.setState({ isRemovingTag: !this.state.isRemovingTag });

    let criteria = {
      collectionUid: this.props.collectionUid,
      tagId: tagId,
      revisionId: revisionId };


    // Add analytics event to track version tag delete
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__["default"].addEventV2({
      category: 'collection',
      action: 'version_tag_delete',
      label: 'collection_changelog',
      entityId: this.props.collectionUid });


    this.store.removeVersionTag(criteria).
    then(() => {
      this.setState({ isRemovingTag: !this.state.isRemovingTag });
    }).
    catch(() => {
      this.setState({ isRemovingTag: !this.state.isRemovingTag });
    });
  }

  handleVersionTagModalClose() {
    this.setState({ openVersionTagModal: !this.state.openVersionTagModal });
  }

  handleRestore(maxId, createdAt) {
    let restoreTarget = {
      collectionUid: this.props.collectionUid,
      maxId: maxId };


    this.restoreDate = _postman_date_helper__WEBPACK_IMPORTED_MODULE_1___default.a.getFormattedDateAndTime(createdAt);

    // Add analytics event to show that collection has been restored
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__["default"].addEventV2({
      category: 'collection',
      action: 'restore_collection',
      label: 'collection_changelog',
      entityId: this.props.collectionUid });


    this.setState({ isRestored: false });
    this.setState({ collectionRestoreTarget: restoreTarget }, () => {
      pm.syncManager.restoreCollection(restoreTarget, (error, res) => {

        // Since artemis uses restore collection from Sync Manager New directly, we need to handle the callback response here
        // and set respective restored and collectionRestoreTarget states.
        if (error || res && res.error) {
          // when socket connection is not available
          this.setState({ isRestored: false, collectionRestoreTarget: null });

          pm.toasts.error('我们无法将集合恢复到以前的状态. 请稍后再试.', { noIcon: true, title: '无法恢复集合' });
        } else
        if (res && res.data) {
          this.setState({ isRestored: true, collectionRestoreTarget: null });

          pm.toasts.success(`您的集合已成功恢复到 ${this.restoreDate || '以前的状态'}.`, { noIcon: true, title: '集合已恢复' });
        }
      });
    });
  }

  subscribeToCollectionRestore() {
    this.unsubscribe = pm.eventBus.channel('sync-manager-internal').subscribe((event) => {
      if (!event) {
        return;
      }

      const eventNamespace = Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_7__["getEventNamespace"])(event),
      eventName = Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_7__["getEventName"])(event),
      eventData = Object(_modules_model_event__WEBPACK_IMPORTED_MODULE_7__["getEventData"])(event) || {};

      if (eventName === 'collectionRestored' && eventNamespace === 'command') {
        this.setState({ isRestored: true, collectionRestoreTarget: null });

        if (!eventData.error) {
          pm.toasts.success(`您的集合已成功恢复到 ${this.restoreDate || '以前的状态'}.`, { noIcon: true, title: '集合已恢复' });
        } else
        {
          pm.toasts.error('我们无法将集合恢复到以前的状态. 请稍后再试.', { noIcon: true, title: '无法恢复集合' });
        }
      }
    });
  }

  /**
   * @param {Boolean} - options.initialRetry - retry initializing change-logs
   * @param {Boolean} - options.loadMoreRetry - retry loading more change-logs
   */
  handleRetry(options) {
    if (options.initialRetry) {
      this.initializeFeeds();
    } else
    if (options.loadMoreRetry) {
      this.handleLoadMore();
    }
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_9___default()({ 'collection-browser-activity-feed-lists': true }, this.props.className);
  }

  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: this.getClasses(), onClickCapture: (e) => {console.log('|| clicked', e.target);} }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_activity_feed_ActivityFeed__WEBPACK_IMPORTED_MODULE_2__["default"], {
        activityFeed: this.store,
        title: this.props.title,
        canAddVersionTag: this.props.canAddVersionTag,
        collectionRestoreTarget: this.state.collectionRestoreTarget,
        enableRestore: this.props.enableRestore,
        isLoggedIn: this.props.isLoggedIn,
        isRemovingTag: this.state.isRemovingTag,
        isRestored: this.state.isRestored,
        isVisible: this.props.isVisible,
        isOffline: this.props.isOffline,
        onLoadNew: this.handleLoadNew,
        onLoadMore: this.handleLoadMore,
        onSignIn: this.handleSignIn,
        onRestore: this.handleRestore,
        onRetry: this.handleRetry,
        onAddVersionTag: this.handleAddVersionTag,
        onRemoveVersionTag: this.handleRemoveVersionTag,
        onClose: this.props.onClose }),


      this.state.openVersionTagModal && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_activity_feed_AddVersionTagModal__WEBPACK_IMPORTED_MODULE_4__["default"], {
        activityFeed: this.store,
        revisionId: this.state.revisionId,
        collectionUid: this.props.collectionUid,
        isOffline: this.props.isOffline,
        isOpen: this.state.openVersionTagModal,
        onRequestClose: this.handleVersionTagModalClose })));




  }}

/***/ }),

/***/ 9737:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ActivityFeed; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Activity__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9738);
/* harmony import */ var _postman_date_helper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2304);
/* harmony import */ var _postman_date_helper__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_postman_date_helper__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var pure_render_decorator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2846);
/* harmony import */ var pure_render_decorator__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(pure_render_decorator__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2298);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3174);
/* harmony import */ var _postman_app_monolith_renderer_js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1810);
/* harmony import */ var _appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2862);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2325);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2293);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9);
/* harmony import */ var _version_control_pull_request_components_PullRequestListing__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9739);
/* harmony import */ var _version_control_pull_request_components_PullRequestListing__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_version_control_pull_request_components_PullRequestListing__WEBPACK_IMPORTED_MODULE_12__);
var _class;











let


ActivityFeed = Object(mobx_react__WEBPACK_IMPORTED_MODULE_10__["observer"])(_class = class ActivityFeed extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {

  constructor(props) {
    super(props);
    this.handleScroll = this.handleScroll.bind(this);
    this.handleScrollDebounced = _.debounce(this.handleScroll, 100);
    this.handleSignIn = this.handleSignIn.bind(this);
    this.handleRefreshFeed = this.handleRefreshFeed.bind(this);
    this.handleChangeLogLearn = this.handleChangeLogLearn.bind(this);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.activityFeed &&
    this.props.activityFeed &&
    nextProps.activityFeed.collectionUid &&
    nextProps.activityFeed.collectionUid !== this.props.activityFeed.collectionUid) {
      this.refs.activity_feed && (this.refs.activity_feed.scrollTop = 0);
    }

    if (nextProps.isRestored && nextProps.isRestored !== this.props.isRestored) {
      this.handleRefreshFeed();
    }
  }

  componentDidUpdate(prevProps) {
    // Refetch the changelog once back from offline state if it is not yet fetched
    const activities = _.get(prevProps, 'activityFeed.feeds', []),
    meta = _.get(prevProps, 'activityFeed.meta', {}),
    filteredActivities = _.filter(activities, (activity) => {
      return !(meta.model === 'collection' && _.includes(['subscribe', 'unsubscribe'], activity.action));
    }),
    wasOffline = prevProps.isOffline;

    if (wasOffline && wasOffline !== this.props.isOffline && _.isEmpty(filteredActivities)) {
      this.props.onRetry({ initialRetry: true });
    }
  }

  handleChangeLogLearn() {
    Object(_postman_app_monolith_renderer_js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_6__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_5__["ACTIVITY_FEED_AND_RESTORING_COLLECTION"]);
  }

  getRefreshTextClass() {
    return classnames__WEBPACK_IMPORTED_MODULE_9___default()({
      'changelog-learn-more-header__refresh-container': true,
      'is-loading-new': this.props.activityFeed.isLoadingNew });

  }

  handleSignIn() {
    this.props.onSignIn && this.props.onSignIn();
  }

  handleScroll() {
    let node = this.refs.activity_feed;
    if (node.scrollHeight - (node.scrollTop + node.offsetHeight) <= 5) {
      _.isEmpty(this.props.activityFeed.error) && this.props.onLoadMore && this.props.onLoadMore();
    }
  }

  handleRefreshFeed() {
    this.props.onLoadNew && this.props.onLoadNew().
    then((isNewFeedLoaded) => {
      if (isNewFeedLoaded) {
        this.refs.activity_feed.scrollTop = 0;
      }
    });
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_9___default()({ 'activity-feed-container': true }, this.props.className);
  }

  render() {
    let props = this.props,
    activities = _.get(props, 'activityFeed.feeds', []),
    meta = _.get(props, 'activityFeed.meta', {}),
    error = _.get(props, 'activityFeed.error', {}),
    initialError = error && error.type === 'initial',
    loadMoreError = error && error.type === 'loadMore';

    // Don't show subscribe / Unsubscribe event in collection activity feed
    let filteredActivities = _.filter(activities, (activity) => {
      return !(meta.model === 'collection' && _.includes(['subscribe', 'unsubscribe'], activity.action));
    }),
    groupedActivities = _.isEmpty(filteredActivities) ? [] : _postman_date_helper__WEBPACK_IMPORTED_MODULE_2___default.a.getDateGroups(filteredActivities, 'createdAt', 'MMMM D, YYYY'),
    latestActivity = _.maxBy(filteredActivities, 'id');

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: this.getClasses() }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_7__["ContextBarViewHeader"], { title: '变更日志', onClose: this.props.onClose }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_8__["Button"], {
        type: "tertiary",
        className: this.getRefreshTextClass(),
        onClick: this.handleRefreshFeed,
        disabled: props.activityFeed.isLoading || props.isOffline,
        tooltip: props.isOffline ? '重新在线后即可执行此操作' : '获取更新的源' }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_11__["Icon"], { name: "icon-action-refresh-stroke", className: "changelog-learn-more-header__refresh-icon pm-icon pm-icon-normal" }))),



      props.isOffline && _.isEmpty(error) && _.isEmpty(groupedActivities) && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_version_control_pull_request_components_PullRequestListing__WEBPACK_IMPORTED_MODULE_12__["EmptyState"], {
        illustration: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_11__["IllustrationCheckInternetConnection"], null),
        title: "检查您的连接",
        message: "联网查看变更日志" }), /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "activity-feed",
        ref: "activity_feed",
        onScroll: this.handleScrollDebounced },


      (props.activityFeed.isLoading || initialError) && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Activity__WEBPACK_IMPORTED_MODULE_1__["LoadFeed"], {
        error: error,
        key: "loading",
        isLoading: props.activityFeed.isLoading,
        onRetry: this.props.onRetry }),



      _.map(groupedActivities, (subActivities) => {
        if (_.isEmpty(subActivities)) {
          return false;
        }

        return /*#__PURE__*/(
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
            className: "activity-feed-date-group-wrapper",
            key: subActivities.name }, /*#__PURE__*/

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "activity-feed-date-group" }, " ", subActivities.name, " "),

          _.map(subActivities.items, (activity) => {
            return /*#__PURE__*/(
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Activity__WEBPACK_IMPORTED_MODULE_1__["Activity"], {
                activity: activity,
                canAddVersionTag: this.props.canAddVersionTag,
                enableRestore: !!(this.props.enableRestore && latestActivity && latestActivity.id !== activity.id),
                isRestoring: _.get(this.props, 'collectionRestoreTarget.maxId') === activity.id,
                isRemovingTag: this.props.isRemovingTag,
                isVisible: this.props.isVisible,
                isOffline: this.props.isOffline,
                key: activity.id,
                meta: meta,
                onAddVersionTag: this.props.onAddVersionTag,
                onRemoveVersionTag: this.props.onRemoveVersionTag,
                onRestore: this.props.onRestore }));


          })));



      }),


      !props.activityFeed.isLoading && _.isEmpty(groupedActivities) && !error && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: props.className }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "activity-feed-loading-container " }, "暂无活动"))),






      (props.activityFeed.isLoadingMore || loadMoreError) && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Activity__WEBPACK_IMPORTED_MODULE_1__["LoadFeed"], {
        error: error,
        key: "loading-more",
        isLoading: props.activityFeed.isLoadingMore,
        isOffline: props.isOffline,
        onRetry: this.props.onRetry })));




  }}) || _class;


ActivityFeed.propTypes = {
  activityFeed: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.object.isRequired,
  activityName: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.string,
  className: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.string,
  onLoadMore: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.func.isRequired };
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 9745:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return AddVersionTagModal; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2293);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _postman_app_monolith_renderer_js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1810);
/* harmony import */ var _base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2322);
/* harmony import */ var _base_Buttons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2325);
/* harmony import */ var _base_Modals__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4174);
/* harmony import */ var _base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2845);
/* harmony import */ var _api_dev_components_common_ErrorHandler_ErrorHandler__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7263);
/* harmony import */ var _modules_services_ActivityFeedService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8450);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1812);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3174);
/* harmony import */ var _api_dev_services_APIDevService__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2255);
var _class;













const CONTEXT_LIST = [
{ model: 'collection', type: 'documentation', name: '文档' },
{ model: 'collection', type: 'testsuite', name: '测试套件' },
{ model: 'collection', type: 'integrationtest', name: '集成测试' },
{ model: 'collection', type: 'contracttest', name: '合同测试' }];let



AddVersionTagModal = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class AddVersionTagModal extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      items: null,
      selectedAPI: null,
      selectedAPIVersion: null,
      selectedAPIContext: '',
      isAPIVersionSelectEnable: false,
      isRequiredWarning: true,
      isModalLoading: false,
      isLoading: false,
      isOnlyOneAPI: false,
      modalOpenError: null };


    this.handleClose = this.handleClose.bind(this);
    this.handleAPISelect = this.handleAPISelect.bind(this);
    this.handleAPIVersionSelect = this.handleAPIVersionSelect.bind(this);
    this.handleAPIContextSelect = this.handleAPIContextSelect.bind(this);
    this.handleAddVersionTag = this.handleAddVersionTag.bind(this);
    this.handleActivityFeedTagsLearn = this.handleActivityFeedTagsLearn.bind(this);
  }

  componentDidMount() {
    let criteria = _.assign({}, {
      collectionUid: this.props.collectionUid });

    this.store = this.props.activityFeed;
    this.initialFetch(criteria);
  }

  getCustomStyles() {
    return {
      margin: 'auto',
      height: '384px',
      width: '350px' };

  }

  handleActivityFeedTagsLearn() {
    Object(_postman_app_monolith_renderer_js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_3__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_11__["ACTIVITY_FEED_VERSION_TAGS"]);
  }

  handleClose() {
    this.props.onRequestClose && this.props.onRequestClose();
  }

  initialFetch(criteria) {
    this.setState({
      isModalLoading: true });


    _modules_services_ActivityFeedService__WEBPACK_IMPORTED_MODULE_9__["default"].fetchPossibleAPIVersions(criteria).
    then((entities) => {
      this.setState({
        isModalLoading: false,
        items: entities },
      () => {
        this.state.items.length === 1 &&
        this.setState({
          selectedAPI: _.head(this.state.items),
          isAPIVersionSelectEnable: true,
          isOnlyOneAPI: true });

      });
    }).
    catch((error) => {
      this.setState({
        isModalLoading: false,
        modalOpenError: error });

      pm.logger.warn(error);
    });
  }

  handleAPISelect(id) {
    this.setState({ isAPIVersionSelectEnable: true });
    let item = _.find(this.state.items, ['id', id]);

    !_.isUndefined(item) ?
    this.setState({ selectedAPI: item }) :
    this.setState({ selectedAPI: _.head(this.state.items) });
  }

  handleAPIVersionSelect(id) {
    let item = _.find(this.state.selectedAPI.versions, ['id', id]);

    this.setState({
      selectedAPIVersion: item,

      // if API and API context are selected, enable `添加版本标签` button by setting `isRequiredWarning` state to `false`
      isRequiredWarning: this.state.selectedAPI && this.state.selectedAPIContext ? false : true });

  }

  handleAPIContextSelect(contextType) {
    let context = _.find(CONTEXT_LIST, ['type', contextType]);

    this.setState({
      selectedAPIContext: context,

      // if API and API version are selected, enable `添加版本标签` button by setting `isRequiredWarning` state to `false`
      isRequiredWarning: this.state.selectedAPI && this.state.selectedAPIVersion ? false : true });

  }

  handleAddVersionTag() {
    // Bail out if API or API version or API context is not selected
    if (!this.state.selectedAPI || !this.state.selectedAPIVersion || !this.state.selectedAPIContext) {
      return;
    } else
    {
      this.setState({ isLoading: true });
      let criteria = {
        collectionUid: this.props.collectionUid,
        revisionId: this.props.revisionId,
        apiVersionId: this.state.selectedAPIVersion.id,
        relationType: this.state.selectedAPIContext.type };


      this.store.addVersionTag(criteria).
      then(() => {
        this.setState({ isLoading: false });

        // Add analytics event to track initial version tag create
        _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_10__["default"].addEventV2({
          category: 'collection',
          action: 'successful_version_tag_create',
          label: 'collection_changelog',
          entityId: this.props.collectionUid });


        this.handleClose();
      }).
      catch(() => {
        this.setState({ isLoading: false });
      });
    }
  }

  getModalContentClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'version-tag__modal-content': true,
      'is-modal-loading': this.state.isModalLoading });

  }

  getDropdownHeadLabelClasses(showPlaceholderText) {
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'dropdown-head-label': true,
      'placeholder-text': showPlaceholderText });

  }

  renderModalContent() {
    if (this.state.isModalLoading) {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_4__["default"], null);
    }

    if (this.state.modalOpenError) {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "version-tag-modal-error" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_api_dev_components_common_ErrorHandler_ErrorHandler__WEBPACK_IMPORTED_MODULE_8__["default"], {
        title: "出了些问题",
        description: "向此集合添加版本标签时出现问题. 请稍后再试." }));


    }

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "version-tag__modal-content-heading" }, "将此集合修订版本链接到特定的API版本.", /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
        className: "btn btn-text version-tag__learn-btn-text",
        onClick: this.handleActivityFeedTagsLearn }, "了解更多")), /*#__PURE__*/




      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "version-tag__modal-content-dropdown" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-select__dropdown" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "dropdown-label" }, "选择API"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["Dropdown"], { onSelect: this.handleAPISelect }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["DropdownButton"], { type: "secondary", size: "small" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_5__["Button"], {
        className: "dropdown-head",
        disabled: this.state.isOnlyOneAPI }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", { className: this.getDropdownHeadLabelClasses(!this.state.selectedAPI) },
      this.state.selectedAPI && this.state.selectedAPI.name || '选择一个API'))), /*#__PURE__*/



      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["DropdownMenu"], {
        className: "dropdown-menu",
        fluid: true },


      !_.isEmpty(this.state.items) ?
      this.state.items.map((menuItem) => {
        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["MenuItem"], { key: menuItem.id, refKey: menuItem.id }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, menuItem.name));
      }) : /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["MenuItem"], { disabled: true }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, "此工作区中没有API"))))), /*#__PURE__*/




      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-version-select__dropdown" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "dropdown-label" }, "选择版本"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["Dropdown"], {
        onSelect: this.handleAPIVersionSelect }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["DropdownButton"], { type: "secondary", size: "small" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_5__["Button"], {
        className: "dropdown-head",
        disabled: !this.state.isAPIVersionSelectEnable }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", { className: this.getDropdownHeadLabelClasses(!this.state.selectedAPIVersion) },
      this.state.selectedAPIVersion && this.state.selectedAPIVersion.name || '选择一个版本'))), /*#__PURE__*/



      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["DropdownMenu"], {
        className: "dropdown-menu-list",
        fluid: true },


      this.state.selectedAPI &&
      !_.isEmpty(this.state.selectedAPI.versions) ?
      this.state.selectedAPI.versions.map((menuItem) => {
        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["MenuItem"], { key: menuItem.id, refKey: menuItem.id }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, menuItem.name));
      }) : /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["MenuItem"], { disabled: true }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, "没有用于标记此集合的API版本."))))), /*#__PURE__*/




      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-relation-select__dropdown" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "dropdown-label" }, "添加API为"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["Dropdown"], {
        onSelect: this.handleAPIContextSelect }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["DropdownButton"], { type: "secondary", size: "small" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_5__["Button"], {
        className: "dropdown-head",
        disabled: !this.state.isAPIVersionSelectEnable }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", { className: this.getDropdownHeadLabelClasses(!this.state.selectedAPIContext) },
      this.state.selectedAPIContext.name || '将此添加为您的API'))), /*#__PURE__*/



      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["DropdownMenu"], {
        className: "dropdown-menu-list",
        fluid: true },


      CONTEXT_LIST.map((menuItem) => {
        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["MenuItem"], { key: menuItem.type, refKey: menuItem.type }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, menuItem.name));
      }))))), /*#__PURE__*/





      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "version-tag__modal-content-action" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_5__["Button"], {
        type: "secondary",
        onClick: this.props.onRequestClose,
        className: "modal-cancel-btn" }, "取消"), /*#__PURE__*/



      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Buttons__WEBPACK_IMPORTED_MODULE_5__["Button"], {
        type: "primary",
        onClick: this.handleAddVersionTag,
        className: "modal-version-tag-btn",
        disabled: this.state.isRequiredWarning || this.state.isLoading || this.props.isOffline,
        tooltip:
        this.props.isOffline ?
        '重新在线后即可执行此操作' :
        '要添加版本标记,请选择API版本以及您要添加集合的内容.' },



      this.state.isLoading ? /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_4__["default"], null) :
      '添加版本标签'))));




  }

  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Modals__WEBPACK_IMPORTED_MODULE_6__["Modal"], {
        className: "version-tag-modal",
        isOpen: this.props.isOpen,
        onRequestClose: this.props.onRequestClose,
        customStyles: this.getCustomStyles() }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Modals__WEBPACK_IMPORTED_MODULE_6__["ModalHeader"], null, "添加版本标签"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Modals__WEBPACK_IMPORTED_MODULE_6__["ModalContent"], { className: this.getModalContentClasses() },
      this.renderModalContent())));



  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ })

}]);