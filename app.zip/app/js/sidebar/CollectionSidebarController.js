(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[25],{

/***/ 9684:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionSidebarController; });
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1595);
/* harmony import */ var _postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1601);
/* harmony import */ var _postman_app_monolith_renderer_js_modules_controllers_PermissionController__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2223);
/* harmony import */ var _CollectionSidebarModel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7632);
/* harmony import */ var _datastores_adapters_CollectionModelEventsAdapter__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3189);
/* harmony import */ var _folder_datastores_adapters_FolderModelEventsAdapter__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3185);
/* harmony import */ var _request_http_datastores_adapters_RequestModelEventsAdapter__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8543);
/* harmony import */ var _example_datastores_adapters_ResponseModelEventsAdapter__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8550);
/* harmony import */ var _datastores_adapters_CollectionListingAPIAdapter__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9685);
/* harmony import */ var _common_WorkbenchStatusConstants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4479);
/* harmony import */ var _onboarding_src_common_dependencies__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2249);
/* harmony import */ var _common_SyncEndpoints__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2269);
var _class, _descriptor;function _initializerDefineProperty(target, property, descriptor, context) {if (!descriptor) return;Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 });}function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) {var desc = {};Object.keys(descriptor).forEach(function (key) {desc[key] = descriptor[key];});desc.enumerable = !!desc.enumerable;desc.configurable = !!desc.configurable;if ('value' in desc || desc.initializer) {desc.writable = true;}desc = decorators.slice().reverse().reduce(function (desc, decorator) {return decorator(target, property, desc) || desc;}, desc);if (context && desc.initializer !== void 0) {desc.value = desc.initializer ? desc.initializer.call(context) : void 0;desc.initializer = undefined;}if (desc.initializer === void 0) {Object.defineProperty(target, property, desc);desc = null;}return desc;}function _initializerWarningHelper(descriptor, context) {throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.');}












// eslint-disable-next-line no-magic-numbers
const REQUEST_TIMEOUT = 30 * 1000; // 30 seconds

/**
 * Populates the Stores with Collection attributes
 *
 * @param {Array} collectionList List of collections in the current workspace
 */
function _populateStoresWithAttributes(collectionList) {
  if (_.isEmpty(collectionList)) {
    return;
  }

  const favoritedCollections = [],
  sharedCollections = [],
  publicCollections = [],
  archivedCollections = [];

  collectionList.forEach((collection) => {
    const isFavorite = _.get(collection, 'attributes.flags.isFavorite'),
    isShared = _.get(collection, 'attributes.permissions.teamCanView'),
    isPublic = _.get(collection, 'attributes.permissions.anybodyCanView'),
    isArchived = _.get(collection, 'attributes.flags.isArchived'),
    collectionModelId = Object(_onboarding_src_common_dependencies__WEBPACK_IMPORTED_MODULE_10__["decomposeUID"])(collection.id).modelId,
    itemToPopulate = { id: collectionModelId };

    isFavorite && favoritedCollections.push(itemToPopulate);
    isShared && sharedCollections.push(itemToPopulate);
    isPublic && publicCollections.push({ id: collection.id });
    isArchived && archivedCollections.push({
      model: 'collection',
      modelId: collectionModelId });

  });

  !_.isEmpty(favoritedCollections) && Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('FavoritedCollectionStore').add(favoritedCollections);
  !_.isEmpty(sharedCollections) && Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('SharedCollectionsStore').add(sharedCollections);
  !_.isEmpty(publicCollections) && Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('PublicEntityStore').add(publicCollections);
  !_.isEmpty(archivedCollections) && Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('ArchivedResourceStore').add(archivedCollections);
}let

CollectionSidebarController = (_class = class CollectionSidebarController {constructor() {this.
    model = null;this.
    _adapters = [];_initializerDefineProperty(this, "status", _descriptor, this);}




  /**
   * @lifecycle
   */
  async didCreate() {
    this.model = new _CollectionSidebarModel__WEBPACK_IMPORTED_MODULE_3__["default"]();

    // For browser, use listing API only
    if (window.SDK_PLATFORM === 'browser') {
      try {
        await this._loadFromListingAPIAdapter();
      } catch (err) {
        pm.logger.error('CollectionSidebarController~didCreate: Error in loading collection list from listing API', err);

        return this.setSidebarStatus(_common_WorkbenchStatusConstants__WEBPACK_IMPORTED_MODULE_9__["ERROR"]);
      }

      return this.setSidebarStatus(_common_WorkbenchStatusConstants__WEBPACK_IMPORTED_MODULE_9__["READY"]);
    }

    // Additional step for integrating listing API for online app
    //
    // Try to load the sidebar in one-shot using the listing API. We'll
    // switch over to model events after this completes.
    try {
      await this._loadFromListingAPI();

      // Set sidebar ready after loading the collection list
      this.setSidebarStatus(_common_WorkbenchStatusConstants__WEBPACK_IMPORTED_MODULE_9__["READY"]);
    } catch (e) {
      pm.logger.error('CollectionSidebarController~didCreate: Failed to fetch collection list:', e);

      // Throwing here would make the sidebar show error state.
      // Instead, let the model events adapter hydrate the sidebar as a
      // failover.
    }

    try {
      await this._loadFromModelEventsAdapter();
    } catch (err) {
      pm.logger.error('CollectionSidebarController~didCreate: Error in loading collections from model events', err);

      return this.setSidebarStatus(_common_WorkbenchStatusConstants__WEBPACK_IMPORTED_MODULE_9__["ERROR"]);
    }

    return this.setSidebarStatus(_common_WorkbenchStatusConstants__WEBPACK_IMPORTED_MODULE_9__["READY"]);
  }

  /**
   * @lifecycle
   */
  beforeDestroy() {
    this._adapters && this._adapters.forEach((adapter) => {
      _.isFunction(adapter.dispose) && adapter.dispose();
    });

    this.model = null;
    this._adapters = [];
  }

  /**
   * Update status of the sidebar
   *
   * @param {String} value
   */

  setSidebarStatus(value) {
    this.status = value;
  }

  /**
   * Fetches collections from the Listing endpoint and hydrates the model
   *
   * @private
   * @return {Promise<Array<Object>>} - A promise that resolves with an array
   *    of collections fetched from the API
   */
  async _fetchCollections() {
    // Wait for sync to connect
    await Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('SyncStatusStore').onSyncAvailable();

    const workspace = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('ActiveWorkspaceStore').id,

    collectionList = await _onboarding_src_common_dependencies__WEBPACK_IMPORTED_MODULE_10__["RemoteSyncRequestService"].request(_common_SyncEndpoints__WEBPACK_IMPORTED_MODULE_11__["COLLECTION_LIST"]`${workspace}`, {
      method: 'POST',
      timeout: REQUEST_TIMEOUT }),


    /**
      * Update the collection userCanUpdate attribute to manage the glitch on fixing
      * the rendering for lock icon appearing and disappearing.
      *
      * TODO: Fix this appropriately
      */

    // Also checks whether the permission exists for collections in `PermissionStore`
    data = _.forEach(
    _.get(collectionList, 'body.data', []), (collection) => {
      const criteria = {
        model: 'collection',
        modelId: collection.id,
        action: 'UPDATE_COLLECTION' },

      compositeKey = _postman_app_monolith_renderer_js_modules_controllers_PermissionController__WEBPACK_IMPORTED_MODULE_2__["default"].getCompositeKey(criteria),
      permissionPresent = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('PermissionStore').members.has(compositeKey);

      !permissionPresent && _.set(collection, 'attributes.permissions.userCanUpdate', true);
    });


    this.model.hydrate && this.model.hydrate(data);

    return data;
  }

  /**
   * Loads the collection in a one-shot manner using the listing API.
   * Does not subscribe to changes
   */
  async _loadFromListingAPI() {
    // This is not applicable for scratchpad because we can't call the
    // listing API.
    if (pm.isScratchpad) {
      return;
    }

    const collectionList = await this._fetchCollections();

    // The listing endpoint contains the attributes for the collections
    // like forkInfo, isFavorite, etc. This information is not present in
    // the collection fetched from sync but is fetched in another call.
    // This causes the icons for these attributes to disappear when we
    // switch over to model events based data. To prevent that, we
    // populate the stores using the date fetched from listing endpoint
    // here.
    _populateStoresWithAttributes(collectionList);
  }

  /**
   * Loads the collection model using model events adapter
   */
  async _loadFromModelEventsAdapter() {
    const workspace = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('ActiveWorkspaceStore').id,

    collectionAdapter = new _datastores_adapters_CollectionModelEventsAdapter__WEBPACK_IMPORTED_MODULE_4__["default"](
    this.model.getCollectionAdapterModel(),
    {
      activeWorkspace: workspace,
      useUID: true }),


    folderAdapter = new _folder_datastores_adapters_FolderModelEventsAdapter__WEBPACK_IMPORTED_MODULE_5__["default"](
    this.model.getFolderAdapterModel()),

    requestAdapter = new _request_http_datastores_adapters_RequestModelEventsAdapter__WEBPACK_IMPORTED_MODULE_6__["default"](
    this.model.getRequestAdapterModel()),

    hydrateEntities = [
    collectionAdapter.hydrate(),
    folderAdapter.hydrate(),
    requestAdapter.hydrate()];


    this._adapters.push(collectionAdapter, folderAdapter, requestAdapter);

    // We're hydrating the responses after the promise is resolved because
    // response needs the request to be hydrated in the sidebar model to
    // add references (requestModel.responses) to the responses. If response
    // is hydrated before its parent request, it cannot be linked to the
    // parent request and does not show up in the sidebar.
    await Promise.all(hydrateEntities);

    // At this point we have enough data to show in the sidebar. Set it as
    // ready and load the responses in the background.
    this.setSidebarStatus(_common_WorkbenchStatusConstants__WEBPACK_IMPORTED_MODULE_9__["READY"]);

    const responseAdapter = new _example_datastores_adapters_ResponseModelEventsAdapter__WEBPACK_IMPORTED_MODULE_7__["default"](
    this.model.getResponseAdapterModel());


    this._adapters.push(responseAdapter);

    await responseAdapter.hydrate();
  }

  /**
   * Loads the collection model using listing API adapter
   */
  async _loadFromListingAPIAdapter() {
    const listingAPIAdapter = new _datastores_adapters_CollectionListingAPIAdapter__WEBPACK_IMPORTED_MODULE_8__["default"](
    this.model.getCollectionAdapterModel());


    this._adapters.push(listingAPIAdapter);

    await listingAPIAdapter.hydrate();
  }}, (_descriptor = _applyDecoratedDescriptor(_class.prototype, "status", [mobx__WEBPACK_IMPORTED_MODULE_0__["observable"]], { configurable: true, enumerable: true, writable: true, initializer: function () {return _common_WorkbenchStatusConstants__WEBPACK_IMPORTED_MODULE_9__["LOADING"];} }), _applyDecoratedDescriptor(_class.prototype, "setSidebarStatus", [mobx__WEBPACK_IMPORTED_MODULE_0__["action"]], Object.getOwnPropertyDescriptor(_class.prototype, "setSidebarStatus"), _class.prototype)), _class);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 9685:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionListingAPIAdapter; });
/* harmony import */ var _postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1601);
/* harmony import */ var _postman_app_monolith_renderer_js_common_model_event__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1616);
/* harmony import */ var _postman_app_monolith_renderer_js_common_model_event__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_postman_app_monolith_renderer_js_common_model_event__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _postman_app_monolith_renderer_js_utils_uid_helper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1621);
/* harmony import */ var _common_SyncEndpoints__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2269);
/* harmony import */ var _common_datastores_adapters_ListingAPIAdapter__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9686);






/**
 * Adapter for Collection Listing API
 *
 * The model which uses this adapter should have these methods:
 *   - hydrate (entities)
 *   - add (entities)
 *   - remove (ids)
 *   - updateFavorite (id)
 */
class CollectionListingAPIAdapter extends _common_datastores_adapters_ListingAPIAdapter__WEBPACK_IMPORTED_MODULE_4__["default"] {
  getListAndSubscribeAPIEndpoint() {
    const workspace = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_0__["getStore"])('ActiveWorkspaceStore').id;

    return _common_SyncEndpoints__WEBPACK_IMPORTED_MODULE_3__["COLLECTION_LIST_AND_SUBSCRIBE"]`${workspace}`;
  }

  getListAPIEndpoint() {
    const workspace = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_0__["getStore"])('ActiveWorkspaceStore').id;

    return _common_SyncEndpoints__WEBPACK_IMPORTED_MODULE_3__["COLLECTION_LIST"]`${workspace}`;
  }

  dispose() {
    super.dispose();

    this.unsubscribeModelEvents && this.unsubscribeModelEvents();
  }

  _subscribeToChangeEvents(realtimeSubscriptionId) {
    super._subscribeToChangeEvents(realtimeSubscriptionId);

    // Currently there are no real-time events for favorite/unfavorite in
    // Listing API, so we're using the model-events to create a bridge in the
    // Listing adapter.
    // See: RUNTIME-2780

    // If the subscription for favorite/unfavorite already exists, clear it
    this.unsubscribeModelEvents && this.unsubscribeModelEvents();
    this.unsubscribeModelEvents = null;

    this.unsubscribeModelEvents = pm.eventBus.channel('model-events').subscribe((event) => {
      if (Object(_postman_app_monolith_renderer_js_common_model_event__WEBPACK_IMPORTED_MODULE_1__["getEventNamespace"])(event) !== 'collection') {
        return;
      }

      const eventName = Object(_postman_app_monolith_renderer_js_common_model_event__WEBPACK_IMPORTED_MODULE_1__["getEventName"])(event);

      if (!['favorite', 'unfavorite'].includes(eventName)) {
        return;
      }

      const eventData = Object(_postman_app_monolith_renderer_js_common_model_event__WEBPACK_IMPORTED_MODULE_1__["getEventData"])(event),
      collectionId = _.get(eventData, 'collection.id'),
      owner = _.get(eventData, 'collection.owner'),
      collectionUid = Object(_postman_app_monolith_renderer_js_utils_uid_helper__WEBPACK_IMPORTED_MODULE_2__["composeUID"])(collectionId, owner),
      isFavorite = eventName === 'favorite';

      // To-do: remove this when RUNTIME-2780 completed
      this.model.updateFavorite && this.model.updateFavorite(collectionUid, isFavorite);
    });
  }}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ })

}]);