(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[31],{

/***/ 9706:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EnvironmentSidebarController; });
/* harmony import */ var _postman_app_monolith_renderer_js_modules_services_RemoteSyncRequestService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1798);
/* harmony import */ var _postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1601);
/* harmony import */ var _postman_app_monolith_renderer_js_modules_controllers_PermissionController__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2223);
/* harmony import */ var _common_SyncEndpoints__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2269);
/* harmony import */ var _EnvironmentSidebarModel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9705);
/* harmony import */ var _datastores_adapters_EnvironmentListingAPIAdapter__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9707);
/* harmony import */ var _datastores_adapters_EnvironmentModelEventsAdapter__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8534);








/**
 * Populates the Stores with Environment attributes
 *
 * @param {Array} environments List of environments in the current workspace
 */
function _populateStoresWithAttributes(environments) {
  if (_.isEmpty(environments)) {
    return;
  }

  const publicEnvironments = [],
  sharedEnvironments = [];

  environments.forEach((environment) => {
    const isPublic = _.get(environment, 'attributes.permissions.anybodyCanView'),
    isShared = _.get(environment, 'attributes.permissions.teamCanView');

    isPublic && publicEnvironments.push({ id: environment.id });
    isShared && sharedEnvironments.push({ id: environment.id });
  });

  !_.isEmpty(publicEnvironments) && Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('PublicEntityStore').add(publicEnvironments);
  !_.isEmpty(sharedEnvironments) && Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('SharedEnvironmentsStore').add(sharedEnvironments);
}

class EnvironmentSidebarController {
  constructor() {
    this.model = null;
    this.adapter = null;
  }

  async didCreate() {
    this.model = new _EnvironmentSidebarModel__WEBPACK_IMPORTED_MODULE_4__["default"]();

    this.model.setLoading && this.model.setLoading(true);

    // If this is Native App, we use the sync API and cache stores for realtime
    // updates
    if (window.SDK_PLATFORM !== 'browser') {
      // Additional step for integrating listing API for online app
      if (!pm.isScratchpad) {
        const environmentListResponse = await this.fetchEnvironments(),
        environments = _.get(environmentListResponse, 'body.data', []);

        _populateStoresWithAttributes(environments);
      }

      this.adapter = new _datastores_adapters_EnvironmentModelEventsAdapter__WEBPACK_IMPORTED_MODULE_6__["default"](this.model);
    } else {
      this.adapter = new _datastores_adapters_EnvironmentListingAPIAdapter__WEBPACK_IMPORTED_MODULE_5__["default"](this.model);
    }

    await this.adapter.hydrate();

    this.model.setLoading && this.model.setLoading(false);
  }

  async fetchEnvironments() {
    // Wait for sync to connect
    await Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('SyncStatusStore').onSyncAvailable();

    const workspace = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('ActiveWorkspaceStore').id,

    // When sidebar loads then make a call the sync to get the list of environments
    environmentList = await _postman_app_monolith_renderer_js_modules_services_RemoteSyncRequestService__WEBPACK_IMPORTED_MODULE_0__["default"].request(
    _common_SyncEndpoints__WEBPACK_IMPORTED_MODULE_3__["ENVIRONMENT_LIST_AND_SUBSCRIBE"]`${workspace}`,
    { method: 'POST' }),


    /**
       * Update the environment userCanUpdate attribute to manage the glitch on fixing
       * the rendering for lock icon appearing and disappearing.
       *
       * TODO: Fix this appropriately
       */

    // Also checks whether the permission exists for environments in `PermissionStore`
    environments = _.forEach(
    _.get(environmentList, 'body.data', []), (environment) => {
      const criteria = {
        model: 'environment',
        modelId: environment.id,
        action: 'UPDATE_ENVIRONMENT' },

      compositeKey = _postman_app_monolith_renderer_js_modules_controllers_PermissionController__WEBPACK_IMPORTED_MODULE_2__["default"].getCompositeKey(criteria),
      permissionPresent = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('PermissionStore').members.has(compositeKey);

      !permissionPresent && _.set(environment, 'attributes.permissions.userCanUpdate', true);
    });


    this.model.hydrate && this.model.hydrate(environments);
    this.model.setLoading && this.model.setLoading(false);

    return environmentList;
  }

  beforeDestroy() {
    this.model.dispose();
    this.model = null;

    this.adapter && this.adapter.dispose();
    this.adapter = null;
  }}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 9707:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EnvironmentListingAPIAdapter; });
/* harmony import */ var _postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1601);
/* harmony import */ var _common_datastores_adapters_ListingAPIAdapter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9686);
/* harmony import */ var _common_SyncEndpoints__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2269);




/**
 * Adapter for Environment Listing API
 *
 * The model which uses this adapter should have these methods:
 *   - hydrate (entities)
 *   - add (entity)
 *   - remove (ids)
 */
class EnvironmentListingAPIAdapter extends _common_datastores_adapters_ListingAPIAdapter__WEBPACK_IMPORTED_MODULE_1__["default"] {
  getListAndSubscribeAPIEndpoint() {
    const workspace = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_0__["getStore"])('ActiveWorkspaceStore').id;

    return _common_SyncEndpoints__WEBPACK_IMPORTED_MODULE_2__["ENVIRONMENT_LIST_AND_SUBSCRIBE"]`${workspace}`;
  }

  getListAPIEndpoint() {
    const workspace = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_0__["getStore"])('ActiveWorkspaceStore').id;

    return _common_SyncEndpoints__WEBPACK_IMPORTED_MODULE_2__["ENVIRONMENT_LIST"]`${workspace}`;
  }}

/***/ })

}]);