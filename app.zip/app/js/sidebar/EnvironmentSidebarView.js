(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[30],{

/***/ 9699:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EnvironmentSidebarView; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2298);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2293);
/* harmony import */ var _postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1601);
/* harmony import */ var _EnvironmentSidebarContainer_EnvironmentSidebarContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9700);
/* harmony import */ var _common_components_molecule__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4068);
/* harmony import */ var _EnvironmentSidebarModel__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9705);
var _class;







let


EnvironmentSidebarView = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class EnvironmentSidebarView extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  render() {
    const { controller } = this.props,

    // The API isConsistentlyOffline is only supposed to be used to show the offline state view to the user
    // when he has been consistently offline.
    // For disabling the actions on lack of connectivity, please rely on the socket connected state itself for now.
    // Otherwise, there is a chance of data loss if we let the user perform actions
    // when we are attempting a connection.
    { isConsistentlyOffline } = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('SyncStatusStore');

    if (!pm.isScratchpad && isConsistentlyOffline && _.get(controller, 'model.isLoading')) {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_components_molecule__WEBPACK_IMPORTED_MODULE_5__["SidebarOfflineState"], null);
    }

    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_EnvironmentSidebarContainer_EnvironmentSidebarContainer__WEBPACK_IMPORTED_MODULE_4__["default"], { model: controller.model });
  }}) || _class;


EnvironmentSidebarView.propTypes = {
  controller: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.shape({
    model: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.instanceOf(_EnvironmentSidebarModel__WEBPACK_IMPORTED_MODULE_6__["default"]) }).
  isRequired };
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 9700:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EnvironmentSidebarContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2298);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2293);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2856);
/* harmony import */ var _EnvironmentSidebarMenu_EnvironmentSidebarMenu__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9701);
/* harmony import */ var _EnvironmentSidebarListContainer_EnvironmentSidebarListContainer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9702);
/* harmony import */ var _EnvironmentSidebarModel__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9705);
var _class;






let


EnvironmentSidebarContainer = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class EnvironmentSidebarContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "env-sidebar-container" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_EnvironmentSidebarMenu_EnvironmentSidebarMenu__WEBPACK_IMPORTED_MODULE_4__["default"], {
        model: this.props.model }), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_3__["default"], { identifier: "environment" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_EnvironmentSidebarListContainer_EnvironmentSidebarListContainer__WEBPACK_IMPORTED_MODULE_5__["default"], {
        model: this.props.model }))));




  }}) || _class;


EnvironmentSidebarContainer.propTypes = {
  model: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.instanceOf(_EnvironmentSidebarModel__WEBPACK_IMPORTED_MODULE_6__["default"]).isRequired };

/***/ }),

/***/ 9701:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EnvironmentSidebarMenu; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2293);
/* harmony import */ var _postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1601);
/* harmony import */ var _postman_app_monolith_renderer_js_containers_apps_requester_sidebar_SidebarListActions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9025);
/* harmony import */ var _api_EnvironmentInterface__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4504);
/* harmony import */ var _common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4181);
var _class;







const NEW_ENV_CLICK_THROTTLE_TIMEOUT = 1000; // 1 sec
let

EnvironmentSidebarMenu = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class EnvironmentSidebarMenu extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = { isEnvCreateEnabled: true };

    this.handleCreate = this.handleCreate.bind(this);
    this.handleSearchChange = this.handleSearchChange.bind(this);
  }

  handleCreate() {
    // Disable the create environment button for the defined timeout to prevent
    // a lot of environment creates in a short amount of time
    this.setState({ isEnvCreateEnabled: false });

    // Enable after the timeout has elapsed
    //
    // Cancel any pending timeout before setting a new timeout
    this.timeoutId && clearTimeout(this.timeoutId);
    this.timeoutId = setTimeout(
    () => {this.setState({ isEnvCreateEnabled: true });},
    NEW_ENV_CLICK_THROTTLE_TIMEOUT);


    Object(_api_EnvironmentInterface__WEBPACK_IMPORTED_MODULE_4__["createEnvironment"])({ openInTab: true });
  }


  handleSearchChange(query) {
    this.props.model && this.props.model.setSearchQuery(query);
  }

  render() {
    const { userCanSave } = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('OnlineStatusStore'),
    canAddEnvironment = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('PermissionStore').can('addEnvironment', 'workspace', Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('ActiveWorkspaceStore').id),
    isEnvCreateEnabled = userCanSave && canAddEnvironment && this.state.isEnvCreateEnabled;

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_containers_apps_requester_sidebar_SidebarListActions__WEBPACK_IMPORTED_MODULE_3__["default"], {
        createNewConfig: {
          tooltip: userCanSave ?
          canAddEnvironment ?
          '创建新的环境' :
          _common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_5__["DISABLED_TOOLTIP_NO_PERMISSION"] :

          _common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_5__["DISABLED_TOOLTIP_IS_OFFLINE"],
          disabled: !isEnvCreateEnabled,
          onCreate: this.handleCreate,
          xPathIdentifier: 'addEnvironment' },

        onSearch: this.handleSearchChange,
        searchQuery: this.props.model.searchQuery }));


  }}) || _class;

/***/ }),

/***/ 9702:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EnvironmentSidebarListContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2298);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1595);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2293);
/* harmony import */ var _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2327);
/* harmony import */ var _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_postman_react_click_outside__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_virtualized_auto_sizer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5127);
/* harmony import */ var react_window__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3699);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2314);
/* harmony import */ var _postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1601);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2856);
/* harmony import */ var _EnvironmentSidebarListItem_EnvironmentSidebarListItem__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9703);
/* harmony import */ var _globals_sidebar_GlobalsSidebarListItem_GlobalsSidebarListItem__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9704);
/* harmony import */ var _EnvironmentSidebarModel__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9705);
/* harmony import */ var _api_EnvironmentInterface__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(4504);
/* harmony import */ var _common_ToastHelpers__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(2353);
/* harmony import */ var _EnvironmentActionsConstant__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4505);
/* harmony import */ var _common_ModelConstant__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(2357);
/* harmony import */ var _appsdk_sidebar_SidebarEmptyState_SidebarEmptyState__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(9027);
/* harmony import */ var _appsdk_sidebar_SidebarNoResultsFound_SidebarNoResultsFound__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(8228);
/* harmony import */ var _appsdk_sidebar_SidebarLoadingState_SidebarLoadingState__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(7771);
var _class;

























const OVERSCAN_COUNT = 10,
DEFAULT_ITEM_HEIGHT = 28;

/**
 * Get input value from the inlineInput
 *
 * @param {Object} editStateFromInput - state of InlineInput
 * @returns {String|undefined}
 */
function getInputValueFromInputEditState(editStateFromInput) {
  return _.get(editStateFromInput, 'inlineInput.value');
}let



EnvironmentSidebarListContainer = _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_4___default()(_class = Object(mobx_react__WEBPACK_IMPORTED_MODULE_3__["observer"])(_class = class EnvironmentSidebarListContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    /**
     * Cache for list item currently in edit (renaming) mode
     *
     * @type {Object}
     * @property {Number} index - index of the list item in edit mode
     * @property {Object} inlineInput - cache of inlineInput's state
     */
    this.editCache = null;

    this.listItemRefs = {};

    this.getItemSize = this.getItemSize.bind(this);
    this.scrollToItem = this.scrollToItem.bind(this);
    this.setEditCache = this.setEditCache.bind(this);
    this.saveCachedValue = this.saveCachedValue.bind(this);
    this.handleClickOutside = this.handleClickOutside.bind(this);

    // Shortcut handlers
    this.focusNext = this.focusNext.bind(this);
    this.focusPrev = this.focusPrev.bind(this);
    this.deleteItem = this.deleteItem.bind(this);
    this.renameItem = this.renameItem.bind(this);
    this.duplicateItem = this.duplicateItem.bind(this);
  }

  componentDidMount() {
    this.scrollToViewReactionDisposer = Object(mobx__WEBPACK_IMPORTED_MODULE_2__["reaction"])(() => _.get(this.props, 'model.activeItemIndex'), (activeItemIndex) => this.scrollToItem(activeItemIndex));

    // This is required to clear the height cache of items present after the first element
    // when the items shown are filtered and does not have `Globals` item in the list.
    this.resetHeightReactionDisposer = Object(mobx__WEBPACK_IMPORTED_MODULE_2__["reaction"])(() => _.get(this.props, 'model.items'), () => {this.listRef && this.listRef.resetAfterIndex(0);});
  }

  componentWillUnmount() {
    this.scrollToViewReactionDisposer && this.scrollToViewReactionDisposer();
    this.resetHeightReactionDisposer && this.resetHeightReactionDisposer();

    clearTimeout(this.clearCollectionLoadingTimer);
  }

  getSidebarEmptyState() {
    const canAddEnvironment = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('PermissionStore').can('addEnvironment', 'workspace', Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('ActiveWorkspaceStore').id);

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_sidebar_SidebarEmptyState_SidebarEmptyState__WEBPACK_IMPORTED_MODULE_18__["default"], {
        illustration: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_7__["IllustrationNoEnvironment"], null),
        title: "您没有任何环境",
        message: "环境是一组变量,允许您切换请求的上下文.",
        action: canAddEnvironment && {
          label: '创建环境',
          handler: _api_EnvironmentInterface__WEBPACK_IMPORTED_MODULE_14__["createEnvironment"] } }));



  }

  getGlobalsListItem() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_10__["default"], { identifier: "globals" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_globals_sidebar_GlobalsSidebarListItem_GlobalsSidebarListItem__WEBPACK_IMPORTED_MODULE_12__["default"], {
        model: this.props.model.globals })));



  }

  getItemSize() {
    return DEFAULT_ITEM_HEIGHT;
  }

  getListItem({ style, index }) {
    const { model } = this.props,
    item = _.get(model, ['items', index]);

    if (!item) {
      return null;
    }

    const { id: itemId } = item;

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_10__["default"], { identifier: itemId }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { style: style }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_EnvironmentSidebarListItem_EnvironmentSidebarListItem__WEBPACK_IMPORTED_MODULE_11__["default"], {
        ref: (ref) => {this.listItemRefs[itemId] = ref;},
        key: itemId,
        index: index,
        item: item,
        model: model,
        setEditCache: this.setEditCache,
        editCache: _.get(this.editCache, 'index') === index ? this.editCache : null }))));




  }

  getKeyMapHandlers() {
    return {
      quit: pm.shortcuts.handle('quit', this.setEditCache.bind(this, null)),
      select: pm.shortcuts.handle('select', this.saveCachedValue),
      nextItem: pm.shortcuts.handle('nextItem', this.focusNext),
      prevItem: pm.shortcuts.handle('prevItem', this.focusPrev),

      // @todo[EntityInTabs]: Stop firing of these shortcuts for Globals list item
      delete: pm.shortcuts.handle('delete', this.deleteItem),
      rename: pm.shortcuts.handle('rename', this.renameItem),
      duplicate: pm.shortcuts.handle('duplicate', this.duplicateItem) };

  }

  setEditCache(value) {
    this.editCache = value;
  }

  saveCachedValue() {
    if (!this.editCache) {
      return;
    }

    const { index, inlineInput: inlineInputEditState } = this.editCache,
    item = _.get(this.props.model, ['items', index]),
    valueToUpdate = getInputValueFromInputEditState(inlineInputEditState);

    // `valueToUpdate` can be an empty string which is a falsy values
    // but a valid one while the item is in edit mode,
    // hence checking for `isNil` (null/undefined)
    if (!item || _.isNil(valueToUpdate)) {
      return;
    }

    this.props.model.handleAction(item.id, _EnvironmentActionsConstant__WEBPACK_IMPORTED_MODULE_16__["ACTION_TYPE_RENAME"], { name: valueToUpdate });
  }

  focusNext(e) {
    e && e.preventDefault();
    this.props.model.focusNext();
  }

  focusPrev(e) {
    e && e.preventDefault();
    this.props.model.focusPrev();
  }

  deleteItem() {
    this.props.model.handleAction(_.get(this.props.model, 'activeItem'), _EnvironmentActionsConstant__WEBPACK_IMPORTED_MODULE_16__["ACTION_TYPE_DELETE"]);
  }

  renameItem() {
    if (!Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('OnlineStatusStore').userCanSave) {
      return Object(_common_ToastHelpers__WEBPACK_IMPORTED_MODULE_15__["showOfflineActionDisabledToast"])();
    }

    // FIXME: This should find the index of the activeItem and then trigger the
    _.invoke(this.listItemRefs, [_.get(this.props.model, 'activeItem'), 'handleEditName']);
  }

  duplicateItem() {
    this.props.model.handleAction(_.get(this.props.model, 'activeItem'), _EnvironmentActionsConstant__WEBPACK_IMPORTED_MODULE_16__["ACTION_TYPE_DUPLICATE"]);
  }

  handleClickOutside(e) {
    const targetClassName = e && e.target && e.target.className,
    isClickFromInsideInput = targetClassName === 'input input-box inline-input';

    // Bailout if the click is coming from inside the inline input or
    // there is no cache present for any list item
    if (!this.editCache || isClickFromInsideInput) {
      return;
    }

    this.saveCachedValue();
  }

  scrollToItem(index) {
    !_.isEmpty(this.listRef) && !_.isNil(index) && this.listRef.scrollToItem(index);
  }

  render() {
    const { model } = this.props,
    itemLength = _.size(model.items);


    // Show loading state
    if (model.isLoading) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "env-sidebar-list-container" },
        this.getGlobalsListItem(), /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_sidebar_SidebarLoadingState_SidebarLoadingState__WEBPACK_IMPORTED_MODULE_20__["default"], null)));


    }

    // Items is all empty then we need to show some empty states
    if (_.isEmpty(model.items)) {
      // If the searchQuery empty
      if (_.isEmpty(model.searchQuery)) {
        return /*#__PURE__*/(
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "env-sidebar-list-container" },
          this.getGlobalsListItem(),
          this.getSidebarEmptyState()));


      }

      // If the search term is not empty and does not contain the term global
      if (!_common_ModelConstant__WEBPACK_IMPORTED_MODULE_17__["GLOBALS"].includes(model.searchQuery)) {
        return /*#__PURE__*/(
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_sidebar_SidebarNoResultsFound_SidebarNoResultsFound__WEBPACK_IMPORTED_MODULE_19__["default"], { searchQuery: model.searchQuery, illustration: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_7__["IllustrationNoEnvironment"], null) }));

      }

      // Note: If it contains the term global then we just let it fall through
      // to be shown as part of the listing
    }

    const lister = (data) => /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mobx_react__WEBPACK_IMPORTED_MODULE_3__["Observer"], null,
    this.getListItem.bind(this, data));



    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_8__["default"], {
        keyMap: pm.shortcuts.getShortcuts(),
        handlers: this.getKeyMapHandlers() }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "env-sidebar-list-container", onClick: this.handleClickOutside },
      this.getGlobalsListItem(), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "env-sidebar-list" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_virtualized_auto_sizer__WEBPACK_IMPORTED_MODULE_5__["default"], null,
      ({ height, width }) => /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_window__WEBPACK_IMPORTED_MODULE_6__["VariableSizeList"], {
        height: height,
        width: width,
        itemCount: itemLength,
        itemSize: this.getItemSize,
        overscanCount: OVERSCAN_COUNT,
        ref: (ref) => {this.listRef = ref;} },

      lister))))));







  }}) || _class) || _class;


EnvironmentSidebarListContainer.propTypes = {
  model: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.instanceOf(_EnvironmentSidebarModel__WEBPACK_IMPORTED_MODULE_13__["default"]).isRequired };
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 9703:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EnvironmentSidebarListItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2293);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2298);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9);
/* harmony import */ var _postman_app_monolith_renderer_js_containers_apps_requester_sidebar_SidebarListItem__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9023);
/* harmony import */ var _postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1601);
/* harmony import */ var _postman_app_monolith_renderer_js_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4332);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2325);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2856);
/* harmony import */ var _workbench_EnvironmentMetaIcons__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4654);
/* harmony import */ var _EnvironmentActionsConstant__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4505);
/* harmony import */ var _common_components_molecule__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4068);
/* harmony import */ var _common_ScratchpadConstants__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4378);
/* harmony import */ var _common_ToastHelpers__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2353);
/* harmony import */ var _common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(4181);
var _class;
















let


EnvironmentSidebarListItem = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class EnvironmentSidebarListItem extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleEditName = this.handleEditName.bind(this);
    this.handleItemSelect = this.handleItemSelect.bind(this);
    this.handleRenameSubmit = this.handleRenameSubmit.bind(this);
    this.handleSetActiveEnvironment = this.handleSetActiveEnvironment.bind(this);
    this.handleRemoveActiveEnvironment = this.handleRemoveActiveEnvironment.bind(this);
    this.handleDropdownActionSelect = this.handleDropdownActionSelect.bind(this);

    this.containerRef = this.containerRef.bind(this);
    this.getStatusIndicators = this.getStatusIndicators.bind(this);
    this.getDisabledText = this.getDisabledText.bind(this);
  }

  // ToDo: Need to move edit cache capability to SidebarListItem and implement it for all sidebars
  componentDidMount() {
    // If the list item was in edit (renaming) state, restore its state
    if (this.props.editCache && this.listItemRef) {
      this.handleEditName();

      this.listItemRef.setEditState(this.props.editCache.inlineInput);
    }
  }

  // ToDo: Need to move edit cache capability to SidebarListItem and implement it for all sidebars
  componentWillUnmount() {
    const { listItemRef } = this;

    if (!listItemRef) {
      return;
    }

    if (!listItemRef.isEditing()) {
      return;
    }

    // If the list item is in its edit state, cache the internal state
    this.props.setEditCache({
      index: this.props.index,
      inlineInput: listItemRef.getEditState() });

  }

  getStatusIndicators() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_workbench_EnvironmentMetaIcons__WEBPACK_IMPORTED_MODULE_10__["default"], {
        environment: this.props.item,
        showForkLabel: true }));


  }

  getRightAlignedContainer(isHovered, isMoreActionsDropdownOpen) {
    const classNames = classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'env-actions-icon-container': true,
      isHovered: isHovered || isMoreActionsDropdownOpen,
      isActive: this.props.item.isActive });


    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: classNames }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_8__["Button"], {
        type: "icon",
        tooltip: "设为非活动",
        onClick: this.handleRemoveActiveEnvironment,
        className: "sidebar-action-btn active-env-icon" }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_4__["Icon"], { name: "icon-state-success-fill-small", size: "large", color: "content-color-primary" })), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_8__["Button"], {
        type: "icon",
        tooltip: "设为活动",
        onClick: this.handleSetActiveEnvironment,
        className: "sidebar-action-btn inactive-env-icon" }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_4__["Icon"], { name: "icon-state-success-stroke", size: "large", color: "content-color-primary" }))),


      !isHovered && !isMoreActionsDropdownOpen && this.props.item.isActive && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "env-actions__more-actions-placeholder" })));


  }

  getDisabledText(isDisabled, actionType) {
    if (!isDisabled) {
      return;
    }

    if (pm.isScratchpad) {
      return _common_ScratchpadConstants__WEBPACK_IMPORTED_MODULE_13__["DISABLED_IN_SCRATCHPAD_TOOLTIP"];
    }

    if (!Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('OnlineStatusStore').userCanSave) {
      return _common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_15__["DISABLED_TOOLTIP_IS_OFFLINE"];
    }

    const defaultMessage = _common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_15__["DISABLED_TOOLTIP_NO_PERMISSION"],
    manageRolesMessage = '您需要登录到一个团队才能执行此操作',
    workspaceId = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveWorkspaceStore').id;

    switch (actionType) {
      case _EnvironmentActionsConstant__WEBPACK_IMPORTED_MODULE_11__["ACTION_MANAGE_ROLES"]:
        return manageRolesMessage;

      case _EnvironmentActionsConstant__WEBPACK_IMPORTED_MODULE_11__["ACTION_REMOVE_FROM_WORKSPACE"]:
        if (Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('PermissionStore').can('removeEnvironment', 'workspace', workspaceId)) {
          return '联网以执行此操作';
        }

        return defaultMessage;

      case _EnvironmentActionsConstant__WEBPACK_IMPORTED_MODULE_11__["ACTION_TYPE_PULL_REQUEST"]:
        return '即将在未来的版本中发布!';

      case _EnvironmentActionsConstant__WEBPACK_IMPORTED_MODULE_11__["ACTION_TYPE_MERGE"]:
        return '即将在未来的版本中发布!';

      default:
        return defaultMessage;}

  }

  getMenuItemIconClasses(label) {
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({ 'dropdown-menu-item-icon': true }, { 'pm-icon': true }, { 'pm-icon-normal': true }, `menu-icon--${label}`);
  }

  getMenuItems() {
    const { model, item } = this.props;

    return _.map(model.getActions(item.id), (action) => {
      const item = /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", { className: "env-action-item" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "dropdown-menu-item-label" }, action.label),

      action.shortcut && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "dropdown-menu-item-shortcut" }, Object(_postman_app_monolith_renderer_js_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_7__["getShortcutByName"])(action.shortcut)));




      return !action.hide && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_components_molecule__WEBPACK_IMPORTED_MODULE_12__["MenuItem"], {
        key: action.type,
        refKey: action.type,
        disabled: !action.isEnabled,
        disabledText: this.getDisabledText(!action.isEnabled, action.type) },

      action.xpathLabel ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_9__["default"], { identifier: action.xpathLabel }, item) : item);


    });
  }

  getActionsMenuItems() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_components_molecule__WEBPACK_IMPORTED_MODULE_12__["DropdownMenu"], {
        className: "env-dropdown-menu",
        "align-right": true },

      this.getMenuItems()));


  }

  containerRef(ele) {
    this.listItemRef = ele;
  }

  handleSetActiveEnvironment() {
    this.props.model.handleAction(this.props.item.id, _EnvironmentActionsConstant__WEBPACK_IMPORTED_MODULE_11__["ACTION_TYPE_SET_ACTIVE"]);
  }

  handleRemoveActiveEnvironment() {
    this.props.model.handleAction(this.props.item.id, _EnvironmentActionsConstant__WEBPACK_IMPORTED_MODULE_11__["ACTION_TYPE_SET_ACTIVE"], { noEnvironment: true });
  }

  handleEditName() {
    _.invoke(this.listItemRef, 'editText');
  }

  async handleRenameSubmit(newName) {
    await this.props.model.handleAction(this.props.item.id, _EnvironmentActionsConstant__WEBPACK_IMPORTED_MODULE_11__["ACTION_TYPE_RENAME"], { name: newName });
    this.props.setEditCache(null);
  }

  async handleDropdownActionSelect(action) {
    // If action is of rename toggle then just handle it here
    if (action === _EnvironmentActionsConstant__WEBPACK_IMPORTED_MODULE_11__["ACTION_TYPE_RENAME_TOGGLE"]) {
      if (!Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('OnlineStatusStore').userCanSave) {
        return Object(_common_ToastHelpers__WEBPACK_IMPORTED_MODULE_14__["showOfflineActionDisabledToast"])();
      }

      return this.handleEditName();
    }

    await this.props.model.handleAction(this.props.item.id, action);
  }

  handleItemSelect() {
    this.props.model.openInTab(this.props.item.id);
  }

  render() {
    const { item, model } = this.props,
    rightAlignedContainer = (...args) => /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mobx_react__WEBPACK_IMPORTED_MODULE_1__["Observer"], null,
    this.getRightAlignedContainer.bind(this, ...args));



    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_containers_apps_requester_sidebar_SidebarListItem__WEBPACK_IMPORTED_MODULE_5__["default"], {
        ref: this.containerRef,
        text: item.name,
        isForked: !!(_.get(item, 'attributes.fork.forkId') || _.get(item, 'attributes.fork.id')),
        isSelected: model.activeItem === item.id,
        onClick: this.handleItemSelect,
        onRename: this.handleRenameSubmit,
        statusIndicators: this.getStatusIndicators,
        rightMetaComponent: rightAlignedContainer,
        moreActions: this.getActionsMenuItems(),
        onActionsDropdownSelect: this.handleDropdownActionSelect }));


  }}) || _class;



EnvironmentSidebarListItem.propTypes = {
  index: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.number.isRequired,
  item: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.object.isRequired,
  model: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.object.isRequired,
  editCache: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.object.isRequired,
  setEditCache: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.func.isRequired };
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 9704:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return GlobalsSidebarListItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2293);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2298);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _postman_app_monolith_renderer_js_containers_apps_requester_sidebar_SidebarListItem__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9023);
/* harmony import */ var _environment_sidebar_EnvironmentSidebarModel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9705);
var _class;




let


GlobalsSidebarListItem = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class GlobalsSidebarListItem extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleSelect = this.handleSelect.bind(this);
  }

  getItemClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'globals-sidebar-list-item': true,
      selected: this.props.model.isActive });

  }

  handleSelect() {
    this.props.model.openInTab();
  }

  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_containers_apps_requester_sidebar_SidebarListItem__WEBPACK_IMPORTED_MODULE_4__["default"], {
        text: "全局",
        isSelected: this.props.model.isActive,
        onClick: this.handleSelect }), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "globals-separator" })));


  }}) || _class;


GlobalsSidebarListItem.propTypes = {
  model: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.instanceOf(_environment_sidebar_EnvironmentSidebarModel__WEBPACK_IMPORTED_MODULE_5__["GlobalsModel"]).isRequired };

/***/ })

}]);