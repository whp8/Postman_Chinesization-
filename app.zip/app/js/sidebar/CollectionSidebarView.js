(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[24],{

/***/ 9652:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionSidebarView; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2298);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2293);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2856);
/* harmony import */ var _postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1601);
/* harmony import */ var _CollectionSidebarModel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7632);
/* harmony import */ var _appsdk_sidebar_SidebarLoadingState_SidebarLoadingState__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7771);
/* harmony import */ var _CollectionSidebarListContainer_CollectionSidebarListContainer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9653);
/* harmony import */ var _CollectionSidebarMenu_CollectionSidebarMenu__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9682);
/* harmony import */ var _common_WorkbenchStatusConstants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4479);
/* harmony import */ var _common_components_SidebarErrorState_SidebarErrorState__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9683);
/* harmony import */ var _common_components_molecule__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4068);
var _class;














let


CollectionSidebarView = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class CollectionSidebarView extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.focus = this.focus.bind(this);
    this.focusCollection = this.focusCollection.bind(this);
    this.focusNext = this.focusNext.bind(this);

    this.listRef = null;
  }

  getView() {
    const { model, status } = this.props.controller || {},

    // The API isConsistentlyOffline is only supposed to be used to show the offline state view to the user
    // when he has been consistently offline.
    // For disabling the actions on lack of connectivity, please rely on the socket connected state itself for now.
    // Otherwise, there is a chance of data loss if we let the user perform actions
    // when we are attempting a connection.
    { isConsistentlyOffline } = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('SyncStatusStore');

    if (!pm.isScratchpad && isConsistentlyOffline && status === _common_WorkbenchStatusConstants__WEBPACK_IMPORTED_MODULE_9__["LOADING"]) {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_components_molecule__WEBPACK_IMPORTED_MODULE_11__["SidebarOfflineState"], null);
    }

    if (status === _common_WorkbenchStatusConstants__WEBPACK_IMPORTED_MODULE_9__["ERROR"]) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_components_SidebarErrorState_SidebarErrorState__WEBPACK_IMPORTED_MODULE_10__["default"], {
          title: "无法加载集合",
          description: "尝试刷新此页面或过一段时间再检查" }));


    }

    if (status === _common_WorkbenchStatusConstants__WEBPACK_IMPORTED_MODULE_9__["READY"]) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_3__["default"], { identifier: "collection" }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_CollectionSidebarListContainer_CollectionSidebarListContainer__WEBPACK_IMPORTED_MODULE_7__["default"], {
          ref: (ref) => {this.listRef = ref;},
          model: model })));



    }

    // Keeping sidebar in loading state if the `status` does not meet any of the above condition
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_sidebar_SidebarLoadingState_SidebarLoadingState__WEBPACK_IMPORTED_MODULE_6__["default"], { hasIcon: true });
  }

  focus() {
    _.invoke(this, 'listRef.__wrappedInstance.focus');
  }

  focusCollection(collectionId, CollectionSidebarContainer) {
    _.invoke(this, 'listRef.__wrappedInstance.focusCollection', collectionId, CollectionSidebarContainer);
  }

  focusNext() {
    const collection = _.head(_.get(this.props.controller, 'model.collections'));

    _.invoke(this, 'listRef.handleSelect', collection.id);
  }

  render() {
    const { model } = this.props.controller || {};

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "collection-sidebar" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "collection-sidebar-wrapper" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_CollectionSidebarMenu_CollectionSidebarMenu__WEBPACK_IMPORTED_MODULE_8__["default"], {
        model: model }),

      this.getView())));



  }}) || _class;


CollectionSidebarView.propTypes = {
  controller: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.shape({
    model: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.instanceOf(_CollectionSidebarModel__WEBPACK_IMPORTED_MODULE_5__["default"]),
    status: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf([_common_WorkbenchStatusConstants__WEBPACK_IMPORTED_MODULE_9__["ERROR"], _common_WorkbenchStatusConstants__WEBPACK_IMPORTED_MODULE_9__["READY"], _common_WorkbenchStatusConstants__WEBPACK_IMPORTED_MODULE_9__["LOADING"]]) }).
  isRequired };
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 9682:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionSidebarMenu; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2298);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2293);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2325);
/* harmony import */ var _postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1601);
/* harmony import */ var _postman_app_monolith_renderer_js_services_NavigationService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1801);
/* harmony import */ var _postman_app_monolith_renderer_js_containers_apps_requester_sidebar_SidebarListActions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9025);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2845);
/* harmony import */ var _common_WorkspaceHelpers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2287);
/* harmony import */ var _CollectionSidebarModel__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7632);
/* harmony import */ var _api_CollectionInterface__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2369);
/* harmony import */ var _common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4181);
var _class;












const NEW_COLLECTION_CLICK_THROTTLE_TIMEOUT = 1000; // 1 sec
let

CollectionSidebarMenu = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class CollectionSidebarMenu extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = { isCollectionCreateEnabled: true };

    this.handleNewCollectionClick = this.handleNewCollectionClick.bind(this);
    this.handleSearchChange = this.handleSearchChange.bind(this);
  }

  handleNewCollectionClick() {
    // Disable the create collection button for the defined timeout to prevent
    // a lot of collection creates in a short ammount of time
    this.setState({ isCollectionCreateEnabled: false });

    // Enable after the timeout has elapsed
    //
    // Cancel any pending timeout before setting a new timeout
    this.timeoutId && clearTimeout(this.timeoutId);
    this.timeoutId = setTimeout(
    () => {this.setState({ isCollectionCreateEnabled: true });},
    NEW_COLLECTION_CLICK_THROTTLE_TIMEOUT);


    Object(_api_CollectionInterface__WEBPACK_IMPORTED_MODULE_10__["createCollection"])();
  }

  handleTrashOpen() {
    if (!Object(_common_WorkspaceHelpers__WEBPACK_IMPORTED_MODULE_8__["isWorkspaceMember"])()) {
      if (Object(_common_WorkspaceHelpers__WEBPACK_IMPORTED_MODULE_8__["canJoinWorkspace"])()) {
        return pm.mediator.trigger('openUnjoinedWorkspaceModal');
      }

      if (!Object(_common_WorkspaceHelpers__WEBPACK_IMPORTED_MODULE_8__["isLoggedIn"])()) {
        return pm.mediator.trigger('showSignInModal', {
          type: 'trash',
          origin: 'open_trash' });

      }
    }

    _postman_app_monolith_renderer_js_services_NavigationService__WEBPACK_IMPORTED_MODULE_5__["default"].transitionTo('trash');
  }

  handleSearchChange(query) {
    this.props.model && this.props.model.setSearchQuery(query);
  }

  render() {
    const permissionStore = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('PermissionStore'),
    workspaceId = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('ActiveWorkspaceStore').id,
    canAddCollection = permissionStore.can('addCollection', 'workspace', workspaceId),
    { userCanSave } = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('OnlineStatusStore'),
    isCollectionCreateEnabled = userCanSave && canAddCollection && this.state.isCollectionCreateEnabled,
    isOffline = !Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('SyncStatusStore').isSocketConnected,
    disableTrash = Object(_common_WorkspaceHelpers__WEBPACK_IMPORTED_MODULE_8__["isLoggedIn"])() && !(Object(_common_WorkspaceHelpers__WEBPACK_IMPORTED_MODULE_8__["isWorkspaceMember"])() || Object(_common_WorkspaceHelpers__WEBPACK_IMPORTED_MODULE_8__["canJoinWorkspace"])()) || isOffline;

    let tooltipMessage = disableTrash ? '只有此工作区的成员才能恢复已删除的集合' : '恢复已删除的集合';

    tooltipMessage = isOffline ? '重新联网后即可执行此操作' : tooltipMessage;

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "collection-sidebar-menu" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_containers_apps_requester_sidebar_SidebarListActions__WEBPACK_IMPORTED_MODULE_6__["default"], {
        createNewConfig: {
          tooltip: userCanSave ?
          canAddCollection ?
          '创建新的集合' :
          '您没有权限在此工作区中创建集合.' :

          _common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_11__["DISABLED_TOOLTIP_IS_OFFLINE"],
          disabled: !isCollectionCreateEnabled,
          onCreate: this.handleNewCollectionClick,
          xPathIdentifier: 'addCollection' },

        onSearch: this.handleSearchChange,
        searchQuery: _.get(this.props.model, 'searchQuery'),
        moreActions: /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["DropdownMenu"], null, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["MenuItem"], null, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_3__["Button"], {
          onClick: this.handleTrashOpen,
          tooltip: pm.isScratchpad ? '您需要在工作区中才能打开回收站' : tooltipMessage,
          disabled: pm.isScratchpad || disableTrash,
          type: "text",
          className: "collection-sidebar-menu__actions-trash" }, "打开回收站"))) })));









  }}) || _class;


CollectionSidebarMenu.propTypes = {
  model: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.instanceOf(_CollectionSidebarModel__WEBPACK_IMPORTED_MODULE_9__["default"]).isRequired };
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 9683:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SidebarErrorState; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2298);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2293);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2325);
var _class;


let


SidebarErrorState = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class SidebarErrorState extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.renderButton = this.renderButton.bind(this);
  }

  renderButton() {
    if (this.props.buttonText) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_3__["Button"], {
          type: "secondary",
          onClick: this.props.handler },

        this.props.buttonText));


    }
  }

  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "sidebar-error-wrapper" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "sidebar-error-thumbnail" }), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "sidebar-error-content-container" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "sidebar-error-header" }, this.props.title), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "sidebar-error-content" },
      this.props.description),

      this.renderButton())));



  }}) || _class;


SidebarErrorState.defaultProps = {
  description: null,
  buttonText: null,
  handler: _.noop };


SidebarErrorState.propTypes = {
  title: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string.isRequired,
  description: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  buttonText: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  handler: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func };
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ })

}]);