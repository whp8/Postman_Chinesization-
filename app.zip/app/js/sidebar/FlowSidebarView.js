(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[38],{

/***/ 9728:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const lodash_1 = __webpack_require__(515);
const mobx_react_1 = __webpack_require__(2293);
const react_1 = __importStar(__webpack_require__(2));
const aether_1 = __webpack_require__(9);
const molecule_1 = __webpack_require__(4068);
const SidebarListActions_1 = __importDefault(__webpack_require__(9025));
const SidebarEmptyState_1 = __importDefault(__webpack_require__(9027));
const SidebarLoadingState_1 = __importDefault(__webpack_require__(7771));
const get_store_1 = __webpack_require__(1601);
const FlowSidebarContainer_1 = __importDefault(__webpack_require__(9729));
const FlowInterface_1 = __webpack_require__(8063);
let FlowSidebarView = class FlowSidebarView extends react_1.Component {
    getToolTip(isReadOnly) {
        if (isReadOnly) {
            return '重新联网后即可执行此操作';
        }
        return '创建新流';
    }
    getView() {
        var _a;
        const { controller } = this.props, { isConsistentlyOffline } = get_store_1.getStore('SyncStatusStore');
        if (isConsistentlyOffline) {
            return react_1.default.createElement(molecule_1.SidebarOfflineState, null);
        }
        if (!controller.model || controller.model.isLoading) {
            return react_1.default.createElement(SidebarLoadingState_1.default, { hasIcon: true });
        }
        const showPublicWorkspaceMessage = get_store_1.getStore('ActiveWorkspaceStore').visibilityStatus === 'public' && controller.model.isReadOnlyByPermission, tryOtherWorkspace = '同时, 您可以在其他工作区中尝试流.', flowMessage = '流通过逻辑连接请求来帮助您测试实际流程.', message = showPublicWorkspaceMessage ? tryOtherWorkspace.concat(flowMessage) : flowMessage;
        if (lodash_1.isEmpty(controller.model.items) || showPublicWorkspaceMessage) {
            if (lodash_1.isEmpty(controller.model.searchQuery)) {
                return (react_1.default.createElement(SidebarEmptyState_1.default, { illustration: react_1.default.createElement(aether_1.IllustrationCreateFlow, null), title: showPublicWorkspaceMessage ? '即将进入公共工作区' : '创建您的第一个流', message: message, action: !showPublicWorkspaceMessage && {
                        label: '创建流',
                        handler: () => FlowInterface_1.createNewFlow()
                    }, hasPermissions: !((_a = controller.model) === null || _a === void 0 ? void 0 : _a.isReadOnly) }));
            }
        }
        return react_1.default.createElement(FlowSidebarContainer_1.default, { model: controller.model });
    }
    render() {
        var _a, _b, _c;
        const { controller } = this.props;
        return (react_1.default.createElement(react_1.default.Fragment, null,
            react_1.default.createElement(SidebarListActions_1.default, { createNewConfig: {
                    tooltip: this.getToolTip((_a = controller.model) === null || _a === void 0 ? void 0 : _a.isReadOnly),
                    onCreate: () => FlowInterface_1.createNewFlow(),
                    disabled: ((_b = controller.model) === null || _b === void 0 ? void 0 : _b.isReadOnly)
                }, onSearch: (q) => { var _a; return (_a = controller.model) === null || _a === void 0 ? void 0 : _a.setSearchQuery(q); }, searchQuery: (_c = controller.model) === null || _c === void 0 ? void 0 : _c.searchQuery }),
            this.getView()));
    }
};
FlowSidebarView = __decorate([
    mobx_react_1.observer
], FlowSidebarView);
exports.default = FlowSidebarView;


/***/ }),

/***/ 9729:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const mobx_react_1 = __webpack_require__(2293);
const react_1 = __importStar(__webpack_require__(2));
const aether_1 = __webpack_require__(9);
const react_virtualized_auto_sizer_1 = __importDefault(__webpack_require__(5127));
const react_window_1 = __webpack_require__(3699);
const styled_components_1 = __importDefault(__webpack_require__(37));
const lodash_1 = __webpack_require__(515);
const SidebarListItem_1 = __importDefault(__webpack_require__(9023));
const FlowInterface_1 = __webpack_require__(8063);
const Dropdowns_1 = __webpack_require__(2845);
const NavigationService_1 = __importDefault(__webpack_require__(1801));
const SidebarNoResultsFound_1 = __importDefault(__webpack_require__(8228));
const KeyMaps_1 = __importDefault(__webpack_require__(2314));
const ShortcutsList_1 = __webpack_require__(4332);
const Container = styled_components_1.default.div `
  display: flex;
  flex-direction:column;
  flex: 1;

  >.sidebar-list-item {
    flex: unset;
  }
`, OVERSCAN_COUNT = 10, DEFAULT_ITEM_HEIGHT = 28;
let FlowSidebarContainer = class FlowSidebarContainer extends react_1.Component {
    getActionsMenu() {
        return (react_1.default.createElement(Dropdowns_1.DropdownMenu, { "align-right": true },
            react_1.default.createElement(Dropdowns_1.MenuItem, { key: 'delete', refKey: 'delete', disabled: this.props.model.isReadOnly, disabledText: this.props.model.getDisabledText() },
                react_1.default.createElement("div", { className: 'dropdown-menu-item-label' }, "删除"),
                react_1.default.createElement("div", { className: 'dropdown-menu-item-shortcut' }, ShortcutsList_1.getShortcutByName('delete')))));
    }
    getKeyMapHandlers(item) {
        return {
            delete: pm.shortcuts.handle('delete', () => { this.props.model.handleAction('delete', item); })
        };
    }
    getListItem({ style, index }) {
        const { model, model: { items } } = this.props, item = lodash_1.get(items, index);
        if (!item) {
            return null;
        }
        const { id, state: { name } } = item;
        return (react_1.default.createElement(KeyMaps_1.default, { handlers: this.getKeyMapHandlers(item) },
            react_1.default.createElement("div", { style: style, key: id },
                react_1.default.createElement(SidebarListItem_1.default, { text: name, onClick: () => FlowInterface_1.openFlowInWorkbench(id), moreActions: this.getActionsMenu(), onActionsDropdownSelect: (action) => model.handleAction(action, item), isSelected: NavigationService_1.default.isActive('build.flow', { fid: id }) }))));
    }
    render() {
        const { model } = this.props, itemLength = model.items.length;
        return (react_1.default.createElement(Container, null,
            react_1.default.createElement(react_virtualized_auto_sizer_1.default, null, ({ height, width }) => (react_1.default.createElement(react_window_1.FixedSizeList, { height: height, width: width, itemCount: itemLength, itemSize: DEFAULT_ITEM_HEIGHT, overscanCount: OVERSCAN_COUNT }, (data) => (react_1.default.createElement(mobx_react_1.Observer, null, this.getListItem.bind(this, data)))))),
            lodash_1.isEmpty(model.items) && !lodash_1.isEmpty(model.searchQuery) && (react_1.default.createElement(SidebarNoResultsFound_1.default, { searchQuery: model.searchQuery, illustration: react_1.default.createElement(aether_1.IllustrationCreateFlow, null) }))));
    }
};
FlowSidebarContainer = __decorate([
    mobx_react_1.observer
], FlowSidebarContainer);
exports.default = FlowSidebarContainer;


/***/ })

}]);