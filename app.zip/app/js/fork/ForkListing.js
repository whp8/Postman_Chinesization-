(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[44],{

/***/ 9747:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ForkListing; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(37);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(755);
/* harmony import */ var querystring__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(querystring__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1601);
/* harmony import */ var _appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2862);
/* harmony import */ var _ForkListBody__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9748);
/* harmony import */ var _js_modules_services_RemoteSyncRequestService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1798);









const ForkList = styled_components__WEBPACK_IMPORTED_MODULE_1__["default"].div`
  overflow-y: auto;
`;

const forkListConfig = {
  length: 12,
  sortBy: 'createdAt',
  sortType: 'desc' };


const storeMap = {
  'environment': 'EnvironmentStore',
  'collection': 'CollectionStore' };


/**
 * Fork Listing
 *
 * @param {Object} props
 */
function ForkListing(props) {
  const [forks, setForks] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])([]);
  const [forkInfo, setForkInfo] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])({});
  const [loading, setLoading] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(true);
  const [isEmpty, setIsEmpty] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
  const [error, setError] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(null);
  const syncStatusStore = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('SyncStatusStore');
  const model = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])(storeMap[props.contextData.model]).find(props.contextData.id);
  const isOffline = !Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('SyncStatusStore').isSocketConnected;
  const queryObject = {
    populateUsers: true,
    pageSize: forkListConfig.length,
    sortBy: forkListConfig.sortBy,
    sortType: forkListConfig.sortType };

  const fetchForks = () => {
    setLoading(true);
    setError(null);

    syncStatusStore.
    onSyncAvailable({ timeout: 5000 }).
    then(() => _js_modules_services_RemoteSyncRequestService__WEBPACK_IMPORTED_MODULE_6__["default"].request(`/${props.contextData.model}/${model.uid}/fork-list?${querystring__WEBPACK_IMPORTED_MODULE_2___default.a.stringify(queryObject)}`)).
    then((res) => {
      setForks(_.get(res, 'body.data.forks'));
      setForkInfo({
        publicForks: _.get(res, 'body.data.publicForkCount'),
        privateForks: _.get(res, 'body.data.privateForkCount'),
        hiddenForks: _.get(res, 'body.data.hiddenForkCount'),
        totalForks: _.get(res, 'body.data.totalForkCount') });

      setIsEmpty(!(_.get(res, 'body.data.forks') || []).length);
      setLoading(false);
    }).
    catch((error) => {
      setError(error);
      setLoading(false);

      pm.logger.error('Unable to fetch fork list', error);
    });
  };

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    fetchForks();
  }, []);

  return /*#__PURE__*/(
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(ForkList, null, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_4__["ContextBarViewHeader"], {
      title: "分叉",
      onClose: props.onClose }), /*#__PURE__*/

    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_ForkListBody__WEBPACK_IMPORTED_MODULE_5__["default"], {
      loading: loading,
      isOffline: isOffline,
      isEmpty: isEmpty,
      error: error,
      forks: forks,
      fetchForks: fetchForks,
      forkInfo: forkInfo,
      model: model,
      modelName: props.contextData.model })));



}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 9748:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ForkListBody; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(37);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9);
/* harmony import */ var moment_timezone__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2278);
/* harmony import */ var moment_timezone__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment_timezone__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _common_TabLoader__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7048);
/* harmony import */ var _common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6930);
/* harmony import */ var _js_components_base_Avatar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4190);
/* harmony import */ var _common_TabEmptyState__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7053);
/* harmony import */ var _common_context_bar_items__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9749);
/* harmony import */ var _js_services_NavigationService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1801);
/* harmony import */ var _js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1810);
/* harmony import */ var _appsdk_components_link_Link__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2687);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2325);
/* harmony import */ var _js_utils_PluralizeHelper__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3194);
/* harmony import */ var _common_ItemLink__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7056);

















const ListItemWrapper = styled_components__WEBPACK_IMPORTED_MODULE_1__["default"].div`
  display: inline-block;
`;

const ListItemAvatar = Object(styled_components__WEBPACK_IMPORTED_MODULE_1__["default"])(_common__WEBPACK_IMPORTED_MODULE_5__["CustomTooltip"])`
  float: right;
  margin-top: var(--spacing-s);
  margin-right: var(--spacing-xxl);
`;

const HelperText = styled_components__WEBPACK_IMPORTED_MODULE_1__["default"].div`
  font-size: var(--text-size-m);
  color: var(--content-color-primary);
  font-weight: var(--text-weight-medium);
  margin-bottom: var(--spacing-m);
`;

const LinkText = styled_components__WEBPACK_IMPORTED_MODULE_1__["default"].span`
  color: var(--content-color-info);
  font-size: var(--text-size-m);
  margin-top: var(--spacing-l);
  cursor: pointer;
  padding-bottom: var(--spacing-xl);

  &:hover {
    text-decoration: underline
  }
`;

const ExternalLinkIcon = Object(styled_components__WEBPACK_IMPORTED_MODULE_1__["default"])(_postman_aether__WEBPACK_IMPORTED_MODULE_2__["Icon"])`
  position: relative;
  top: 2px;
`;

/**
 * Fork List Body
 *
 * @param {Object} props - React props
 */
function ForkListBody(props) {
  const FORK_LEARNING_CENTER_LINK = {
    collection: 'https://go.pstmn.io/docs-collection-forking',
    environment: 'https://go.pstmn.io/docs-environment-forking' };


  const EmptyStateAction = /*#__PURE__*/
  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", null, /*#__PURE__*/
  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(LinkText, { onClick: () => Object(_js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_10__["openExternalLink"])(FORK_LEARNING_CENTER_LINK[props.modelName], '_blank') }, /*#__PURE__*/
  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_2__["Text"], { type: "link-primary", isExternal: true }, "了解更多关于分叉")));



  const RetryAction = /*#__PURE__*/
  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_12__["Button"], {
    type: "primary",
    size: "small",
    onClick: props.fetchForks }, "重试");




  const forkText = _js_utils_PluralizeHelper__WEBPACK_IMPORTED_MODULE_13__["default"].pluralize({
    count: _.get(props, 'forkInfo.totalForks'),
    singular: '分叉',
    plural: '分叉' });


  if (props.loading) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_TabLoader__WEBPACK_IMPORTED_MODULE_4__["default"], null);
  } else
  if (pm.isScratchPad) {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_context_bar_items__WEBPACK_IMPORTED_MODULE_8__["ContextBarEmptyStateContainer"], null, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_TabEmptyState__WEBPACK_IMPORTED_MODULE_7__["default"], {
        illustration: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_2__["IllustrationNoFork"], null),
        title: "分叉在便笺中不可用",
        message: '检查以确保您在线,然后切换到工作区以查看分叉.' })));



  } else
  if (props.isOffline) {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_context_bar_items__WEBPACK_IMPORTED_MODULE_8__["ContextBarEmptyStateContainer"], null, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_TabEmptyState__WEBPACK_IMPORTED_MODULE_7__["default"], {
        showAction: true,
        illustration: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_2__["IllustrationCheckInternetConnection"], null),
        title: "检查您的连接",
        message: "联网查看您的分叉列表.",
        action: RetryAction })));



  } else
  if (props.error) {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_context_bar_items__WEBPACK_IMPORTED_MODULE_8__["ContextBarEmptyStateContainer"], null, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_TabEmptyState__WEBPACK_IMPORTED_MODULE_7__["default"], {
        illustration: props.isForbidden ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_2__["IllustrationNoPermission"], null) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_2__["IllustrationInternalServerError"], null),
        title: "无法加载分叉列表",
        message:
        props.isForbidden ?
        `您无法查看此${props.modelName}的分叉列表.` :
        _.get(props, 'error.error.message') || '尝试重新获取分叉' })));




  } else
  if (props.isEmpty) {
    const hiddenForksExist = Boolean(_.get(props, 'forkInfo.hiddenForks'));

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_context_bar_items__WEBPACK_IMPORTED_MODULE_8__["ContextBarEmptyStateContainer"], null, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_TabEmptyState__WEBPACK_IMPORTED_MODULE_7__["default"], {
        showAction: true,
        illustration: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_2__["IllustrationNoFork"], null),
        title:
        hiddenForksExist ?
        `${_.get(props, 'forkInfo.totalForks')} ${forkText} of ${_.get(
        props,
        'model.name')
        }` :
        '尚未创建分叉',

        message:
        hiddenForksExist ?
        '它们是不可见的,因为它们位于您无法访问的工作区中.' :
        `在此${({collection:'集合', environment:'环境'})[props.modelName] || props.modelName}中创建的所有分叉都将显示在此处.`,

        action: EmptyStateAction })));



  }

  return /*#__PURE__*/(
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_context_bar_items__WEBPACK_IMPORTED_MODULE_8__["ContextBarDescription"], null,
    _.get(props, 'forkInfo.totalForks'), " ", forkText, " of ", _.get(props, 'model.name'), ".",
    _.get(props, 'forkInfo.hiddenForks') > 0 ? ` 其中的${_.get(props, 'forkInfo.hiddenForks')}个不在此列表中,因为它们位于您无权访问的工作空间中.` : ''), /*#__PURE__*/

    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_context_bar_items__WEBPACK_IMPORTED_MODULE_8__["ContextBarContainer"], null, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(HelperText, null, "最近创建的:"),
    (props.forks || []).map((fork) => /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { key: fork.modelId }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(ListItemWrapper, null, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_components_link_Link__WEBPACK_IMPORTED_MODULE_11__["default"], {
      to: fork.modelId ? `${pm.artemisUrl}/${props.modelName}/${fork.modelId}` : '',
      disabled: !fork.modelId }, /*#__PURE__*/

    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_context_bar_items__WEBPACK_IMPORTED_MODULE_8__["ContextBarListItem"], null, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_ItemLink__WEBPACK_IMPORTED_MODULE_14__["default"], { text: fork.forkName }))), /*#__PURE__*/


    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_context_bar_items__WEBPACK_IMPORTED_MODULE_8__["ContextBarSubtext"], null,
    `创建于: ${moment_timezone__WEBPACK_IMPORTED_MODULE_3___default()(fork.createdAt).format('DD MMM, YYYY')}`)), /*#__PURE__*/


    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(ListItemAvatar, {
      align: "bottom",
      body: _.get(fork, 'createdBy.name') }, /*#__PURE__*/

    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Avatar__WEBPACK_IMPORTED_MODULE_6__["default"], {
      size: "medium",
      userId: _.get(fork, 'createdBy.id'),
      customPic: _.get(fork, 'createdBy.profilePicUrl') })))), /*#__PURE__*/




    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(LinkText, { onClick: () => _js_services_NavigationService__WEBPACK_IMPORTED_MODULE_9__["default"].transitionTo('build.forks', { model: props.modelName, id: _.get(props, 'model.uid') }) },
    _.get(props, 'forkInfo.totalForks') > (props.forks || []).length ? '查看所有分叉' : '查看详情'))));



}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 9749:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContextBarDescription", function() { return ContextBarDescription; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContextBarListItem", function() { return ContextBarListItem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContextBarSubtext", function() { return ContextBarSubtext; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContextBarContainer", function() { return ContextBarContainer; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContextBarLoading", function() { return ContextBarLoading; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContextBarEmptyStateContainer", function() { return ContextBarEmptyStateContainer; });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37);


const ContextBarDescription = styled_components__WEBPACK_IMPORTED_MODULE_0__["default"].span`
  font-size: var(--text-size-m);
  color: var(--content-color-secondary);
  font-weight: var(--text-weight-regular);
  margin-left: var(--spacing-s);
  display: flex;
`;

const ContextBarListItem = styled_components__WEBPACK_IMPORTED_MODULE_0__["default"].span`
  color: var(--content-color-primary);
  font-size: var(--text-size-m);

  &:hover {
    text-decoration: underline;
    cursor: pointer;
  }
`;

const ContextBarSubtext = styled_components__WEBPACK_IMPORTED_MODULE_0__["default"].p`
  margin-top: 0;
  margin-bottom: 0;
  color: var(--content-color-tertiary);
  font-size: var(--text-size-s);
`;

const ContextBarContainer = styled_components__WEBPACK_IMPORTED_MODULE_0__["default"].div`
  margin-left: var(--spacing-s);
  margin-top: var(--spacing-l);
  padding-bottom: var(--spacing-xl);

  div {
    margin-bottom: var(--spacing-s);
  }
`;

const ContextBarLoading = styled_components__WEBPACK_IMPORTED_MODULE_0__["default"].div`
  position: absolute;
  top: 50%;
  left: 50%;
`;

const ContextBarEmptyStateContainer = styled_components__WEBPACK_IMPORTED_MODULE_0__["default"].div`
  position: absolute;
  top: 30%;
  left: 15%;
  min-width: 300px;

  p {
    font-size: var(--text-size-m);
    color: var(--content-color-secondary);
    margin: 0;
  }
`;

/***/ })

}]);