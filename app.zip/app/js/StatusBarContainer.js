(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[74],{

/***/ 17836:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return StatusBarContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2293);
/* harmony import */ var _models_status_bar_StatusBar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(17837);
/* harmony import */ var _components_status_bar_plugins__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(17839);
/* harmony import */ var _plugins_PluginInterface__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(17838);
/* harmony import */ var _components_status_bar_base_Item__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(17861);
/* harmony import */ var _components_status_bar_base_Text__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(17862);
/* harmony import */ var _components_status_bar_base_Icon__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(17863);
/* harmony import */ var _components_status_bar_base_Pane__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(17864);
/* harmony import */ var _components_status_bar_base_Drawer__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(17865);
/* harmony import */ var _runtime_repl_request_http_RequesterTabLayoutConstants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4328);
/* harmony import */ var _components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2856);
var _class;















let PluginEnvironment = {
  React: (react__WEBPACK_IMPORTED_MODULE_0___default()),
  PluginInterface: _plugins_PluginInterface__WEBPACK_IMPORTED_MODULE_4__["default"],
  StatusBarComponents: {
    Item: _components_status_bar_base_Item__WEBPACK_IMPORTED_MODULE_5__["default"],
    Text: _components_status_bar_base_Text__WEBPACK_IMPORTED_MODULE_6__["default"],
    Icon: _components_status_bar_base_Icon__WEBPACK_IMPORTED_MODULE_7__["default"],
    Pane: _components_status_bar_base_Pane__WEBPACK_IMPORTED_MODULE_8__["default"],
    Drawer: _components_status_bar_base_Drawer__WEBPACK_IMPORTED_MODULE_9__["default"] },

  constants: {
    layout: {
      REQUESTER_TAB_LAYOUT_1_COLUMN: _runtime_repl_request_http_RequesterTabLayoutConstants__WEBPACK_IMPORTED_MODULE_10__["REQUESTER_TAB_LAYOUT_1_COLUMN"],
      REQUESTER_TAB_LAYOUT_2_COLUMN: _runtime_repl_request_http_RequesterTabLayoutConstants__WEBPACK_IMPORTED_MODULE_10__["REQUESTER_TAB_LAYOUT_2_COLUMN"] } } };let





StatusBarContainer = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class StatusBarContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      items: [],
      activeItem: null };


    this.addItem = this.addItem.bind(this);
    this.addItems = this.addItems.bind(this);
    this.toggleActive = this.toggleActive.bind(this);
    this.items = null;
  }

  componentDidMount() {
    _models_status_bar_StatusBar__WEBPACK_IMPORTED_MODULE_2__["default"].initialize();
    _models_status_bar_StatusBar__WEBPACK_IMPORTED_MODULE_2__["default"].loadPlugins(_components_status_bar_plugins__WEBPACK_IMPORTED_MODULE_3__["default"]);
  }

  UNSAFE_componentWillMount() {
    _models_status_bar_StatusBar__WEBPACK_IMPORTED_MODULE_2__["default"].on('loadedPlugins', this.addItems);
    _models_status_bar_StatusBar__WEBPACK_IMPORTED_MODULE_2__["default"].on('add', this.addItem);
  }

  componentWillUnmount() {
    _models_status_bar_StatusBar__WEBPACK_IMPORTED_MODULE_2__["default"].off('loadedPlugins', this.addItems);
    _models_status_bar_StatusBar__WEBPACK_IMPORTED_MODULE_2__["default"].off('add', this.addItem);
    this.items = null;
  }

  addItem(item) {
    this.items.push({
      item: item,
      component: item.getComponent(PluginEnvironment) });

    let items = _.concat(this.state.items, item);
    this.setState({ items });
  }

  addItems(items) {
    this.items = _.map(_components_status_bar_plugins__WEBPACK_IMPORTED_MODULE_3__["default"], (item) => {
      return {
        item: item,
        component: item.getComponent(PluginEnvironment) };

    });
    this.setState({ items });
  }

  toggleActive(item) {
    this.setState({ activeItem: this.state.activeItem === item ? null : item });
  }

  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_11__["default"], { identifier: "statusBar" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "status-bar-container status-bar" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "sb-section" },

      _.map(this.items, (item, index) => {
        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(item.component, {
          key: index,
          isOpen: _.isEqual(this.state.activeItem, item.item.name),
          toggleActive: this.toggleActive.bind(this, item.item.name) });

      })))));





  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 17837:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var events__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(661);
/* harmony import */ var events__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(events__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _plugins_PluginInterface__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17838);



class StatusBar extends events__WEBPACK_IMPORTED_MODULE_0___default.a {
  constructor() {
    super();
  }

  initialize() {
    _plugins_PluginInterface__WEBPACK_IMPORTED_MODULE_1__["default"].initialize();
  }

  register(property, handler, context) {
    this.properties[property] &&
    this.properties[property].handler(context, handler);
  }

  loadPlugins(plugins) {
    this.emit('loadedPlugins', plugins);
  }

  addItem(sbItem) {
    this.emit('add', sbItem);
    sbItem.initialize && sbItem.initialize();
  }}


/* harmony default export */ __webpack_exports__["default"] = (new StatusBar());

/***/ }),

/***/ 17838:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1595);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3174);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1601);
/* harmony import */ var _services_EditorService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2250);
/* harmony import */ var _external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1810);
/* harmony import */ var _runtime_repl_request_http_RequesterBottomPaneConstants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4896);
/* harmony import */ var _services_NavigationService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1801);










class PluginInterface {
  initialize() {
    this.properties = {
      layout: {
        value: Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('ConfigurationStore').get('editor.requestEditorLayoutName'),
        registerer: function (context, cb) {
          Object(mobx__WEBPACK_IMPORTED_MODULE_0__["reaction"])(() => Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('ConfigurationStore').get('editor.requestEditorLayoutName'), cb.bind(context));
        } },

      theme: {
        value: pm.settings.getSetting('postmanTheme') || 'light',
        registerer: function (context, cb) {
          pm.settings.on('setSetting:postmanTheme', cb, context);
        } },

      platform: {
        value: navigator.platform,
        registerer: _.noop },

      windows: {
        value: [],
        registerer: function (context, cb) {
          pm.appWindow.on('windowClosed', cb.bind(context, 'windowClosed'), context);
        } },

      modals: {
        value: null,
        registerer: function (context, cb) {
          pm.mediator.on('modalOpened', cb.bind(context, 'modalOpened'), context);
          pm.mediator.on('modalClosed', cb.bind(context, 'modalClosed'), context);
        } },

      xFlows: {
        value: null,
        registerer: function (context, cb) {
          pm.mediator.on('saveXFlowActivity', cb.bind(context), context);
        } } };


  }

  register(property, handler, context) {
    this.properties[property] &&
    this.properties[property].registerer(context, handler);
  }

  get(key) {
    return _.get(this, `properties[${key}].value`);
  }

  openWindow(windowType) {
    switch (windowType) {
      case 'requester':
        pm.mediator.trigger('newRequesterWindow');
        break;
      case 'console':
        pm.mediator.trigger('newConsoleWindow');
        break;
      default:
        break;}

  }

  toggleTwoPaneLayout() {
    pm.app.toggleLayout();
  }

  openURL(url) {
    Object(_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_4__["openExternalLink"])(url);
  }

  openModal(modalName, options) {
    switch (modalName) {
      case 'settings':
        // open the settings modal via navigation
        pm.mediator.trigger('openSettingsModal', options.tab);
        break;
      case 'release-notes':
        _services_EditorService__WEBPACK_IMPORTED_MODULE_3__["default"].open('customview://releaseNotes');
        break;
      case 'x-flow-activity-feed':
        pm.mediator.trigger('openXFlowActivityFeed');
        break;
      default:
        break;}

  }

  toggleSidebar() {
    pm.mediator.trigger('toggleSidebar');
  }

  toggleFindReplace() {
    const store = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('RequesterBottomPaneUIStore');

    store && store.toggleTab(_runtime_repl_request_http_RequesterBottomPaneConstants__WEBPACK_IMPORTED_MODULE_5__["REQUESTER_BOTTOM_PAME_FIND_REPLACE"]);
  }

  toggleConsole() {
    const store = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('RequesterBottomPaneUIStore');

    store && store.toggleTab(_runtime_repl_request_http_RequesterBottomPaneConstants__WEBPACK_IMPORTED_MODULE_5__["REQUESTER_BOTTOM_PANE_CONSOLE"]);
  }}


/* harmony default export */ __webpack_exports__["default"] = (new PluginInterface());
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 17839:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Help__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(17840);
/* harmony import */ var _onboarding_src_features_Skills_Bootcamp_components_BootcampLauncher__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17841);
/* harmony import */ var _AgentSelection__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(17842);
/* harmony import */ var _BrowserActiveTrackSelection__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(17845);
/* harmony import */ var _WebSocketProxySelection__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(17856);
/* harmony import */ var _constants_TrackSupportConstants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(17858);
/* harmony import */ var _Trash__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(17859);
/* harmony import */ var _Runner__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(17866);
/* harmony import */ var _TwoPane__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(17867);
/* harmony import */ var _Copyright__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(17870);











let pluginsToAdd = [
_Help__WEBPACK_IMPORTED_MODULE_0__["default"],
_TwoPane__WEBPACK_IMPORTED_MODULE_8__["default"],
_Trash__WEBPACK_IMPORTED_MODULE_6__["default"],
_Runner__WEBPACK_IMPORTED_MODULE_7__["default"],
_AgentSelection__WEBPACK_IMPORTED_MODULE_2__["default"],
_onboarding_src_features_Skills_Bootcamp_components_BootcampLauncher__WEBPACK_IMPORTED_MODULE_1__["default"],
_Copyright__WEBPACK_IMPORTED_MODULE_9__["default"]];


if (window.SDK_PLATFORM === 'browser' && _constants_TrackSupportConstants__WEBPACK_IMPORTED_MODULE_5__["TRACK_SUPPORTED_CHANNELS"].has(window.RELEASE_CHANNEL)) {
  pluginsToAdd.push(_BrowserActiveTrackSelection__WEBPACK_IMPORTED_MODULE_3__["default"]);
  pluginsToAdd.push(_WebSocketProxySelection__WEBPACK_IMPORTED_MODULE_4__["default"]);
}

/* harmony default export */ __webpack_exports__["default"] = (pluginsToAdd);

/***/ }),

/***/ 17840:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3174);
function _extends() {_extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};return _extends.apply(this, arguments);}


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'Help',
  position: 'right',

  getComponent: function ({
    React,
    PluginInterface,
    StatusBarComponents })
  {
    class Help extends React.Component {
      constructor(props) {
        super(props);
      }

      handleItemSelect(item) {
        switch (item) {
          case 'releases':
            PluginInterface.openModal('release-notes');
            break;
          case 'shortcuts':
            PluginInterface.openModal('settings', { tab: 'shortcuts' });
            break;
          case 'docs':
            PluginInterface.openURL(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_1__["DOCS_URL"]);
            break;
          case 'security':
            PluginInterface.openURL(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_1__["DOCS_SECURITY_URL"]);
            break;
          case 'support':
            PluginInterface.openURL(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_1__["SUPPORT_URL"]);
            break;
          case 'twitter':
            PluginInterface.openURL(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_1__["TWITTER_URL"]);
            break;
          case 'community':
            PluginInterface.openURL(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_1__["POSTMAN_COMMUNITY"]);
            break;
          default:
            break;}

      }

      getIcon() {
        return /*#__PURE__*/(
          React.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_0__["Icon"], { name: "icon-state-help-stroke", size: "small" }));

      }

      render() {
        let { Item, Icon, Drawer } = StatusBarComponents;

        return /*#__PURE__*/(
          React.createElement(Item, _extends({
            className: "plugin__help",
            tooltip: "帮助和反馈" },
          this.props), /*#__PURE__*/

          React.createElement(Drawer, {
            className: "plugin__help__drawer",
            button: () => {
              return /*#__PURE__*/(
                React.createElement(Icon, {
                  className: "plugin__help__icon",
                  icon: this.getIcon() }));


            },
            onSelect: this.handleItemSelect,
            items: [
            ...(window.SDK_PLATFORM !== 'browser' ? [{
              key: 'releases',
              label: '发行说明' }] :
            []),
            {
              key: 'docs',
              label: '文档' },

            {
              key: 'security',
              label: '安全' },

            {
              key: 'support',
              label: '支持' },

            {
              key: 'twitter',
              label: '@getpostman' },

            {
              key: 'community',
              label: '社区' },

            {
              key: 'shortcuts',
              label: '键盘快捷键' }] })));





      }}


    return Help;
  } });

/***/ }),

/***/ 17841:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9);
/* harmony import */ var _LessonConstants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4956);
/* harmony import */ var _common_apis_APIService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2277);
/* harmony import */ var _Spinner__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8072);
/* harmony import */ var _LessonController__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4921);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2325);
/* harmony import */ var _common_dependencies__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2249);
/* harmony import */ var _js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2856);
/* harmony import */ var _js_components_base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3346);















const defaultState = {
  dismissable: false,
  currentState: null,
  label: '训练营',
  pausedLessonId: null,
  isLoadingLesson: false },

HIGHLIGHT_STATE = 'highlight';

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'learningCenter',
  position: 'right',

  getComponent: function ({
    React,
    StatusBarComponents })
  {
    return class LearningCenter extends React.Component {
      constructor(props) {
        super(props);
        this.state = defaultState;

        this.handleReset = this.handleReset.bind(this);
        this.handleContinue = this.handleContinue.bind(this);
        this.handleClick = this.handleClick.bind(this);
        this.handleHighlightLessonButton = this.handleHighlightLessonButton.bind(this);
        _common_dependencies__WEBPACK_IMPORTED_MODULE_7__["UIEventService"].subscribe(_LessonConstants__WEBPACK_IMPORTED_MODULE_2__["LESSON_PAUSED"], this.handleContinue);
        _common_dependencies__WEBPACK_IMPORTED_MODULE_7__["UIEventService"].subscribe('highlightLessonButton', this.handleHighlightLessonButton);
        _common_dependencies__WEBPACK_IMPORTED_MODULE_7__["UIEventService"].subscribe(_common_dependencies__WEBPACK_IMPORTED_MODULE_7__["OPEN_LESSON_PLAN"], this.openBootcampPage);
      }

      openBootcampPage() {
        _common_dependencies__WEBPACK_IMPORTED_MODULE_7__["NavigationService"].transitionTo('bootcamp');
      }

      continuePausedLesson() {
        this.setState({ isLoadingLesson: true, label: '课程加载中' });

        Object(_common_apis_APIService__WEBPACK_IMPORTED_MODULE_3__["fetchLesson"])(this.state.pausedLessonId, (lesson) => {
          if (_.isEmpty(lesson)) {
            return;
          }
          _LessonController__WEBPACK_IMPORTED_MODULE_5__["default"].continueLesson(lesson);
          _common_dependencies__WEBPACK_IMPORTED_MODULE_7__["UIEventService"].subscribe('lessonPopoverTriggered', () => {
            this.setState({ isLoadingLesson: false, label: '训练营' });
          }, { once: true });
        });
        this.setState({ pausedLessonId: null, currentState: null, dismissable: false });
      }

      handleClick() {
        if (this.state.pausedLessonId) {
          this.continuePausedLesson();
          return;
        }
        let currentUser = Object(_common_dependencies__WEBPACK_IMPORTED_MODULE_7__["getStore"])('CurrentUserStore'),
        isLoggedIn = currentUser && currentUser.isLoggedIn;

        if (!isLoggedIn) {
          pm.mediator.trigger('showSignInModal', {
            title: '提高您的Postman技能',
            subtitle: '通过交互式教程了解Postman内部的不同功能并提高技能. 请创建一个账户以继续.',
            renderIcon: this.renderIcon,
            onAuthentication: this.openBootcampPage,
            origin: 'learning_center' });

          return;
        }

        this.openBootcampPage();
        this.handleReset();
      }

      renderIcon() {
        return /*#__PURE__*/React.createElement("div", { className: "learning-center-empty-state-icon" });
      }

      handleReset(e) {
        e && e.stopPropagation();
        this.setState(defaultState);
      }

      handleContinue(pausedLessonId) {
        this.setState({
          dismissable: true,
          currentState: HIGHLIGHT_STATE,
          label: '继续学习',
          pausedLessonId });

      }

      handleHighlightLessonButton() {
        this.setState({
          currentState: HIGHLIGHT_STATE,
          label: '训练营' });

      }

      render() {

        if (pm.isScratchpad) {
          return null;
        }

        let { Item, Text } = StatusBarComponents;

        return /*#__PURE__*/(
          React.createElement(Item, {
            className: "plugin__learningCenter",
            tooltip: "学习中心" }, /*#__PURE__*/

          React.createElement(Text, {
            render: () => {
              return /*#__PURE__*/(
                React.createElement(_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_8__["default"], { identifier: "learningCenter" }, /*#__PURE__*/
                React.createElement("div", {
                  className: classnames__WEBPACK_IMPORTED_MODULE_0___default()(
                  { 'loading': this.state.isLoadingLesson },
                  { 'highlight': this.state.currentState },
                  'learning-center-button'),

                  onClick: this.handleClick },

                this.state.isLoadingLesson ? /*#__PURE__*/React.createElement(_Spinner__WEBPACK_IMPORTED_MODULE_4__["default"], null) : /*#__PURE__*/
                React.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["Icon"], {
                  name: "icon-descriptive-bootcamp-stroke",
                  className: "pm-icon",
                  color: this.state.currentState && 'content-color-brand',
                  size: "small" }), /*#__PURE__*/

                React.createElement("span", { className:
                  classnames__WEBPACK_IMPORTED_MODULE_0___default()(
                  { 'dismissable': this.state.dismissable },
                  'learning-center-label') },


                this.state.label),


                this.state.dismissable && /*#__PURE__*/
                React.createElement("div", {
                  className: "pm-icon",
                  onClick: this.handleReset }, /*#__PURE__*/

                React.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["Icon"], {
                  name: "icon-action-close-stroke",
                  color: this.state.currentState && 'content-color-brand',
                  size: "small" })))));






            } })));



      }};

  } });
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 17842:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2293);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9);
/* harmony import */ var _components_base_Icons_RunIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(17843);
/* harmony import */ var _components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2856);
/* harmony import */ var _base_Tooltips__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2326);
/* harmony import */ var _runtime_repl_agent_AgentSelectionContainer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(17844);
/* harmony import */ var _runtime_repl_agent_AgentConstants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4186);












/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'AgentSelection',
  position: 'right',

  getComponent: function ({
    React,
    PluginInterface,
    StatusBarComponents })
  {var _class;
    return Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class AgentSelection extends React.Component {
      constructor(props) {
        super(props);

        this.state = {
          isOpen: false };


        this.handleOpen = this.handleOpen.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.handleClick = this.handleClick.bind(this);
      }

      handleOpen() {
        this.setState({ isOpen: true });
      }

      handleClose() {
        this.setState({ isOpen: false });
      }

      handleClick() {
        this.setState(({ isOpen }) => ({ isOpen: !isOpen }));
      }

      UNSAFE_componentWillMount() {
        pm.mediator.on('showAgentSelectionPopover', this.handleOpen);
      }

      componentWillUnmount() {
        pm.mediator.off('showAgentSelectionPopover', this.handleOpen);
      }

      render() {
        if (!(window.SDK_PLATFORM === 'browser')) {
          return null;
        }

        let { Item, Text } = StatusBarComponents;
        const { type: agentType } = pm.runtime.agent.stat,
        agentTypeName = _runtime_repl_agent_AgentConstants__WEBPACK_IMPORTED_MODULE_8__["FRIENDLY_TYPES"][agentType],
        hasError = !pm.runtime.agent.isReady,
        agentLabel = pm.runtime.agent.autoMode ?
        '自动选择代理' :
        _runtime_repl_agent_AgentConstants__WEBPACK_IMPORTED_MODULE_8__["SETTING_VALUES"][agentTypeName.toUpperCase()].label + ' 代理';

        return /*#__PURE__*/(
          React.createElement(_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_5__["default"], { identifier: "runtime-agent" }, /*#__PURE__*/
          React.createElement("div", { ref: (ref) => {this.containerRef = ref;} }, /*#__PURE__*/
          React.createElement(Item, {
            className: "plugin__agent-selection-shortcut" }, /*#__PURE__*/

          React.createElement(Text, {
            render: () => {
              return /*#__PURE__*/(
                React.createElement("div", {
                  className: "agent-selection-icon",
                  onClick: this.handleClick },

                hasError ? /*#__PURE__*/
                React.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_3__["Icon"], {
                  className: "agent-selection-icon-error",
                  name: "icon-state-error-stroke",
                  color: "content-color-error",
                  size: "small" }) : /*#__PURE__*/


                React.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_3__["Icon"], {
                  className: "agent-selection-icon-success",
                  name: "icon-state-success-stroke",
                  color: "content-color-success",
                  size: "small" }), /*#__PURE__*/


                React.createElement("span", { className: "agent-selection-label" },
                agentLabel)));



            } })), /*#__PURE__*/


          React.createElement(_base_Tooltips__WEBPACK_IMPORTED_MODULE_6__["Tooltip"], {
            className: `agent-selection-details__${pm.runtime.agent.autoMode ? _runtime_repl_agent_AgentConstants__WEBPACK_IMPORTED_MODULE_8__["AUTOMATIC_SELECTION_SETTING_KEY"] : agentTypeName}`,
            show: this.state.isOpen,
            target: this.containerRef,
            placement: "top-right",
            immediate: true }, /*#__PURE__*/

          React.createElement(_runtime_repl_agent_AgentSelectionContainer__WEBPACK_IMPORTED_MODULE_7__["default"], { onClose: this.handleClose })))));





      }}) || _class;

  } });

/***/ }),

/***/ 17843:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return RunIcon; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2320);
function _extends() {_extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};return _extends.apply(this, arguments);}


const icon = /*#__PURE__*/
react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("svg", { width: "8", height: "10", viewBox: "0 0 16 16" }, /*#__PURE__*/
react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("defs", null, /*#__PURE__*/
react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("path", { id: "run", d: "M11.852 7.726L4.43 3.044a.264.264 0 0 0-.29-.002.319.319 0 0 0-.141.275v9.366a.319.319 0 0 0 .142.275c.09.057.2.056.289-.002l7.42-4.682A.317.317 0 0 0 12 8a.317.317 0 0 0-.148-.274z" })), /*#__PURE__*/

react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("use", { fill: "#282828", fillRule: "evenodd", xlinkHref: "#run" }));



function RunIcon(props) {
  return /*#__PURE__*/(
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], _extends({},
    props, {
      icon: icon })));


}

/***/ }),

/***/ 17844:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return AgentSelectionContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2298);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2293);
/* harmony import */ var _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2327);
/* harmony import */ var _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_postman_react_click_outside__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9);
/* harmony import */ var _postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1601);
/* harmony import */ var _postman_app_monolith_renderer_js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1810);
/* harmony import */ var _postman_app_monolith_renderer_js_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3174);
/* harmony import */ var _postman_app_monolith_renderer_js_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4332);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2325);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_ToggleSwitch__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4396);
/* harmony import */ var _AgentConstants__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4186);
/* harmony import */ var _common_components_molecule__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4068);
var _class;















let



AgentSelectionContainer = _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_4___default()(_class = Object(mobx_react__WEBPACK_IMPORTED_MODULE_3__["observer"])(_class = class AgentSelectionContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleAgentSelect = this.handleAgentSelect.bind(this);
    this.handleAgentOnboardingOpen = this.handleAgentOnboardingOpen.bind(this);
    this.handleLinkClick = this.handleLinkClick.bind(this);
    this.handleDesktopAgentLinkCLick = this.handleDesktopAgentLinkCLick.bind(this);
    this.handleClickOutside = this.handleClickOutside.bind(this);
    this.handleAutomaticSelectToggle = this.handleAutomaticSelectToggle.bind(this);
  }

  getDescriptionForDesktopAgent(isSafari, isCloudAgentEnabled) {
    if (isSafari) {
      return 'Safari不支持桌面代理. 尝试切换浏览器或改用浏览器代理.';
    }

    if (!isCloudAgentEnabled) {
      return '桌面代理使您可以毫不打扰地发送请求.';
    }

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, "通过本地运行的Postman发送请求",

      ' ', /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", { className: "details__link", onClick: this.handleDesktopAgentLinkCLick }, "桌面代理"), "."));



  }

  handleClickOutside(e) {
    e && e.stopPropagation();
    this.props.onClose();
  }

  handleLinkClick() {
    Object(_postman_app_monolith_renderer_js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_7__["openExternalLink"])(_postman_app_monolith_renderer_js_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_8__["POSTMAN_AGENTS"], '_blank');
  }

  handleDesktopAgentLinkCLick() {
    Object(_postman_app_monolith_renderer_js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_7__["openExternalLink"])(_postman_app_monolith_renderer_js_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_8__["POSTMAN_DESKTOP_AGENT_DOCS"], '_blank');
  }

  handleAgentOnboardingOpen() {
    this.props.onClose();
    _common_components_molecule__WEBPACK_IMPORTED_MODULE_13__["openAgentOnboardingModal"] && Object(_common_components_molecule__WEBPACK_IMPORTED_MODULE_13__["openAgentOnboardingModal"])(true);
  }

  handleAutomaticSelectToggle() {
    pm.settings.setSetting(_AgentConstants__WEBPACK_IMPORTED_MODULE_12__["AUTOMATIC_SELECTION_SETTING_KEY"], !_.get(pm.runtime, 'agent.autoMode'));
  }

  handleAgentSelect(option) {
    if (_.get(pm.runtime, 'agent.autoMode')) {
      return;
    }

    pm.settings.setSetting(_AgentConstants__WEBPACK_IMPORTED_MODULE_12__["SETTING_KEY"], option);
  }

  renderContent(selection, hasError) {
    const isCloudAgentEnabled = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('FeatureFlagsStore').isEnabled('runtime:isCloudAgentEnabled'),
    isSafari = Object(_postman_app_monolith_renderer_js_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_9__["getBrowser"])() === 'safari',
    agents = [
    ...(isCloudAgentEnabled ? [{
      label: '云代理',
      description: /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, "通过Postman的安全云服务器发送HTTP请求."),



      key: 'cloud' }] :
    []),
    {
      label: /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, "桌面代理",

      isSafari && ' (不支持)'),


      description: /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null,
      this.getDescriptionForDesktopAgent(isSafari, isCloudAgentEnabled),
      hasError && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_10__["Button"], {
        className: "agent-selection-details__confirm",
        type: "primary",
        onClick: this.handleAgentOnboardingOpen }, "下载桌面代理")),






      key: 'desktop' },

    {
      label: '浏览器代理',
      description: /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, "通过浏览器发送请求",

      ' ', /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", { className: "details__link", onClick: this.handleLinkClick }, "限制"), "."),



      key: 'browser' }],


    AgentInfo = ({
      label, description, active, onClick, unsupported, disabled }) => /*#__PURE__*/

    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      onClick: onClick,
      className: classnames__WEBPACK_IMPORTED_MODULE_2___default()({
        'agent-selection-details__wrapper': true, active, unsupported, disabled }) }, /*#__PURE__*/


    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: classnames__WEBPACK_IMPORTED_MODULE_2___default()({
        'agent-selection-item__radio': true, active, unsupported, disabled }) }), /*#__PURE__*/


    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "agent-selection-item__info" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: classnames__WEBPACK_IMPORTED_MODULE_2___default()({ 'agent-selection-item__label': true, unsupported, disabled }) },
    label), /*#__PURE__*/

    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: classnames__WEBPACK_IMPORTED_MODULE_2___default()({ 'agent-selection-item__description': true, unsupported, disabled }) },
    description)));





    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null,
      agents.map((agent) => /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(AgentInfo, {
        key: agent.key,
        unsupported: isSafari && agent.key === 'desktop',
        active: selection === agent.key,
        label: agent.label,
        description: agent.description,
        addDividerOnTop: agent.addDividerOnTop,
        onClick: () => this.handleAgentSelect(agent.key),
        disabled: _.get(pm.runtime, 'agent.autoMode') }))));




  }


  render() {
    const agentTypeName = _.get(pm.runtime, 'agent.autoMode') ? _AgentConstants__WEBPACK_IMPORTED_MODULE_12__["AUTOMATIC_SELECTION_SETTING_KEY"] : _AgentConstants__WEBPACK_IMPORTED_MODULE_12__["FRIENDLY_TYPES"][_.get(pm.runtime.agent, 'stat.type')],
    hasError = !pm.runtime.agent.isReady;

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: `agent-selection-details__${agentTypeName}` }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "details__header" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_5__["Text"], { type: "label-primary-medium" }, "选择Postman代理")), /*#__PURE__*/



      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "agent-selection-details__wrapper auto-select" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "agent-selection-item__info" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "agent-selection-item__label" }, "自动选择"), /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "agent-selection-item__description" }, "Postman将自动为您的请求选择最佳代理.")), /*#__PURE__*/



      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_ToggleSwitch__WEBPACK_IMPORTED_MODULE_11__["default"], {
        isActive: agentTypeName === _AgentConstants__WEBPACK_IMPORTED_MODULE_12__["AUTOMATIC_SELECTION_SETTING_KEY"],
        onClick: this.handleAutomaticSelectToggle,
        activeLabel: "",
        inactiveLabel: "" })), /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "agent-selection-details__divider" }),
      this.renderContent(agentTypeName, hasError)));


  }}) || _class) || _class;


AgentSelectionContainer.defaultProps = {
  onClose: () => {} };


AgentSelectionContainer.propTypes = {
  onClose: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func };
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 17845:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9);
/* harmony import */ var _services_BrowserActiveTrackService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17846);



/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'BrowserActiveTrackSelection',
  position: 'right',

  getComponent: function ({
    React,
    PluginInterface,
    StatusBarComponents })
  {
    return class BrowserActiveTrackSelection extends React.Component {
      constructor(props) {
        super(props);

        this.state = {
          activeTrack: _services_BrowserActiveTrackService__WEBPACK_IMPORTED_MODULE_1__["default"].getCurrentTrack() };

      }

      handleClick() {
        PluginInterface.openModal('settings', { tab: 'devOptions' });
      }

      render() {
        let { Item, Text } = StatusBarComponents;

        return /*#__PURE__*/(
          React.createElement(Item, {
            className: "plugin__activeTrack",
            tooltip: "切换活动轨迹" }, /*#__PURE__*/

          React.createElement(Text, {
            render: () => {
              return /*#__PURE__*/(
                React.createElement("div", {
                  className: "active-track-button",
                  onClick: this.handleClick }, /*#__PURE__*/

                React.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_0__["Icon"], { name: "icon-action-tag-stroke", size: "small" }), /*#__PURE__*/
                React.createElement("span", { className: "active-track-label" },
                this.state.activeTrack)));



            } })));



      }};

  } });

/***/ }),

/***/ 17856:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2293);
/* harmony import */ var _services_WebSocketProxyService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(17857);




/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'WebSocketProxySelection',
  position: 'right',

  getComponent: function ({
    React,
    PluginInterface,
    StatusBarComponents })
  {
    return class WebSocketProxySelection extends React.Component {
      constructor(props) {
        super(props);

        this.state = {
          webSocketServer: _services_WebSocketProxyService__WEBPACK_IMPORTED_MODULE_2__["default"].getCurrentProxy() };


        pm.windowEvents.addListener('dev-settings-websocket-proxy-update',
        this.updateWebSocketProxy.bind(this));
      }

      handleClick() {
        PluginInterface.openModal('settings', { tab: 'devOptions' });
      }

      updateWebSocketProxy() {
        this.setState({
          webSocketServer: _services_WebSocketProxyService__WEBPACK_IMPORTED_MODULE_2__["default"].getCurrentProxy() });

      }

      render() {
        let { Item, Text } = StatusBarComponents;

        return /*#__PURE__*/(
          React.createElement(Item, {
            className: "plugin__activeTrack",
            tooltip: "切换 Web Socket 代理" }, /*#__PURE__*/

          React.createElement(Text, {
            render: () => {
              return /*#__PURE__*/(
                React.createElement("div", {
                  className: "active-track-button",
                  onClick: this.handleClick }, /*#__PURE__*/

                React.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_0__["Icon"], { name: "icon-state-connectionSecure-stroke", size: "small" }), /*#__PURE__*/
                React.createElement("span", { className: "active-track-label" },
                this.state.webSocketServer.name)));



            } })));



      }};

  } });

/***/ }),

/***/ 17859:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _version_control_trash_components_TrashLabel_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17860);



/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'Trash',
  position: 'right',
  getComponent({
    React,
    StatusBarComponents })
  {
    return _version_control_trash_components_TrashLabel_js__WEBPACK_IMPORTED_MODULE_1__["default"];
  } });

/***/ }),

/***/ 17860:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return TrashLabel; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(37);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2293);
/* harmony import */ var _js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2856);
/* harmony import */ var _appsdk_components_link_Link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2687);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1601);
/* harmony import */ var _common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6930);
/* harmony import */ var _js_components_status_bar_base_Item__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(17861);
/* harmony import */ var _js_components_status_bar_base_Text__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(17862);
var _class;











const TrashWrapper = Object(styled_components__WEBPACK_IMPORTED_MODULE_2__["default"])(_appsdk_components_link_Link__WEBPACK_IMPORTED_MODULE_5__["default"])`
  opacity: ${(props) => props.disabled && '0.5'};
`;let


TrashLabel = Object(mobx_react__WEBPACK_IMPORTED_MODULE_3__["observer"])(_class = class TrashLabel extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {
  render() {
    const isOffline = !Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('SyncStatusStore').isSocketConnected,
    isScratchpad = pm.isScratchpad,
    isDisabled = isScratchpad || isOffline;

    let tooltipBody = null;

    if (isScratchpad) {
      tooltipBody = '您需要退出便笺才能执行此操作';
    } else
    if (isOffline) {
      tooltipBody = '重新在线后即可执行此操作';
    }

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(TrashWrapper, {
        to: {
          routeIdentifier: 'trash' },

        disabled: isDisabled }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_4__["default"], { identifier: "trash" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_status_bar_base_Item__WEBPACK_IMPORTED_MODULE_8__["default"], { tooltip: "回收站" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_status_bar_base_Text__WEBPACK_IMPORTED_MODULE_9__["default"], {
        render: () => {
          return /*#__PURE__*/(
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common__WEBPACK_IMPORTED_MODULE_7__["CustomTooltip"], {
              align: "top",
              body: tooltipBody }, /*#__PURE__*/

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
              className: isDisabled ? 'trash-label-button-disabled' : 'trash-label-button' }, /*#__PURE__*/

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", { className: "trash-label-text" }, "回收站"), /*#__PURE__*/


            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["Icon"], {
              name: "icon-action-delete-stroke",
              size: "small" }))));




        } })))));





  }}) || _class;

/***/ }),

/***/ 17861:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Item; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Text__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(17862);
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(17863);
/* harmony import */ var _Pane__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(17864);
/* harmony import */ var _Drawer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(17865);
/* harmony import */ var _base_Tooltips__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2326);









class Item extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = { showTooltip: false };

    this.handleToggleTooltip = this.handleToggleTooltip.bind(this);
  }

  handleToggleTooltip(value = !this.state.showTooltip) {
    if (this.props.isOpen && value) {
      // Do not show the tooltip if the status bar / pane is open
      this.setState({ showTooltip: false });
      return;
    }

    this.setState({ showTooltip: value });
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'sb__item': true,
      'is-disabled': this.props.isDisabled,
      'is-active': this.props.isDisabled && this.props.isOpen },
    this.props.className);
  }

  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        ref: "item",
        className: this.getClasses() },


      react__WEBPACK_IMPORTED_MODULE_0___default.a.Children.map(this.props.children, (child) => {
        if (child.type === _Icon__WEBPACK_IMPORTED_MODULE_3__["default"]) {
          return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.cloneElement(child, {
            onMouseEnter: this.handleToggleTooltip.bind(this, true),
            onMouseLeave: this.handleToggleTooltip.bind(this, false) });

        } else
        if (child.type === _Text__WEBPACK_IMPORTED_MODULE_2__["default"]) {
          return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.cloneElement(child);
        } else
        if (child.type === _Pane__WEBPACK_IMPORTED_MODULE_4__["default"]) {
          return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.cloneElement(child, {
            isOpen: this.props.isOpen,
            onClose: this.props.toggleActive });

        } else
        if (child.type === _Drawer__WEBPACK_IMPORTED_MODULE_5__["default"]) {
          return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.cloneElement(child, {
            isOpen: this.props.isOpen,
            onClose: this.props.toggleActive });

        } else
        {
          throw new Error('Invalid child type, must be Icon, Text, Drawer or Pane');
        }
      }),


      this.props.tooltip && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tooltips__WEBPACK_IMPORTED_MODULE_6__["Tooltip"], {
        show: this.state.showTooltip,
        target: this.refs.item,
        placement: "top" }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Tooltips__WEBPACK_IMPORTED_MODULE_6__["TooltipBody"], null,
      this.props.tooltip))));





  }}

/***/ }),

/***/ 17862:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Text; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);



class Text extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({ 'sb__item__text': true }, this.props.className);
  }

  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: this.getClasses() },
      this.props.render && this.props.render()));


  }}

/***/ }),

/***/ 17863:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Icon; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);



class Icon extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({ 'sb__item__icon': true }, this.props.className);
  }

  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: this.getClasses(),
        onClick: this.props.onClick,
        onMouseEnter: this.props.onMouseEnter,
        onMouseLeave: this.props.onMouseLeave },

      this.props.icon));


  }}

/***/ }),

/***/ 17864:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Pane; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _postman_react_draggable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2894);
/* harmony import */ var _postman_react_draggable__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_postman_react_draggable__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3346);






class Pane extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = { paneHeight: this.props.paneHeight || 200 };
    this.handleStart = this.handleStart.bind(this);
    this.handleDrag = this.handleDrag.bind(this);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.isOpen && nextProps.isOpen !== this.props.isOpen) {
      let documentHeight = _.get(document, 'body.offsetHeight', 800);
      if (documentHeight - this.state.paneHeight < 100) {
        this.setState({ paneHeight: documentHeight - 100 });
      }
    }
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'sb__item__pane': true,
      'is-hidden': !this.props.isOpen },
    this.props.className);
  }

  handleStart(event, data) {
    this.paneHeight = this.state.paneHeight;
    this.startClientY = data.y;
  }

  handleDrag(event, data) {
    let clientY = data.y,
    paneHeight = this.paneHeight + (this.startClientY - clientY),
    documentHeight = _.get(document, 'body.offsetHeight', 800);

    if (documentHeight - paneHeight < 100) {
      paneHeight = this.state.paneHeight;
    }

    if (paneHeight < 100) {
      paneHeight = 100;
    }

    this.setState({ paneHeight: paneHeight });
  }

  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_react_draggable__WEBPACK_IMPORTED_MODULE_2__["DraggableCore"], {
        axis: "y",
        handle: ".plugin__pane-resize-wrapper",
        onStart: this.handleStart,
        onDrag: this.handleDrag }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: this.getClasses(),
        style: { 'height': this.state.paneHeight } }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "plugin__pane-resize-wrapper" }),
      this.props.children, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Icons_CloseIcon__WEBPACK_IMPORTED_MODULE_3__["default"], {
        className: "plugin__pane-close",
        onClick: this.props.onClose }))));




  }}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 17865:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Drawer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_Dropdowns__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2845);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
function _extends() {_extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};return _extends.apply(this, arguments);}



class Drawer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleSelect = this.handleSelect.bind(this);
  }

  handleSelect(item) {
    this.props.onSelect && this.props.onSelect(item);
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({ 'sb__drawer': true }, this.props.className);
  }

  getItemProps(defaultArgs, props = {}) {
    return _extends({},
    defaultArgs,
    props, {
      className: classnames__WEBPACK_IMPORTED_MODULE_2___default()(defaultArgs.className, props.className || '') });

  }

  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: this.getClasses() }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_1__["Dropdown"], { onSelect: this.handleSelect }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_1__["DropdownButton"], null,
      this.props.button && this.props.button()), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_1__["DropdownMenu"], { className: "help-plugin-dropdown-menu", "align-right": true },

      _.map(this.props.items, (item) => {
        return /*#__PURE__*/(
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_base_Dropdowns__WEBPACK_IMPORTED_MODULE_1__["MenuItem"], {
            key: item.key,
            refKey: item.key }, /*#__PURE__*/

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, item.label)));


      })))));





  }}


Drawer.defaultProps = {
  itemRenderer: (item, getItemProps) => {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", getItemProps(),
      item.label));


  } };
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 17866:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2856);
/* harmony import */ var _runtime_repl_runner_api_RunnerInterface__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2376);






/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'Runner',
  position: 'right',
  getComponent({
    React,
    StatusBarComponents })
  {
    return class Runner extends React.Component {
      render() {
        const { Item, Text } = StatusBarComponents;

        return /*#__PURE__*/(
          React.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_2__["default"], { identifier: "runner" }, /*#__PURE__*/
          React.createElement(Item, null, /*#__PURE__*/
          React.createElement(Text, {
            render: () => {
              return /*#__PURE__*/(
                React.createElement("div", {
                  className: "runner-label-button",
                  onClick: () => Object(_runtime_repl_runner_api_RunnerInterface__WEBPACK_IMPORTED_MODULE_3__["openRunnerTab"])({}, { preview: false }) }, /*#__PURE__*/

                React.createElement("span", { className: "runner-label-text" }, "运行"), /*#__PURE__*/


                React.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["Icon"], {
                  name: "icon-action-run-stroke",
                  size: "small" })));



            } }))));




      }};

  } });

/***/ }),

/***/ 17867:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var _components_base_Icons_TwoPaneIcon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(17868);
/* harmony import */ var _components_base_Icons_SinglePaneIcon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17869);



/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'TwoPane',
  position: 'right',
  getComponent: function ({
    React,
    PluginInterface,
    StatusBarComponents,
    constants })
  {
    return class TwoPane extends React.Component {
      constructor(props) {
        super(props);
        this.state = { layout: PluginInterface.get('layout') };
      }

      UNSAFE_componentWillMount() {
        PluginInterface.register('layout', this.handleLayout, this);
      }

      handleLayout(payload) {
        this.setState({ layout: payload });
      }

      handleClick() {
        PluginInterface.toggleTwoPaneLayout();
      }

      getShortcut() {
        let platform = PluginInterface.get('platform');
        if (_.includes(platform, 'Mac')) {
          return '⌥⌘V';
        } else
        {
          return 'Ctrl + Alt + V';
        }
      }

      getTooltipContent(isTwoPane) {
        // when  Pane view switcher is relevant for the current Tab
        return `${isTwoPane ? '单窗格视图' : '双窗格视图'} (${this.getShortcut()})`;
      }

      getIcon() {
        let activeTheme = PluginInterface.get('theme'),
        layout = this.state.layout,
        { REQUESTER_TAB_LAYOUT_1_COLUMN, REQUESTER_TAB_LAYOUT_2_COLUMN } = constants.layout;

        if (_.isEqual(layout, REQUESTER_TAB_LAYOUT_2_COLUMN)) {
          return /*#__PURE__*/(
            React.createElement(_components_base_Icons_SinglePaneIcon__WEBPACK_IMPORTED_MODULE_1__["default"], { size: "xs" }));

        } else
        {
          return /*#__PURE__*/(
            React.createElement(_components_base_Icons_TwoPaneIcon__WEBPACK_IMPORTED_MODULE_0__["default"], { size: "xs" }));

        }
      }

      render() {
        const { Item, Icon } = StatusBarComponents,
        { REQUESTER_TAB_LAYOUT_2_COLUMN } = constants.layout,
        isTwoPane = this.state.layout === REQUESTER_TAB_LAYOUT_2_COLUMN,
        tooltipContent = this.getTooltipContent(isTwoPane);

        return /*#__PURE__*/(
          React.createElement(Item, {
            className: `plugin__layout ${isTwoPane ? 'single-pane' : 'two-pane'}`,
            tooltip: tooltipContent }, /*#__PURE__*/

          React.createElement(Icon, {
            onClick: this.handleClick,
            icon: this.getIcon() })));



      }};

  } });
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 17868:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return TwoPaneIcon; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2320);
/* harmony import */ var _XPaths_XPath__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2856);
function _extends() {_extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};return _extends.apply(this, arguments);}



const icon = /*#__PURE__*/
react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("svg", { width: "16", height: "16", viewBox: "0 0 16 16" }, /*#__PURE__*/
react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("defs", null, /*#__PURE__*/
react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("path", { id: "two-pane", d: "M7.5 1H1v14h6.521a.974.974 0 0 1-.021-.205V1zm1 0v13.795c0 .072-.007.14-.021.205H15V1H8.5zM15 0a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1V1a1 1 0 0 1 1-1h14zM2.25 10V6h4v4h-4zm9.5 0a2 2 0 1 1 0-4 2 2 0 0 1 0 4z" })), /*#__PURE__*/

react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("use", { fill: "gray", fillRule: "evenodd", xlinkHref: "#two-pane" }));



function TwoPaneIcon(props) {
  return /*#__PURE__*/(
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_XPaths_XPath__WEBPACK_IMPORTED_MODULE_2__["default"], { identifier: "layout" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], _extends({},
    props, {
      icon: icon }))));



}

/***/ }),

/***/ 17869:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SinglePaneIcon; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2320);
/* harmony import */ var _XPaths_XPath__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2856);
function _extends() {_extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};return _extends.apply(this, arguments);}



const icon = /*#__PURE__*/
react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("svg", { width: "16", height: "16", viewBox: "0 0 16 16" }, /*#__PURE__*/
react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("defs", null, /*#__PURE__*/
react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("path", { id: "single-pane", d: "M7.5 1H1v14h6.521a.974.974 0 0 1-.021-.205V1zm1 0v13.795c0 .072-.007.14-.021.205H15V1H8.5zM15 0a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1V1a1 1 0 0 1 1-1h14zM2.25 10V6h4v4h-4zm9.5 0a2 2 0 1 1 0-4 2 2 0 0 1 0 4z" })), /*#__PURE__*/

react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("use", { fill: "gray", fillRule: "evenodd", transform: "rotate(90 8 8)", xlinkHref: "#single-pane" }));



function SinglePaneIcon(props) {
  return /*#__PURE__*/(
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_XPaths_XPath__WEBPACK_IMPORTED_MODULE_2__["default"], { identifier: "layout" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], _extends({},
    props, {
      icon: icon }))));



}

/***/ }),

/***/ 17870:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2856);
/* harmony import */ var _stores_get_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1601);
/* harmony import */ var _constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3174);
/* harmony import */ var _constants_WorkspaceVisibilityConstants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1799);
/* harmony import */ var _postman_app_monolith_renderer_js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1810);







const PRIVACY_POLICY = 'privacy-policy',
TERMS = 'terms';

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'Copyright',
  position: 'right',
  getComponent({
    React,
    StatusBarComponents })
  {
    return class Copyright extends React.Component {
      constructor(props) {
        super(props);this.




        handleClick = (name) => {
          switch (name) {
            case PRIVACY_POLICY:
              return Object(_postman_app_monolith_renderer_js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_5__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_3__["LICENSE_URL"]);
            case TERMS:
              return Object(_postman_app_monolith_renderer_js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_5__["openExternalLink"])(_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_3__["EULA_LINK"]);
            default:
              break;}

        };this.handleClick = this.handleClick.bind(this);}

      render() {
        const { Item, Text } = StatusBarComponents,
        isLoggedIn = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('CurrentUserStore').isLoggedIn,
        isPublicWorkspace = Object(_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('ActiveWorkspaceStore').visibilityStatus === _constants_WorkspaceVisibilityConstants__WEBPACK_IMPORTED_MODULE_4__["VISIBILITY"].public;

        return /*#__PURE__*/(
          React.createElement(_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_1__["default"], { identifier: "copyright" },

          !isLoggedIn && isPublicWorkspace && /*#__PURE__*/
          React.createElement(Item, null, /*#__PURE__*/
          React.createElement(Text, {
            className: "copyright-container",
            render: () => {
              return /*#__PURE__*/(
                React.createElement("div", { className: "copyright-text" }, /*#__PURE__*/
                React.createElement("span", null, "\xA9 ", new Date().getFullYear(), " Postman, Inc."), "\xA0-\xA0", /*#__PURE__*/

                React.createElement("span", {
                  className: "copyright-link",
                  onClick: () => this.handleClick(PRIVACY_POLICY) }, "隐私政策"), "\xA0-\xA0", /*#__PURE__*/




                React.createElement("span", {
                  className: "copyright-link",
                  onClick: () => this.handleClick(TERMS) }, "条款")));





            } }))));






      }};

  } });

/***/ })

}]);