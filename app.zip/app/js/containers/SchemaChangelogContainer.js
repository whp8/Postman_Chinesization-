(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[78],{

/***/ 17880:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SchemaChangelogContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2293);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(515);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1601);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1595);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9);
/* harmony import */ var _services_ChangelogService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(14699);
/* harmony import */ var _constants_SchemaErrors__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7586);
/* harmony import */ var _components_SchemaChangelog__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(17881);
/* harmony import */ var _api_dev_services_APIPermissionService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7279);
/* harmony import */ var _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1812);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2325);
/* harmony import */ var _appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2862);
var _class;













let


SchemaChangelogContainer = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class SchemaChangelogContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      revisions: [],
      loading: true,
      error: false,
      isRestoring: false,
      restoreEntity: null,
      changelogsExhausted: false,
      fetchingMoreLogs: false,
      noSchema: false,
      isOffline: false };


    this.handleRestoreSchema = this.handleRestoreSchema.bind(this);
    this.handleRefresh = this.handleRefresh.bind(this);
    this.handleRetry = this.handleRetry.bind(this);
    this.handleFetchChangelog = this.handleFetchChangelog.bind(this);
    this.handleFetchMoreChangelog = this.handleFetchMoreChangelog.bind(this);
    this.getRefreshIconText = this.getRefreshIconText.bind(this);
  }

  componentDidMount() {
    this.disposeChangelogReaction = Object(mobx__WEBPACK_IMPORTED_MODULE_4__["reaction"])(
    () => lodash__WEBPACK_IMPORTED_MODULE_2___default.a.get(this.props, 'contextData.id') &&
    lodash__WEBPACK_IMPORTED_MODULE_2___default.a.get(this.props, 'contextData.versionId') &&
    !lodash__WEBPACK_IMPORTED_MODULE_2___default.a.get(this.props, 'contextData.schemaLoading') &&
    lodash__WEBPACK_IMPORTED_MODULE_2___default.a.get(this.props, 'contextData.schemaId') &&
    Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('SyncStatusStore').isSocketConnected,
    (fetch) => {
      if (!Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('SyncStatusStore').isSocketConnected && (this.state.loading || this.state.error)) {
        this.setState({ loading: false, isOffline: true });

        return;
      }

      if (!lodash__WEBPACK_IMPORTED_MODULE_2___default.a.get(this.props, 'contextData.schemaId')) {
        this.setState({ loading: false, noSchema: true, isOffline: false });
      }

      if (fetch) {
        this.setState({
          loading: true,
          noSchema: false,
          error: false,
          isOffline: false });


        this.handleFetchChangelog();

        _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__["default"].addEventV2({
          category: 'schema',
          action: 'view_changelog',
          entityId: lodash__WEBPACK_IMPORTED_MODULE_2___default.a.get(this.props, 'contextData.id') });

      }
    },
    { fireImmediately: true });

  }

  componentWillUnmount() {
    lodash__WEBPACK_IMPORTED_MODULE_2___default.a.isFunction(this.disposeChangelogReaction) && this.disposeChangelogReaction();
    lodash__WEBPACK_IMPORTED_MODULE_2___default.a.isFunction(this.disposeSocketReaction) && this.disposeSocketReaction();
  }

  handleFetchChangelog() {
    const contextData = lodash__WEBPACK_IMPORTED_MODULE_2___default.a.get(this.props, 'contextData', {}),
    apiId = contextData.id,
    versionId = contextData.versionId,
    schemaId = contextData.schemaId;

    if (!schemaId) {
      pm.toasts.error(_constants_SchemaErrors__WEBPACK_IMPORTED_MODULE_8__["ERROR_FETCHING_CHANGELOG"]);

      return;
    }

    Object(_services_ChangelogService__WEBPACK_IMPORTED_MODULE_7__["fetchChangelog"])(apiId, versionId, schemaId).
    then((body) => {
      this.setState({
        revisions: body.revisions,
        loading: false,
        changelogsExhausted: !body.nextMaxId });

    }).
    catch((err) => {
      this.setState({
        loading: false,
        error: true });


      pm.toasts.error(lodash__WEBPACK_IMPORTED_MODULE_2___default.a.get(err, 'message') || _constants_SchemaErrors__WEBPACK_IMPORTED_MODULE_8__["ERROR_FETCHING_CHANGELOG"]);
    });
  }

  handleFetchMoreChangelog() {
    const maxId = lodash__WEBPACK_IMPORTED_MODULE_2___default.a.get(this.state.revisions[this.state.revisions.length - 1], 'id'),
    contextData = lodash__WEBPACK_IMPORTED_MODULE_2___default.a.get(this.props, 'contextData', {}),
    apiId = contextData.id,
    versionId = contextData.versionId,
    schemaId = contextData.schemaId;

    this.setState({ fetchingMoreLogs: true }, () => {
      lodash__WEBPACK_IMPORTED_MODULE_2___default.a.invoke(this.refs, 'changelog.scrollMoreLoaderIntoView');
    });

    Object(_services_ChangelogService__WEBPACK_IMPORTED_MODULE_7__["fetchChangelog"])(apiId, versionId, schemaId, maxId).
    then((body) => {
      this.setState({
        revisions: [...this.state.revisions, ...body.revisions],
        fetchingMoreLogs: false,
        changelogsExhausted: !body.nextMaxId });

    }).
    catch((err) => {
      this.setState({
        fetchingMoreLogs: false,
        error: true });


      pm.toasts.error(lodash__WEBPACK_IMPORTED_MODULE_2___default.a.get(err, 'message') || _constants_SchemaErrors__WEBPACK_IMPORTED_MODULE_8__["ERROR_FETCHING_CHANGELOG"]);
    });
  }

  handleRefresh() {
    this.setState({ loading: true, error: false });

    this.handleFetchChangelog();
  }

  handleRestoreSchema(revisionId = null) {
    if (!Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('CurrentUserStore').isLoggedIn) {
      return pm.mediator.trigger('showSignInModal', {
        type: 'schema',
        subtitle: _constants_SchemaErrors__WEBPACK_IMPORTED_MODULE_8__["NOT_SIGNED_IN_ERROR"],
        origin: 'schema_changelog_restore' });

    }

    if (!Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('ActiveWorkspaceStore').isMember) {
      return pm.mediator.trigger('openUnjoinedWorkspaceModal');
    }

    _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__["default"].addEventV2({
      category: 'schema',
      action: 'initiate_restore',
      entityId: lodash__WEBPACK_IMPORTED_MODULE_2___default.a.get(this.props, 'contextData.id') });


    this.setState({ isRestoring: true, restoreEntity: revisionId });

    if (revisionId) {
      const contextData = lodash__WEBPACK_IMPORTED_MODULE_2___default.a.get(this.props, 'contextData', {}),
      apiId = contextData.id,
      versionId = contextData.versionId,
      schemaId = contextData.schemaId;

      Object(_services_ChangelogService__WEBPACK_IMPORTED_MODULE_7__["restoreSchema"])(apiId, versionId, schemaId, revisionId).
      then(() => {
        _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__["default"].addEventV2({
          category: 'schema',
          action: 'successful_restore',
          entityId: apiId });


        this.setState({ isRestoring: false }, () => {
          this.handleRefresh();
        });

        pm.toasts.success('您已成功恢复架构.');
      }).
      catch((err) => {
        this.setState({
          isRestoring: false,
          restoreEntity: null });


        _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__["default"].addEventV2({
          category: 'schema',
          action: 'fail_restore',
          entityId: apiId });


        pm.toasts.error(lodash__WEBPACK_IMPORTED_MODULE_2___default.a.get(err, 'message') || _constants_SchemaErrors__WEBPACK_IMPORTED_MODULE_8__["SCHEMA_RESTORE_FAILED"]);
      });
    }
  }

  handleExpand(diff, apiName) {
    const data = {
      diff: diff,
      apiName: apiName };


    _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__["default"].addEventV2({
      category: 'schema',
      action: 'expand_changelog',
      entityId: lodash__WEBPACK_IMPORTED_MODULE_2___default.a.get(this.props, 'contextData.id') });


    pm.mediator.trigger('showSchemaChangelogModal', data);
  }

  handleRetry() {
    this.setState({ loading: true, error: false });

    this.handleFetchChangelog();
  }

  getRefreshTextClass() {
    return classnames__WEBPACK_IMPORTED_MODULE_5___default()({
      'schema-changelog-container__refresh-button': true,
      'schema-changelog-container__refresh-button__loading': this.state.loading });

  }

  getRefreshIconText() {
    if (!Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('SyncStatusStore').isSocketConnected) {
      return _constants_SchemaErrors__WEBPACK_IMPORTED_MODULE_8__["OFFLINE_ERROR"];
    }

    if (this.state.loading || this.state.fetchingMoreLogs || lodash__WEBPACK_IMPORTED_MODULE_2___default.a.get(this.props, 'contextData.schemaLoading')) {
      return '请稍等...';
    }

    if (this.state.noSchema) {
      return '找不到架构';
    }

    return '获取更新的变更日志';
  }

  render() {
    const apiId = lodash__WEBPACK_IMPORTED_MODULE_2___default.a.get(this.props, 'contextData.id'),
    permissions = lodash__WEBPACK_IMPORTED_MODULE_2___default.a.get(this.props, 'contextData.permissions'),
    updateSchemaPermission = _api_dev_services_APIPermissionService__WEBPACK_IMPORTED_MODULE_10__["default"].hasPermission(permissions, 'updateSchema', 'api', apiId);

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_13__["ContextBarViewHeader"], {
        title: this.props.title,
        onClose: this.props.onClose }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_12__["Button"], {
        className: this.getRefreshTextClass(),
        tooltip: this.getRefreshIconText(),
        tooltipImmediate: true,
        type: "tertiary",
        onClick: this.handleRefresh,
        disabled: this.state.loading ||
        this.state.fetchingMoreLogs ||
        this.state.noSchema ||
        !Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('SyncStatusStore').isSocketConnected }, /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_6__["Icon"], {
        name: "icon-action-refresh-stroke" }))), /*#__PURE__*/



      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "schema-changelog-container__content" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_SchemaChangelog__WEBPACK_IMPORTED_MODULE_9__["default"], {
        ref: "changelog",
        apiName: lodash__WEBPACK_IMPORTED_MODULE_2___default.a.get(this.props, 'contextData.name'),
        changelogsExhausted: this.state.changelogsExhausted,
        error: this.state.error,
        fetchingMoreLogs: this.state.fetchingMoreLogs,
        isRestoring: this.state.isRestoring,
        isOffline: this.state.isOffline,
        loading: this.state.loading,
        noSchema: this.state.noSchema,
        restoreEntity: this.state.restoreEntity,
        revisions: this.state.revisions,
        schemaLoading: lodash__WEBPACK_IMPORTED_MODULE_2___default.a.get(this.props, 'contextData.schemaLoading'),
        updateSchemaPermission: updateSchemaPermission,
        onExpand: this.handleExpand,
        onRetry: this.handleRetry,
        onRestoreSchema: this.handleRestoreSchema,
        onFetchMoreChangelog: this.handleFetchMoreChangelog }))));




  }}) || _class;

/***/ }),

/***/ 17881:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SchemaChangelog; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2293);
/* harmony import */ var _postman_date_helper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2304);
/* harmony import */ var _postman_date_helper__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_postman_date_helper__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _js_components_base_Avatar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4190);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1601);
/* harmony import */ var _OfflineChangelog__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(14691);
/* harmony import */ var _ErrorChangelog__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(14692);
/* harmony import */ var _EmptyChangelog__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(14693);
/* harmony import */ var _NoSchemaFound__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(14694);
/* harmony import */ var _js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2322);
/* harmony import */ var _js_components_activity_feed_ActivityItemComponents__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9029);
/* harmony import */ var _DiffStrap__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(14695);
/* harmony import */ var _DiffText__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(14697);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2325);
/* harmony import */ var _constants_SchemaErrors__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7586);
/* harmony import */ var _js_components_base_Icons_IntegrationIcon__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(14698);
var _class;















let


SchemaChangelog = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class SchemaChangelog extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleScroll = this.handleScroll.bind(this);
    this.handleScrollDebounced = _.debounce(this.handleScroll, 100);
    this.scrollMoreLoaderIntoView = this.scrollMoreLoaderIntoView.bind(this);
    this.getRestoreTooltip = this.getRestoreTooltip.bind(this);
  }

  getDiffs(data) {
    let splitResponse = data['diff']['line'].split('\n'),
    diffs = [],
    diffChunkIdentifierIndexes = [];

    // Removes No newline at end of file text from the diff
    splitResponse.forEach((line, index) => {
      if (line.includes('No newline at end of file')) {
        splitResponse.splice(index, 1);
      }
    });

    // Find the indexes of chunk identifiers
    splitResponse.forEach((line, index) => {
      if (line.charAt(0) === '@') {
        diffChunkIdentifierIndexes.push(index);
      }
    });

    diffChunkIdentifierIndexes.forEach((chunkIndex, index) => {
      if (index === diffChunkIdentifierIndexes.length) {
        diffs.push(splitResponse.slice(chunkIndex, splitResponse.length));
      } else {
        diffs.push(splitResponse.slice(chunkIndex, diffChunkIdentifierIndexes[index + 1]));
      }
    });

    return diffs;
  }

  getActorName(revision) {
    if (_.get(revision, 'actor.type') === 'integration') {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "changelog__header__action-description__actor-name" }, "集成"));



    } else
    if (_.get(revision, 'actor.isAccessible')) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_activity_feed_ActivityItemComponents__WEBPACK_IMPORTED_MODULE_10__["User"], {
          id: _.get(revision, 'actor.id'),
          name: _.get(revision, 'actor.name') || _.get(revision, 'actor.username') }));


    }

    // Private/Anonymous User
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "changelog__header__action-description__actor-name" },
      _.get(revision, 'actor.name')));


  }

  getActorIcon(revision) {
    if (_.get(revision, 'actor.type') === 'integration') {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "changelog__actor-icon" }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Icons_IntegrationIcon__WEBPACK_IMPORTED_MODULE_15__["default"], { className: "changelog__actor-icon__content" })));


    } else
    if (_.get(revision, 'actor.isAccessible')) {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_activity_feed_ActivityItemComponents__WEBPACK_IMPORTED_MODULE_10__["ProfilePic"], { id: _.get(revision, 'actor.id') });
    }

    // Private/Anonymous User
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "changelog__actor-icon" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Avatar__WEBPACK_IMPORTED_MODULE_3__["default"], {
        size: "medium",
        userId: _.get(revision, 'actor.id'),
        customPic: _.get(revision, 'actor.profilePicUrl') })));



  }

  getActionText(action) {
    if (action === 'create') {
      return '创建了一个新的架构.';
    } else
    if (action === 'update') {
      return '做了以下更改:';
    } else
    if (action === 'restore') {
      return '恢复了架构的旧版本.';
    }
  }

  // If the user hits the bottom of the scrollbar then the call is made to fetch more changelogs
  handleScroll() {
    const node = this.refs.contentRef;

    if (!this.props.changelogsExhausted &&
    !this.props.fetchingMoreLogs &&
    Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('SyncStatusStore').isSocketConnected &&
    node && node.scrollHeight - (node.scrollTop + node.offsetHeight) <= 5)
    {
      this.props.onFetchMoreChangelog();
    }
  }

  scrollMoreLoaderIntoView() {
    const node = this.refs.moreLoader;

    node && node.scrollIntoView();
  }

  getRestoreTooltip() {
    if (!Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('SyncStatusStore').isSocketConnected) {
      return _constants_SchemaErrors__WEBPACK_IMPORTED_MODULE_14__["OFFLINE_ERROR"];
    } else
    if (!this.props.updateSchemaPermission) {
      return _constants_SchemaErrors__WEBPACK_IMPORTED_MODULE_14__["PERMISSION_ERROR"];
    } else
    {
      return '';
    }
  }

  render() {
    const isSyncEnabled = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('GateKeeperStore').isSyncEnabled,
    error = !isSyncEnabled || this.props.error;

    if (this.props.loading || this.props.schemaLoading) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "changelog_loader" }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_9__["default"], null)));


    }

    if (this.props.isOffline) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_OfflineChangelog__WEBPACK_IMPORTED_MODULE_5__["default"], null));

    }

    if (error) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_ErrorChangelog__WEBPACK_IMPORTED_MODULE_6__["default"], {
          onRetry: this.props.onRetry }));


    }

    if (this.props.noSchema) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_NoSchemaFound__WEBPACK_IMPORTED_MODULE_8__["default"], null));

    }

    if (_.get(this.props, 'revisions.length', 0) === 0 && this.props.changelogsExhausted) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_EmptyChangelog__WEBPACK_IMPORTED_MODULE_7__["default"], null));

    }

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "changelog__wrapper",
        ref: "contentRef",
        onScroll: this.handleScrollDebounced },


      (this.props.revisions || []).map((revision, index) => {
        let diffs = this.getDiffs(revision),
        date = _postman_date_helper__WEBPACK_IMPORTED_MODULE_2___default.a.getFormattedDateAndTime(revision.createdAt);

        return /*#__PURE__*/(
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { key: index, className: "changelog" }, /*#__PURE__*/
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_activity_feed_ActivityItemComponents__WEBPACK_IMPORTED_MODULE_10__["Header"], null,

          this.getActorIcon(revision), /*#__PURE__*/

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "changelog__header" }, /*#__PURE__*/
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "changelog__header__date" }, date), /*#__PURE__*/
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "changelog__header__action-description" },

          this.getActorName(revision), /*#__PURE__*/

          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, this.getActionText(revision.action))))),



          _.map(diffs, (diff, newIndex) => {
            let tempDiff;

            if (diff.length > 11) {
              // take the index till 11 because the 0th index is the chunk identifier
              tempDiff = diff.slice(0, 11);
            } else
            {
              tempDiff = diff;
            }

            return /*#__PURE__*/(
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "changelog-content-container", key: newIndex }, /*#__PURE__*/
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "changelog-content-container__content", onClick: () => {this.props.onExpand(diff, this.props.apiName);} }, /*#__PURE__*/
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_DiffStrap__WEBPACK_IMPORTED_MODULE_11__["default"], { diff: tempDiff }), /*#__PURE__*/
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_DiffText__WEBPACK_IMPORTED_MODULE_12__["default"], { diff: tempDiff }), /*#__PURE__*/
              react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "changelog-content-container__content__shadow" }))));



          }),
          _.has(revision, 'allowedActions.restore') && revision.allowedActions.restore && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "changelog-restore" },
          this.props.isRestoring && this.props.restoreEntity === revision.id ? /*#__PURE__*/
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "changelog-restore__loading" }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_9__["default"], null)) : /*#__PURE__*/
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_13__["Button"], {
            className: "changelog-restore__button",
            type: "text",
            onClick: () => {this.props.onRestoreSchema(revision.id);},
            disabled: !this.props.updateSchemaPermission || !Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('SyncStatusStore').isSocketConnected,
            tooltip: this.getRestoreTooltip(),
            tooltipImmediate: true }, "恢复"))));







      }),


      !this.props.changelogsExhausted && this.props.fetchingMoreLogs && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        ref: "moreLoader",
        className: "changelog__more-loader" }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_9__["default"], null))));




  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ })

}]);