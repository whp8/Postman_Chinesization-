(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[20],{

/***/ 9058:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return MonitorActivityInfo; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2293);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1595);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3737);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2325);
/* harmony import */ var _components_common_UserInfo__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9051);
/* harmony import */ var _appsdk_components_link_Link__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2687);
/* harmony import */ var _appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2862);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1601);
/* harmony import */ var _stores_domain_MonitorPermissionStore__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3741);
/* harmony import */ var _js_utils_ClipboardHelper__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2346);
/* harmony import */ var _components_common_MonitorOfflineContextBar__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9054);
/* harmony import */ var _integrations_components_context_bar_IntegrationContextBarList__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9059);
/* harmony import */ var _version_control_common_ForkLabel__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(3191);
/* harmony import */ var _js_containers_new_button_services_VersionTagService__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(3166);
/* harmony import */ var _utils_messages__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(3744);
var _class;function _extends() {_extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};return _extends.apply(this, arguments);}


















// Duration for which we will show the success state after performing the Copy action
const SHOW_COPY_SUCCESS_DURATION = 3000;let


MonitorActivityInfo = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class MonitorActivityInfo extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.monitorPermissionStore = new _stores_domain_MonitorPermissionStore__WEBPACK_IMPORTED_MODULE_11__["default"]();
    this.showPrvtUserTooltip = this.showPrvtUserTooltip.bind(this);
    this.hidePrvtUserTooltip = this.hidePrvtUserTooltip.bind(this);
    this.state = {
      showPrvtUserTooltip: false,
      idCopySuccess: false,
      forkedFromCollectionId: null,
      forkName: null,
      versionTag: null,
      versionName: '' };

    this.workspaceStore = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_10__["getStore"])('ActiveWorkspaceStore');
    this.loadOwnVersions = this.loadOwnVersions.bind(this);
  }

  componentDidMount() {
    Object(mobx__WEBPACK_IMPORTED_MODULE_4__["when"])(
    () => this.props.controller.store.data.collection,
    () => this.loadMonitorInfo());

  }

  loadMonitorInfo() {
    Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_10__["getStore"])('SyncStatusStore').onSyncAvailable().
    then(() => {

      const versionTag = this.props.controller.store.data.versionTag;

      this.loadOwnVersions({ collectionUid: this.props.controller.store.data.collection }).
      then((versions) => {

        let item = _.find(versions, ['id', versionTag]);

        if (item) {
          this.setState(() => ({
            versionName: item.name }));

        } else {
          this.setState(() => ({
            versionName: '当前' }));

        }
      }).
      catch((err) => {
        pm.logger.warn(_utils_messages__WEBPACK_IMPORTED_MODULE_17__["VERSION_TAGS_ERROR"].warn, err);
        pm.toasts.error(_.get(err, 'message') || _utils_messages__WEBPACK_IMPORTED_MODULE_17__["VERSION_TAGS_ERROR"].error);
      });
    });
  }

  loadOwnVersions(criteria) {
    return Object(_js_containers_new_button_services_VersionTagService__WEBPACK_IMPORTED_MODULE_16__["fetchAllTags"])(criteria).
    then((versions) => {
      return versions;
    });
  }

  componentWillUnmount() {
    clearTimeout(this.clearIdCopySuccessTimeout);
  }

  showPrvtUserTooltip() {
    this.setState({ showPrvtUserTooltip: true });
  }

  hidePrvtUserTooltip() {
    this.setState({ showPrvtUserTooltip: false });
  }

  fetchEnvironmentName(id) {
    // Fetch the uid from the workspace store
    if (id) {
      const environments = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_10__["getStore"])('ActiveWorkspaceStore').environments.find((_) => id == _.uid);

      if (environments === undefined) {
        return null;
      } else {
        return environments && environments.name;
      }
    } else {
      return null;
    }
  }

  fetchUserName(userId, data) {
    let teams = data.reduce((obj, item) => {
      obj[item.id] = item;
      return obj;
    }, {});
    let userInfo = _.get(teams, userId, {});
    return userInfo.name;
  }

  canViewCreatorInfo() {
    // contextData here refers to the MonitorConfigurationStore
    return this.monitorPermissionStore.can('viewCreatorInfo', this.props.contextData.id);
  }

  copyMonitorId(id) {
    if (this.state.idCopySuccess) {
      return;
    }

    _js_utils_ClipboardHelper__WEBPACK_IMPORTED_MODULE_12__["default"].copy(id);

    this.setState(
    { idCopySuccess: true },
    () => {
      this.clearIdCopySuccessTimeout = setTimeout(
      () => this.setState({ idCopySuccess: false }),
      SHOW_COPY_SUCCESS_DURATION);

    });

  }

  fetchCopyIcon(statusCheck) {
    if (statusCheck) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["Icon"], {
          name: "icon-state-success-stroke",
          className: "monitor-info-context-view__entity__content__toggle__success" }));


    } else
    {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["Icon"], {
          name: "icon-action-copy-stroke",
          className: "monitor-info-context-view__entity__content__toggle__copy" }));


    }
  }

  render() {
    const { isOffline } = this.props.controller.monitorActivityDetailsStore;

    this.monitorInfo = _.get(this.props, 'contextData', {});

    const createdAt = moment__WEBPACK_IMPORTED_MODULE_5___default()(this.monitorInfo.createdAt).format('DD MMM YYYY, h:mm A');

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "monitor-info-context-view-wrapper" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_9__["ContextBarViewHeader"], {
        title: this.props.title,
        onClose: this.props.onClose }),


      isOffline && typeof this.props.contextData.createdBy === 'number' ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_common_MonitorOfflineContextBar__WEBPACK_IMPORTED_MODULE_13__["default"], null) : /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "monitor-info-context-view" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "monitor-info-context-view__entity" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "monitor-info-context-view__entity__label" }, "ID"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "monitor-info-context-view__entity__content" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "monitor-info-context-view__entity__content__id" },

      this.monitorInfo.id), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_6__["Button"], {
        className: "monitor-info-context-view__entity__content__toggle",
        tooltip: this.state.idCopySuccess ? '`已拷贝`' : '拷贝监视器ID',
        type: "icon",
        onClick: () => this.copyMonitorId(this.monitorInfo.id) },

      this.fetchCopyIcon(this.state.idCopySuccess)))), /*#__PURE__*/



      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "monitor-info-context-view__entity" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "monitor-info-context-view__entity__label" }, "创建者"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        disabled: isOffline,
        className: isOffline && 'monitor-info-userinfo-offline' }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_common_UserInfo__WEBPACK_IMPORTED_MODULE_7__["default"], _extends({},
      this.monitorInfo.creatorInfo, {
        containerClass: "monitor-info-context-view__entity__content" }))))), /*#__PURE__*/




      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "monitor-info-context-view__entity" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "monitor-info-context-view__entity__label" }, "创建于"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "monitor-info-context-view__entity__content" },
      createdAt)), /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "monitor-info-context-view__entity" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "monitor-info-context-view__entity__label" }, "集合"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "monitor-info-context-view__entity__content monitor-info-context-view__entity__content--collection" },

      this.monitorInfo.collection ? /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_components_link_Link__WEBPACK_IMPORTED_MODULE_8__["default"], { to: isOffline ? '' : { routeIdentifier: 'build.collection',
          routeParams: { cid: this.monitorInfo.collection } },
        className: "monitor-info-context-view__entity__content__collection" },

      isOffline ? /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_6__["Button"], {
        type: "tertiary",
        className: "monitor-info-btn",
        disabled: isOffline,
        tooltip: isOffline && _utils_messages__WEBPACK_IMPORTED_MODULE_17__["TOOLTIP_TEXT"].isOffline },

      CollectionItem(this.monitorInfo.collection, isOffline)) :
      CollectionItem(this.monitorInfo.collection, isOffline)), /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "monitor-info-collection__collection-version-tag" },

      this.state.versionName)) : /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", { className: "monitor-info-context-view__entity__content__collection-empty" }, _utils_messages__WEBPACK_IMPORTED_MODULE_17__["MONITOR_DETAILS_NO_COLLECTION"]))), /*#__PURE__*/



      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "monitor-info-context-view__entity" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "monitor-info-context-view__entity__label" }, "环境"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "monitor-info-context-view__entity__content" },

      this.fetchEnvironmentName(this.monitorInfo.environment) ? /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_components_link_Link__WEBPACK_IMPORTED_MODULE_8__["default"], { to: isOffline ? '' : {
          routeIdentifier: 'build.environment', routeParams: { eid: this.monitorInfo.environment } },
        className: "monitor-info-context-view__entity__content__environment" },

      isOffline ? /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_6__["Button"], {
        type: "tertiary",
        className: "monitor-info-btn",
        disabled: isOffline,
        tooltip: isOffline && _utils_messages__WEBPACK_IMPORTED_MODULE_17__["TOOLTIP_TEXT"].isOffline },

      this.fetchEnvironmentName(this.monitorInfo.environment)) : /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["Text"], { type: 'link-subtle', className: "monitor-info-text-link" }, this.fetchEnvironmentName(this.monitorInfo.environment))) : /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", { className: "monitor-info-context-view__entity__content__environment-empty" }, _utils_messages__WEBPACK_IMPORTED_MODULE_17__["NO_ENVIRONMENT"]))),



      _.includes(['dev', 'beta', 'stage', 'canary', 'prod'], window.RELEASE_CHANNEL) && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_integrations_components_context_bar_IntegrationContextBarList__WEBPACK_IMPORTED_MODULE_14__["IntegrationContextBarList"], {
        entityId: this.monitorInfo.id,
        entityType: "monitor" }))));






  }}) || _class;


function CollectionItem(uid, isOffline) {
  let collection = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_10__["getStore"])('ActiveWorkspaceStore').collections.find((_) => uid == _.uid);

  if (uid) {
    if (collection === undefined) {
      return null;
    } else {

      let forkedFrom = _.get(collection, 'meta.forkedFrom') || {};
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: classnames__WEBPACK_IMPORTED_MODULE_3___default()({
            'monitor-info-collection': true,
            'monitor-info-collection__collection-name-offline': isOffline }) }, /*#__PURE__*/


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["Text"], { type: 'link-subtle', className: "monitor-info-collection__collection-name" }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", { className: "monitor-info-collection__collection-name-text" },
        collection.name)),


        collection.isForked ? /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "monitor-info-collection__qualifiers" }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_version_control_common_ForkLabel__WEBPACK_IMPORTED_MODULE_15__["default"], {
          className: "monitor-info-collection__fork-label",
          label: _.get(collection, 'forkInfo.forkLabel'),
          forkedEntity: {
            id: _.get(collection, 'forkInfo.id'),
            model: 'collection',
            forkLabel: _.get(collection, 'forkInfo.forkLabel'),
            name: _.get(collection, 'forkInfo.name') },

          baseEntity: {
            id: forkedFrom.id,
            model: 'collection',
            forkLabel: forkedFrom.forkLabel,
            name: forkedFrom.name } })) :



        null));



    }
  } else {
    return null;
  }
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ })

}]);