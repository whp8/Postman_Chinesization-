(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[16],{

/***/ 9037:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2293);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9);
/* harmony import */ var _components_common_MonitorList__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9038);
/* harmony import */ var _components_sidebar_MonitorSidebarMenu__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9042);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1601);
/* harmony import */ var _components_common_MonitorListEmpty__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9043);
/* harmony import */ var _appsdk_sidebar_SidebarNoResultsFound_SidebarNoResultsFound__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8228);
/* harmony import */ var _appsdk_sidebar_SidebarLoadingState_SidebarLoadingState__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7771);
/* harmony import */ var _components_sidebar_MonitorSidebarError__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9044);
/* harmony import */ var _js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2856);
/* harmony import */ var _components_common_MonitorOfflineSidebar__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9045);
/* harmony import */ var _appsdk_workbench_TabService__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2377);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3752);
/* harmony import */ var _services_UrlService__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(4047);
var _class;














let


MonitorSidebarContainer = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class MonitorSidebarContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.store = props.controller.store;
    this.activeWorkspaceStore = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('ActiveWorkspaceStore');
    this.openCreateMonitorTab = this.openCreateMonitorTab.bind(this);
    this.openMonitorTab = this.openMonitorTab.bind(this);
    this.initiateMonitorDelete = this.initiateMonitorDelete.bind(this);
    this.handleMonitorDelete = this.handleMonitorDelete.bind(this);
    this.handleMonitorRename = this.handleMonitorRename.bind(this);
    this.handleMonitorFocus = this.handleMonitorFocus.bind(this);
    this.refreshMonitorList = this.refreshMonitorList.bind(this);
  }

  openMonitorTab(monitorId, monitorName) {
    this.props.controller.openMonitorTab(monitorId, monitorName);
  }

  /**
   * Helper function to display sign in modal when needed
   * @returns {*}
   */
  showSignInModal() {
    return pm.mediator.trigger('showSignInModal', {
      type: 'generic',
      subtitle: '您需要一个账户才能继续探索 Postman.',
      origin: 'monitors_sidebar_create_button' });

  }

  openCreateMonitorTab() {
    if (!Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('CurrentUserStore').isLoggedIn) {
      return this.showSignInModal();
    }

    this.props.controller.openCreateMonitorTab();
  }

  initiateMonitorDelete(monitorId, monitorName) {
    pm.mediator.trigger('showDeleteMonitorModal', {
      id: monitorId,
      name: monitorName },

    () => {this.handleMonitorDelete(monitorId, monitorName);},
    { origin: 'sidebar' });
  }

  handleMonitorDelete(monitorId, monitorName) {
    pm.toasts.success('监视器已删除.');

    const monitorPath = _services_UrlService__WEBPACK_IMPORTED_MODULE_14__["default"].getMonitorPath({ monitorId, monitorName });

    // Close the tab if monitor is open inside of it
    _appsdk_workbench_TabService__WEBPACK_IMPORTED_MODULE_12__["default"].closeByRoute(_constants__WEBPACK_IMPORTED_MODULE_13__["MONITOR_WORKBENCH_URL"], { monitorPath });
    _appsdk_workbench_TabService__WEBPACK_IMPORTED_MODULE_12__["default"].closeByRoute(_constants__WEBPACK_IMPORTED_MODULE_13__["MONITOR_EDIT_URL"], { monitorPath });
  }

  handleMonitorRename({ monitorId, name }) {
    this.props.controller.updateMonitorName({ monitorId, name });
  }

  handleMonitorFocus(monitorId) {
    this.store.setActiveMonitorId(monitorId);
  }

  refreshMonitorList() {
    this.store.refreshSidebarList();
  }

  getRenderedComponent() {

    const canAddMonitor = !Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('CurrentUserStore').isLoggedIn || this.activeWorkspaceStore.isMember;

    let sidebarContent;

    // Show offline state if the user is offline when sidebar is loaded
    if (this.store.isOffline && !this.store.values.length && !this.store.loaded) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_common_MonitorOfflineSidebar__WEBPACK_IMPORTED_MODULE_11__["default"], null));

    }

    // Show an error msg if we encountered an error while loading the list
    if (this.store.error) {
      sidebarContent = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_sidebar_MonitorSidebarError__WEBPACK_IMPORTED_MODULE_9__["default"], { handleRefresh: this.refreshMonitorList });
    }

    // Show loader while the store is loading
    else if ((!this.store.loaded || this.store.loading) && !this.store.values.length) {
      sidebarContent = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_sidebar_SidebarLoadingState_SidebarLoadingState__WEBPACK_IMPORTED_MODULE_8__["default"], null);
    }

    // Show empty list if there are no monitors in this workspace
    else if (!this.store.values.length && !this.store.searchQuery) {
      sidebarContent = /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_common_MonitorListEmpty__WEBPACK_IMPORTED_MODULE_6__["default"], {
        canAddMonitor: canAddMonitor,
        createNewMonitor: this.openCreateMonitorTab,
        isOffline: this.store.isOffline });


    }

    // Show '未找到结果' view if there are no monitors matching the filter query
    else if (!this.store.filteredItems.length) {
      sidebarContent = /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_sidebar_SidebarNoResultsFound_SidebarNoResultsFound__WEBPACK_IMPORTED_MODULE_7__["default"], { searchQuery: this.store.searchQuery, illustration: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_2__["IllustrationNoMonitor"], null) });

    }

    // There are some items we can display
    else {
      sidebarContent = /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_10__["default"], { identifier: "monitor" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_common_MonitorList__WEBPACK_IMPORTED_MODULE_3__["default"], {
        items: this.store.filteredItems,
        activeMonitorId: this.store.activeMonitorId,
        canAddMonitor: canAddMonitor,
        createNewMonitor: this.openCreateMonitorTab,
        openMonitorTab: this.openMonitorTab,
        initiateMonitorDelete: this.initiateMonitorDelete,
        handleMonitorRename: this.handleMonitorRename,
        handleMonitorFocus: this.handleMonitorFocus,
        isOffline: this.store.isOffline }));



    }

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_sidebar_MonitorSidebarMenu__WEBPACK_IMPORTED_MODULE_4__["default"], {
        canAddMonitor: canAddMonitor,
        createNewMonitor: this.openCreateMonitorTab,
        store: this.store,
        isOffline: this.store.isOffline }),

      sidebarContent));


  }

  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "monitor-sidebar-tab-content" },
      this.getRenderedComponent()));


  }}) || _class;


/* harmony default export */ __webpack_exports__["default"] = (MonitorSidebarContainer);

/***/ }),

/***/ 9038:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _MonitorListItem__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9039);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2293);
/* harmony import */ var _stores_domain_MonitorPermissionStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3741);
/* harmony import */ var _js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2856);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1601);
/* harmony import */ var _js_components_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2314);
var _class;







const DEBOUNCE_WAIT = 300;let


MonitorList = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class MonitorList extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.monitorPermissionStore = new _stores_domain_MonitorPermissionStore__WEBPACK_IMPORTED_MODULE_3__["default"]();
    this.listItemRefs = {};

    // Shortcut handlers
    this.focusNext = this.focusNext.bind(this);
    this.focusPrev = this.focusPrev.bind(this);
    this.deleteItem = this.deleteItem.bind(this);
    this.renameItem = this.renameItem.bind(this);

    this.openMonitorTabDebounced = _.debounce((monitor) =>
    {
      this.props.openMonitorTab(monitor.id, monitor.name);
    }, DEBOUNCE_WAIT);

  }

  render() {
    let items = this.props.items,
    list = items.map((item, index) => {
      const isSelected = item.id === this.props.activeMonitorId ? true : undefined,

      // intentional true for signed out users,
      // so that we can show a 'sign in' modal when they click on the element
      // instead of disabling them
      canRename = !this.monitorPermissionStore.isUserLoggedIn() || this.monitorPermissionStore.can('edit', item.id),
      canDelete = !this.monitorPermissionStore.isUserLoggedIn() || this.monitorPermissionStore.can('delete', item.id),
      canManageRoles = !this.monitorPermissionStore.isUserLoggedIn() || !!Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('CurrentUserStore').team;

      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_4__["default"], { identifier: item.id, key: index }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_MonitorListItem__WEBPACK_IMPORTED_MODULE_1__["default"], {
          ref: (ref) => {this.listItemRefs[item.id] = ref;},
          data: item, key: index,
          selected: isSelected,
          initiateMonitorDelete: this.props.initiateMonitorDelete,
          handleMonitorRename: this.props.handleMonitorRename,
          canRename: canRename,
          canDelete: canDelete,
          canManageRoles: canManageRoles,
          isOffline: this.props.isOffline })));



    });

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_6__["default"], {
        keyMap: pm.shortcuts.getShortcuts(),
        handlers: this.getKeyMapHandlers() }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "monitor-listing" },
      list)));



  }


  getKeyMapHandlers() {
    return {
      nextItem: pm.shortcuts.handle('nextItem', this.focusNext),
      prevItem: pm.shortcuts.handle('prevItem', this.focusPrev),
      delete: pm.shortcuts.handle('delete', this.deleteItem),
      rename: pm.shortcuts.handle('rename', this.renameItem) };

  }

  focusNext(e) {
    e && e.preventDefault();
    this.focusItem(1);
  }

  focusPrev(e) {
    e && e.preventDefault();
    this.focusItem(-1);
  }

  focusItem(indexPadding) {
    const { items, activeMonitorId } = this.props;

    if (!activeMonitorId) {
      return;
    }

    if (_.isEmpty(items)) {
      return;
    }

    const itemIndex = _.findIndex(items, (item) => item.id === activeMonitorId);
    const selectedItem = items[(itemIndex + indexPadding) % items.length];

    this.props.handleMonitorFocus(selectedItem.id);
    this.openMonitorTabDebounced(selectedItem);
  }

  deleteItem() {
    const activeMonitorId = this.props.activeMonitorId;
    const monitors = this.props.items;
    const monitorToDelete = _.find(monitors, (monitor) => monitor.id === activeMonitorId);
    this.props.initiateMonitorDelete(monitorToDelete.id, monitorToDelete.name);
  }

  renameItem() {
    const activeMonitorId = this.props.activeMonitorId;
    _.invoke(this.listItemRefs, [activeMonitorId, 'handleEditName']);
  }}) || _class;


/* harmony default export */ __webpack_exports__["default"] = (MonitorList);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 9039:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2293);
/* harmony import */ var _js_containers_apps_requester_sidebar_SidebarListItem__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9023);
/* harmony import */ var _js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2845);
/* harmony import */ var _MonitorStatusIndicator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9040);
/* harmony import */ var _js_modules_services_ManageRolesModalService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2374);
/* harmony import */ var _DisabledTooltipWrapper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3739);
/* harmony import */ var _stores_domain_MonitorPermissionStore__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3741);
/* harmony import */ var _common_MonitorMetaIcons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9041);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1601);
/* harmony import */ var _services_UrlService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4047);
/* harmony import */ var _js_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4332);
var _class;












const MANAGE_ROLES_DISABLED_TEXT = '您需要登录到一个团队才能执行此操作';let


MonitorListItem = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class MonitorListItem extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.handleDropdownActionSelect = this.handleDropdownActionSelect.bind(this);
    this.handleEditName = this.handleEditName.bind(this);
    this.containerRef = this.containerRef.bind(this);
    this.handleRenameSubmit = this.handleRenameSubmit.bind(this);
    this.getRightMetaComponent = this.getRightMetaComponent.bind(this);
    this.getMonitorMetaIcons = this.getMonitorMetaIcons.bind(this);
    this.monitorPermissionStore = new _stores_domain_MonitorPermissionStore__WEBPACK_IMPORTED_MODULE_7__["default"]();
  }

  getClassNames() {
    let classes = {
      'monitor-listing-list-item': true,
      'monitor-listing-list-item-focussed': this.props.selected };


    return _.keys(_.pickBy(classes, _.identity)).join(' ');
  }

  containerRef(ele) {
    this.listItem = ele;
  }

  getMonitorRouteConfig() {
    return {
      routeIdentifier: 'build.monitor',
      routeParams: {
        monitorPath: _services_UrlService__WEBPACK_IMPORTED_MODULE_10__["default"].getMonitorPath({ monitorName: this.props.data.name, monitorId: this.props.data.id }) } };


  }

  /**
   * When the rename is confirmed by clicking outside or hitting enter
   * @param value
   */
  handleRenameSubmit(value) {
    if (_.get(this.props, 'data.name') === value) {
      return;
    }

    // send the rename request here
    this.props.handleMonitorRename({
      monitorId: this.props.data.id,
      name: value });

  }

  handleEditName() {
    _.invoke(this.listItem, 'editText');
  }

  /**
   * Helper function to display sign in modal when needed
   * @returns {*}
   */
  showSignInModal(action) {
    return pm.mediator.trigger('showSignInModal', {
      type: 'generic',
      subtitle: '您需要一个账户才能继续探索 Postman.',
      origin: `monitors_sidebar_${action}_action` });

  }

  /**
   * Different dropdown actions should be listed here
   * @param action
   */
  handleDropdownActionSelect(action) {
    if (!this.monitorPermissionStore.isUserLoggedIn()) {
      return this.showSignInModal(action);
    }

    switch (action) {
      case 'delete':
        this.props.initiateMonitorDelete(this.props.data.id, this.props.data.name);
        return;
      case 'manage-roles':
        if (!Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('ActiveWorkspaceStore').isMember) {
          return pm.mediator.trigger('openUnjoinedWorkspaceModal');
        }

        Object(_js_modules_services_ManageRolesModalService__WEBPACK_IMPORTED_MODULE_5__["manageRolesOnMonitor"])(this.props.data.id);
        return;
      case 'rename':
        this.handleEditName();
        return;}

  }

  /**
   * What we want to show as dropdown actions in this list item
   * @returns {({xpathLabel: string, isEnabled: *, label: string, type: string}|{xpathLabel: string, disabledMsg: string, isEnabled: *, label: string, type: string}|{xpathLabel: string, isEnabled: *, label: string, type: string})[]}
   */
  getActions() {
    return [
    {
      type: 'rename',
      label: '重命名',
      shortcut: 'rename',
      isEnabled: this.props.canRename,
      xpathLabel: 'rename' },

    {
      type: 'manage-roles',
      label: '管理角色',
      isEnabled: this.props.canManageRoles,
      disabledMsg: MANAGE_ROLES_DISABLED_TEXT,
      xpathLabel: 'manageRoles' },

    {
      type: 'delete',
      label: '删除',
      shortcut: 'delete',
      isEnabled: this.props.canDelete,
      xpathLabel: 'delete' }];


  }

  getMenuItems() {
    return _.chain(this.getActions()).
    map((action) => {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_3__["MenuItem"], {
          key: action.type,
          refKey: action.type,
          disabled: !action.isEnabled || this.props.isOffline }, /*#__PURE__*/

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_DisabledTooltipWrapper__WEBPACK_IMPORTED_MODULE_6__["default"], {
          showTooltip: !action.isEnabled || this.props.isOffline,
          tooltipText: action.disabledMsg,
          isOffline: this.props.isOffline,
          monitorId: this.props.data.id,
          monitorName: this.props.data.name,
          wrapperPrefix: "monitor-sidebar" }, /*#__PURE__*/

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", { className: "monitor-action-item" }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "dropdown-menu-item-label" }, action.label),

        action.shortcut && /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "dropdown-menu-item-shortcut" }, Object(_js_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_11__["getShortcutByName"])(action.shortcut))))));





    }).value();
  }

  dropdownOptions() {
    const menuItems = this.getMenuItems();
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_3__["DropdownMenu"], {
        className: 'monitors-dropdown-menu',
        "align-right": true },

      menuItems));


  }

  /**
   * Component shown between the name and the sidebar actions icon
   * @param isHovered
   * @param isDropdownOpen
   * @returns {JSX.Element}
   */
  getRightMetaComponent(isHovered, isDropdownOpen) {
    // apply the actions-hidden class when the 'dropdown actions icon' is hidden
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_MonitorStatusIndicator__WEBPACK_IMPORTED_MODULE_4__["default"], { isPaused: this.props.data.isPaused, isHealthy: this.props.data.isHealthy, className: !isHovered && !isDropdownOpen ? 'actions-hidden' : '' }));

  }

  getMonitorMetaIcons() {
    let activeWorkspace = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('ActiveWorkspaceStore').visibilityStatus;
    let isPublic = activeWorkspace === 'public',
    canTeamView = activeWorkspace === 'team';
    let isEditable = !this.monitorPermissionStore.isUserLoggedIn() || this.monitorPermissionStore.can('edit', this.props.data.id);

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_MonitorMetaIcons__WEBPACK_IMPORTED_MODULE_8__["default"], {
        isPublic: isPublic,
        canTeamView: canTeamView,
        isEditable: isEditable }));


  }

  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_containers_apps_requester_sidebar_SidebarListItem__WEBPACK_IMPORTED_MODULE_2__["default"], {
        text: _.get(this.props, 'data.name', ''),
        ref: this.containerRef,
        isSelected: this.props.selected,
        onRename: this.handleRenameSubmit,
        moreActions: this.dropdownOptions(),
        onActionsDropdownSelect: this.handleDropdownActionSelect,
        rightMetaComponent: this.getRightMetaComponent,
        statusIndicators: this.getMonitorMetaIcons,
        routeConfig: this.getMonitorRouteConfig() }));


  }}) || _class;

/* harmony default export */ __webpack_exports__["default"] = (MonitorListItem);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 9041:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return MonitorMetaIcons; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9);



class MonitorMetaIcons extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null,

      this.props.isPublic === true && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["Icon"], {
        name: "icon-state-published-stroke",
        color: "content-color-tertiary",
        className: "monitor-meta-icon",
        size: "small",
        title: "共享在公共工作区" }),



      !this.props.isPublic && this.props.canTeamView === true && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["Icon"], {
        name: "icon-descriptive-team-stroke",
        color: "content-color-tertiary",
        className: "monitor-meta-icon",
        size: "small",
        title: "与团队共享" }),



      this.props.isEditable === false && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["Icon"], {
        name: "icon-state-locked-stroke",
        color: "content-color-tertiary",
        className: "monitor-meta-icon",
        size: "small",
        title: "只读" })));




  }}

/***/ }),

/***/ 9042:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return MonitorSidebarMenu; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _js_containers_apps_requester_sidebar_SidebarListActions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9025);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1601);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2293);
/* harmony import */ var _utils_messages__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3744);
var _class;



let


MonitorSidebarMenu = Object(mobx_react__WEBPACK_IMPORTED_MODULE_3__["observer"])(_class = class MonitorSidebarMenu extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleSearch = this.handleSearch.bind(this);
  }

  getTooltipText(isDisabled, isOffline) {
    if (isDisabled) {
      if (!Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('ActiveWorkspaceStore').isMember)
      return _utils_messages__WEBPACK_IMPORTED_MODULE_4__["PERMISSION_TEXT"].JOIN_WORKSPACE_MSG;else

      return _utils_messages__WEBPACK_IMPORTED_MODULE_4__["PERMISSION_TEXT"].DEFAULT_DISABLED_MSG;
    }

    if (!isOffline) {
      return '创建新的监视器';
    } else {
      return '重新联网后即可执行此操作';
    }

  }

  handleSearch(query) {
    this.props.store.setSearchQuery(query);
  }

  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_containers_apps_requester_sidebar_SidebarListActions__WEBPACK_IMPORTED_MODULE_1__["default"], {
        createNewConfig: {
          tooltip: this.getTooltipText(!this.props.canAddMonitor, this.props.isOffline),
          disabled: !this.props.canAddMonitor || this.props.isOffline,
          onCreate: this.props.createNewMonitor,
          xPathIdentifier: 'addMonitor' },

        onSearch: this.handleSearch,
        searchQuery: this.props.store.searchQuery })));



  }}) || _class;

/***/ }),

/***/ 9043:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return MonitorListEmpty; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9);
/* harmony import */ var _appsdk_sidebar_SidebarEmptyState_SidebarEmptyState__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9027);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1601);
/* harmony import */ var _utils_messages__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3744);







class MonitorListEmpty extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  getTooltipText(isDisabled) {
    if (this.props.isOffline) {
      return _utils_messages__WEBPACK_IMPORTED_MODULE_4__["TOOLTIP_TEXT"].isOffline;
    } else if (isDisabled) {
      if (!Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('ActiveWorkspaceStore').isMember)
      return _utils_messages__WEBPACK_IMPORTED_MODULE_4__["PERMISSION_TEXT"].JOIN_WORKSPACE_MSG;else

      return _utils_messages__WEBPACK_IMPORTED_MODULE_4__["PERMISSION_TEXT"].DEFAULT_DISABLED_MSG;
    }
  }

  render() {
    const canAddMonitor = this.props.canAddMonitor;

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_sidebar_SidebarEmptyState_SidebarEmptyState__WEBPACK_IMPORTED_MODULE_2__["default"], {
        illustration: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["IllustrationNoMonitor"], null),
        title: _utils_messages__WEBPACK_IMPORTED_MODULE_4__["EMPTY_STATE"].noMonitorsSetup,
        message: _utils_messages__WEBPACK_IMPORTED_MODULE_4__["EMPTY_STATE"].monitorCollectionRun,
        action: {
          label: _utils_messages__WEBPACK_IMPORTED_MODULE_4__["MONITOR_ACTION"].create,
          handler: this.props.createNewMonitor,
          tooltip: this.getTooltipText(!canAddMonitor) },

        hasPermissions: !this.props.isOffline && canAddMonitor }));


  }}

/***/ }),

/***/ 9044:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2325);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9);
/* harmony import */ var _utils_messages__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3744);





class MonitorSidebarError extends react__WEBPACK_IMPORTED_MODULE_0___default.a.Component {
  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "monitor-sidebar-error-view" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "monitor-sidebar-error-view__illustration" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_2__["IllustrationUnableToLoad"], null)), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "monitor-sidebar-error-view__title" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_2__["Heading"], {
        type: "h4",
        color: "content-color-secondary",
        text: _utils_messages__WEBPACK_IMPORTED_MODULE_3__["MONITOR_ACTION_ERROR"].load })), /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
        className: "btn-small monitor-sidebar-error-view__button",
        type: "secondary",
        onClick: this.props.handleRefresh },

      _utils_messages__WEBPACK_IMPORTED_MODULE_3__["TRY_AGAIN"]))));




  }}


/* harmony default export */ __webpack_exports__["default"] = (MonitorSidebarError);

/***/ }),

/***/ 9045:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return MonitorOfflineSidebar; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9);
/* harmony import */ var _appsdk_sidebar_SidebarEmptyState_SidebarEmptyState__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9027);
/* harmony import */ var _utils_messages__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3744);






class MonitorOfflineSidebar extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "monitor-sidebar-offline-state" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_sidebar_SidebarEmptyState_SidebarEmptyState__WEBPACK_IMPORTED_MODULE_2__["default"], {
        illustration: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["IllustrationCheckInternetConnection"], null),
        title: _utils_messages__WEBPACK_IMPORTED_MODULE_3__["OFFLINE_TEXT"].text,
        message: _utils_messages__WEBPACK_IMPORTED_MODULE_3__["OFFLINE_TEXT"].subText })));



  }}

/***/ })

}]);