/******/ (function(modules) { // webpackBootstrap
/******/ 	// install a JSONP callback for chunk loading
/******/ 	function webpackJsonpCallback(data) {
/******/ 		var chunkIds = data[0];
/******/ 		var moreModules = data[1];
/******/ 		var executeModules = data[2];
/******/
/******/ 		// add "moreModules" to the modules object,
/******/ 		// then flag all "chunkIds" as loaded and fire callback
/******/ 		var moduleId, chunkId, i = 0, resolves = [];
/******/ 		for(;i < chunkIds.length; i++) {
/******/ 			chunkId = chunkIds[i];
/******/ 			if(Object.prototype.hasOwnProperty.call(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 				resolves.push(installedChunks[chunkId][0]);
/******/ 			}
/******/ 			installedChunks[chunkId] = 0;
/******/ 		}
/******/ 		for(moduleId in moreModules) {
/******/ 			if(Object.prototype.hasOwnProperty.call(moreModules, moduleId)) {
/******/ 				modules[moduleId] = moreModules[moduleId];
/******/ 			}
/******/ 		}
/******/ 		if(parentJsonpFunction) parentJsonpFunction(data);
/******/
/******/ 		while(resolves.length) {
/******/ 			resolves.shift()();
/******/ 		}
/******/
/******/ 		// add entry modules from loaded chunk to deferred list
/******/ 		deferredModules.push.apply(deferredModules, executeModules || []);
/******/
/******/ 		// run deferred modules when all chunks ready
/******/ 		return checkDeferredModules();
/******/ 	};
/******/ 	function checkDeferredModules() {
/******/ 		var result;
/******/ 		for(var i = 0; i < deferredModules.length; i++) {
/******/ 			var deferredModule = deferredModules[i];
/******/ 			var fulfilled = true;
/******/ 			for(var j = 1; j < deferredModule.length; j++) {
/******/ 				var depId = deferredModule[j];
/******/ 				if(installedChunks[depId] !== 0) fulfilled = false;
/******/ 			}
/******/ 			if(fulfilled) {
/******/ 				deferredModules.splice(i--, 1);
/******/ 				result = __webpack_require__(__webpack_require__.s = deferredModule[0]);
/******/ 			}
/******/ 		}
/******/
/******/ 		return result;
/******/ 	}
/******/
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// object to store loaded CSS chunks
/******/ 	var installedCssChunks = {
/******/ 		3: 0
/******/ 	}
/******/
/******/ 	// object to store loaded and loading chunks
/******/ 	// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 	// Promise = chunk loading, 0 = chunk loaded
/******/ 	var installedChunks = {
/******/ 		3: 0
/******/ 	};
/******/
/******/ 	var deferredModules = [];
/******/
/******/ 	// script path function
/******/ 	function jsonpScriptSrc(chunkId) {
/******/ 		return __webpack_require__.p + "" + ({"2":"CommonLazyChunk","11":"requester-legacy","12":"controllers/SideBarMockController","13":"components/SidebarMockListing","14":"components/MockInfoContextView","15":"controllers/MonitorSidebarController","16":"containers/MonitorSidebarContainer","17":"controllers/MonitorContextBarController","18":"containers/MonitorActivityLogs","19":"controllers/MonitorActivityDetailsController","20":"containers/MonitorActivityInfo","21":"contextbar/FolderInfoCBView/FolderInfoCBView","22":"contextbar/FolderInfoCBController","23":"text-editor","24":"sidebar/CollectionSidebarView","25":"sidebar/CollectionSidebarController","26":"contextbar/CollectionInfoCBView/CollectionInfoCBView","27":"contextbar/CollectionInfoCBController","28":"contextbar/GlobalsInfoCBView/GlobalsInfoCBView","29":"postman-converters","30":"sidebar/EnvironmentSidebarView","31":"sidebar/EnvironmentSidebarController","32":"contextbar/EnvironmentInfoCBView/EnvironmentInfoCBView","33":"contextbar/EnvironmentInfoCBController","34":"contextbar/ExampleInfoCBView/ExampleInfoCBView","35":"contextbar/RequestInfoCBView/RequestInfoCBView","36":"HistorySidebarContainer","37":"HistorySidebarController","38":"sidebar/FlowSidebarView","39":"sidebar/FlowSidebarController","40":"contextbar/contextbarView","41":"pull-request/components/PullRequestMeta/index","42":"changelog/components/CollectionChangelog","43":"pull-request/components/PullRequestComments","44":"fork/ForkListing","45":"components/DocumentationContextBarView","46":"controllers/DocumentationContextBarController","47":"postman-code-generators","48":"components/api-sidebar/APISidebarContainer/APISidebarContainer","49":"controllers/APISidebarController","50":"components/api-editor/api-context-bar/APIInfoContextBarView/APIInfoContextBarView","51":"components/api-editor/api-context-bar/CommentsContextBarView/APICommentsContextBarView","52":"components/api-version/context-bar/CommentsContextBarView/CommentsContextBarView","53":"components/api-version/context-bar/api-version-changelog/APIVersionChangelogContextBarView/APIVersionChangelogContextBarView","54":"components/api-version/context-bar/api-version-changelog/APIVersionChangelogContextBarView/APIVersionChangelogContextBarViewController","55":"components/api-version/context-bar/APIVersionInfoContextBarView/APIVersionInfoContextBarView","56":"components/release/context-bar/ReleaseInfoContextBarView/ReleaseInfoContextBarView","57":"components/release/context-bar/ReleaseChangelogContextBarView/ReleaseChangelogContextBarView","58":"components/release/context-bar/ReleaseChangelogContextBarView/ReleaseChangelogContextBarViewController","59":"schema/components/CodegenContextBarView/Code","60":"swagger1-to-postman","61":"swagger2-to-postmanv2","62":"@postman/dhc-to-postman","63":"raml1-to-postman","64":"raml-to-postman","65":"@postman/runscope-to-postman","66":"curl-to-postmanv2","67":"@postman/wadl-to-postman","68":"@postman/wsdl-to-postman","69":"openapi-to-postmanv2","70":"graphql-to-postman","71":"components/CodeCBView","72":"controllers/CodeCBController","73":"controllers/CommentsContextBarController","74":"StatusBarContainer","75":"WorkspaceBrowser","76":"controllers/RelatedCollectionsCBController","77":"components/context-bar/RelatedCollectionCBView","78":"containers/SchemaChangelogContainer","79":"react-table","80":"chart.js-legacy","81":"postman-runtime","82":"RequesterModalContainer","83":"jsonMode","84":"html","85":"htmlMode","86":"xml","87":"javascript","88":"tsMode","89":"markdown","90":"yaml","91":"graphql","92":"csharp","93":"cpp","94":"fsharp","95":"powershell","96":"go","97":"java","98":"objective-c","99":"php","100":"python","101":"ruby","102":"swift"}[chunkId]||chunkId) + ".js"
/******/ 	}
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/ 	// This file contains only the entry chunk.
/******/ 	// The chunk loading function for additional chunks
/******/ 	__webpack_require__.e = function requireEnsure(chunkId) {
/******/ 		var promises = [];
/******/
/******/
/******/ 		// mini-css-extract-plugin CSS loading
/******/ 		var cssChunks = {"2":1};
/******/ 		if(installedCssChunks[chunkId]) promises.push(installedCssChunks[chunkId]);
/******/ 		else if(installedCssChunks[chunkId] !== 0 && cssChunks[chunkId]) {
/******/ 			promises.push(installedCssChunks[chunkId] = new Promise(function(resolve, reject) {
/******/ 				var href = "" + ({"2":"CommonLazyChunk","11":"requester-legacy","12":"controllers/SideBarMockController","13":"components/SidebarMockListing","14":"components/MockInfoContextView","15":"controllers/MonitorSidebarController","16":"containers/MonitorSidebarContainer","17":"controllers/MonitorContextBarController","18":"containers/MonitorActivityLogs","19":"controllers/MonitorActivityDetailsController","20":"containers/MonitorActivityInfo","21":"contextbar/FolderInfoCBView/FolderInfoCBView","22":"contextbar/FolderInfoCBController","23":"text-editor","24":"sidebar/CollectionSidebarView","25":"sidebar/CollectionSidebarController","26":"contextbar/CollectionInfoCBView/CollectionInfoCBView","27":"contextbar/CollectionInfoCBController","28":"contextbar/GlobalsInfoCBView/GlobalsInfoCBView","29":"postman-converters","30":"sidebar/EnvironmentSidebarView","31":"sidebar/EnvironmentSidebarController","32":"contextbar/EnvironmentInfoCBView/EnvironmentInfoCBView","33":"contextbar/EnvironmentInfoCBController","34":"contextbar/ExampleInfoCBView/ExampleInfoCBView","35":"contextbar/RequestInfoCBView/RequestInfoCBView","36":"HistorySidebarContainer","37":"HistorySidebarController","38":"sidebar/FlowSidebarView","39":"sidebar/FlowSidebarController","40":"contextbar/contextbarView","41":"pull-request/components/PullRequestMeta/index","42":"changelog/components/CollectionChangelog","43":"pull-request/components/PullRequestComments","44":"fork/ForkListing","45":"components/DocumentationContextBarView","46":"controllers/DocumentationContextBarController","47":"postman-code-generators","48":"components/api-sidebar/APISidebarContainer/APISidebarContainer","49":"controllers/APISidebarController","50":"components/api-editor/api-context-bar/APIInfoContextBarView/APIInfoContextBarView","51":"components/api-editor/api-context-bar/CommentsContextBarView/APICommentsContextBarView","52":"components/api-version/context-bar/CommentsContextBarView/CommentsContextBarView","53":"components/api-version/context-bar/api-version-changelog/APIVersionChangelogContextBarView/APIVersionChangelogContextBarView","54":"components/api-version/context-bar/api-version-changelog/APIVersionChangelogContextBarView/APIVersionChangelogContextBarViewController","55":"components/api-version/context-bar/APIVersionInfoContextBarView/APIVersionInfoContextBarView","56":"components/release/context-bar/ReleaseInfoContextBarView/ReleaseInfoContextBarView","57":"components/release/context-bar/ReleaseChangelogContextBarView/ReleaseChangelogContextBarView","58":"components/release/context-bar/ReleaseChangelogContextBarView/ReleaseChangelogContextBarViewController","59":"schema/components/CodegenContextBarView/Code","60":"swagger1-to-postman","61":"swagger2-to-postmanv2","62":"@postman/dhc-to-postman","63":"raml1-to-postman","64":"raml-to-postman","65":"@postman/runscope-to-postman","66":"curl-to-postmanv2","67":"@postman/wadl-to-postman","68":"@postman/wsdl-to-postman","69":"openapi-to-postmanv2","70":"graphql-to-postman","71":"components/CodeCBView","72":"controllers/CodeCBController","73":"controllers/CommentsContextBarController","74":"StatusBarContainer","75":"WorkspaceBrowser","76":"controllers/RelatedCollectionsCBController","77":"components/context-bar/RelatedCollectionCBView","78":"containers/SchemaChangelogContainer","79":"react-table","80":"chart.js-legacy","81":"postman-runtime","82":"RequesterModalContainer","83":"jsonMode","84":"html","85":"htmlMode","86":"xml","87":"javascript","88":"tsMode","89":"markdown","90":"yaml","91":"graphql","92":"csharp","93":"cpp","94":"fsharp","95":"powershell","96":"go","97":"java","98":"objective-c","99":"php","100":"python","101":"ruby","102":"swift"}[chunkId]||chunkId) + ".css";
/******/ 				var fullhref = __webpack_require__.p + href;
/******/ 				var existingLinkTags = document.getElementsByTagName("link");
/******/ 				for(var i = 0; i < existingLinkTags.length; i++) {
/******/ 					var tag = existingLinkTags[i];
/******/ 					var dataHref = tag.getAttribute("data-href") || tag.getAttribute("href");
/******/ 					if(tag.rel === "stylesheet" && (dataHref === href || dataHref === fullhref)) return resolve();
/******/ 				}
/******/ 				var existingStyleTags = document.getElementsByTagName("style");
/******/ 				for(var i = 0; i < existingStyleTags.length; i++) {
/******/ 					var tag = existingStyleTags[i];
/******/ 					var dataHref = tag.getAttribute("data-href");
/******/ 					if(dataHref === href || dataHref === fullhref) return resolve();
/******/ 				}
/******/ 				var linkTag = document.createElement("link");
/******/ 				linkTag.rel = "stylesheet";
/******/ 				linkTag.type = "text/css";
/******/ 				linkTag.onload = resolve;
/******/ 				linkTag.onerror = function(event) {
/******/ 					var request = event && event.target && event.target.src || fullhref;
/******/ 					var err = new Error("Loading CSS chunk " + chunkId + " failed.\n(" + request + ")");
/******/ 					err.code = "CSS_CHUNK_LOAD_FAILED";
/******/ 					err.request = request;
/******/ 					delete installedCssChunks[chunkId]
/******/ 					linkTag.parentNode.removeChild(linkTag)
/******/ 					reject(err);
/******/ 				};
/******/ 				linkTag.href = fullhref;
/******/
/******/ 				var head = document.getElementsByTagName("head")[0];
/******/ 				head.appendChild(linkTag);
/******/ 			}).then(function() {
/******/ 				installedCssChunks[chunkId] = 0;
/******/ 			}));
/******/ 		}
/******/
/******/ 		// JSONP chunk loading for javascript
/******/
/******/ 		var installedChunkData = installedChunks[chunkId];
/******/ 		if(installedChunkData !== 0) { // 0 means "already installed".
/******/
/******/ 			// a Promise means "currently loading".
/******/ 			if(installedChunkData) {
/******/ 				promises.push(installedChunkData[2]);
/******/ 			} else {
/******/ 				// setup Promise in chunk cache
/******/ 				var promise = new Promise(function(resolve, reject) {
/******/ 					installedChunkData = installedChunks[chunkId] = [resolve, reject];
/******/ 				});
/******/ 				promises.push(installedChunkData[2] = promise);
/******/
/******/ 				// start chunk loading
/******/ 				var script = document.createElement('script');
/******/ 				var onScriptComplete;
/******/
/******/ 				script.charset = 'utf-8';
/******/ 				script.timeout = 120;
/******/ 				if (__webpack_require__.nc) {
/******/ 					script.setAttribute("nonce", __webpack_require__.nc);
/******/ 				}
/******/ 				script.src = jsonpScriptSrc(chunkId);
/******/
/******/ 				// create error before stack unwound to get useful stacktrace later
/******/ 				var error = new Error();
/******/ 				onScriptComplete = function (event) {
/******/ 					// avoid mem leaks in IE.
/******/ 					script.onerror = script.onload = null;
/******/ 					clearTimeout(timeout);
/******/ 					var chunk = installedChunks[chunkId];
/******/ 					if(chunk !== 0) {
/******/ 						if(chunk) {
/******/ 							var errorType = event && (event.type === 'load' ? 'missing' : event.type);
/******/ 							var realSrc = event && event.target && event.target.src;
/******/ 							error.message = 'Loading chunk ' + chunkId + ' failed.\n(' + errorType + ': ' + realSrc + ')';
/******/ 							error.name = 'ChunkLoadError';
/******/ 							error.type = errorType;
/******/ 							error.request = realSrc;
/******/ 							chunk[1](error);
/******/ 						}
/******/ 						installedChunks[chunkId] = undefined;
/******/ 					}
/******/ 				};
/******/ 				var timeout = setTimeout(function(){
/******/ 					onScriptComplete({ type: 'timeout', target: script });
/******/ 				}, 120000);
/******/ 				script.onerror = script.onload = onScriptComplete;
/******/ 				document.head.appendChild(script);
/******/ 			}
/******/ 		}
/******/ 		return Promise.all(promises);
/******/ 	};
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "../js/";
/******/
/******/ 	// on error function for async loading
/******/ 	__webpack_require__.oe = function(err) { console.error(err); throw err; };
/******/
/******/ 	var jsonpArray = window["webpackJsonp"] = window["webpackJsonp"] || [];
/******/ 	var oldJsonpFunction = jsonpArray.push.bind(jsonpArray);
/******/ 	jsonpArray.push = webpackJsonpCallback;
/******/ 	jsonpArray = jsonpArray.slice();
/******/ 	for(var i = 0; i < jsonpArray.length; i++) webpackJsonpCallback(jsonpArray[i]);
/******/ 	var parentJsonpFunction = oldJsonpFunction;
/******/
/******/
/******/ 	// add entry module to deferred list
/******/ 	deferredModules.push([9010,5,10]);
/******/ 	// run deferred modules when ready
/******/ 	return checkDeferredModules();
/******/ })
/************************************************************************/
/******/ ({

/***/ 14712:
/***/ (function(module, exports) {

module.exports = require("child_process");

/***/ }),

/***/ 592:
/***/ (function(module, exports) {

module.exports = require("electron");

/***/ }),

/***/ 594:
/***/ (function(module, exports) {

module.exports = require("path");

/***/ }),

/***/ 616:
/***/ (function(module, exports) {

module.exports = require("os");

/***/ }),

/***/ 674:
/***/ (function(module, exports) {

module.exports = require("fs");

/***/ }),

/***/ 720:
/***/ (function(module, exports) {

module.exports = require("zlib");

/***/ }),

/***/ 9010:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(9011);


/***/ }),

/***/ 9011:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9);
/* harmony import */ var _electron_ElectronService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1811);
/* harmony import */ var _styles_console_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9012);
/* harmony import */ var _styles_console_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_console_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _init__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9013);
/* harmony import */ var _controllers_theme_ThemeManager__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2161);
/* harmony import */ var _utils_TelemetryHelpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8853);
/* harmony import */ var _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1812);
/* harmony import */ var _runtime_repl_console_Console__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7721);
/* harmony import */ var _components_empty_states_CrashHandler__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2895);
/* harmony import */ var _shared_ThemeContext__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2345);
















if (false) {} else
if (window.SDK_PLATFORM !== 'browser') {
  window.onbeforeunload = () => {
    return false;
  };
}

/**
 * Shims requestIdleCallback in case a browser doesn't support it.
 */
window.requestIdleCallback = window.requestIdleCallback ||
function (cb) {
  return setTimeout(function () {
    var start = Date.now();
    cb({
      didTimeout: false,
      timeRemaining: function () {
        return Math.max(0, 50 - (Date.now() - start));
      } });

  }, 1);
};

window.cancelIdleCallback = window.cancelIdleCallback ||
function (id) {
  clearTimeout(id);
};

/**
 * Hides the placeholder loading state
 */
function hideLoadingState() {
  let loader = document.getElementsByClassName('pm-loader')[0];
  loader && loader.classList.add('is-hidden');
}

const rootEl = document.getElementById('app-root');

_init__WEBPACK_IMPORTED_MODULE_5__["default"].init((err) => {
  // We hide the loading state just before the point when we are rendering the console. Earlier,
  // this was happening while initializing ThemeDomDelegator. This was causing an issue where there
  // was a blank white screen rendered after the loader was hidden and before the console got
  // rendered. This was resulting in a jarring experience while loading the console.
  hideLoadingState();

  if (err) {
    Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["render"])( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_empty_states_CrashHandler__WEBPACK_IMPORTED_MODULE_10__["default"], { showError: true }), rootEl);
    return;
  }

  Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["render"])( /*#__PURE__*/
  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_empty_states_CrashHandler__WEBPACK_IMPORTED_MODULE_10__["default"], null, /*#__PURE__*/
  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_shared_ThemeContext__WEBPACK_IMPORTED_MODULE_11__["Theme"], null, /*#__PURE__*/
  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_2__["ToastProvider"], null, /*#__PURE__*/
  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_runtime_repl_console_Console__WEBPACK_IMPORTED_MODULE_9__["default"], {
    currentTheme: _controllers_theme_ThemeManager__WEBPACK_IMPORTED_MODULE_6__["default"].getCurrentTheme(),
    showBlobInModal: true,
    withDropdownRoot: true,
    showHeader: true,
    showFooter: true,
    isWindow: true })))),




  rootEl,
  () => {
    let loadTime = Object(_utils_TelemetryHelpers__WEBPACK_IMPORTED_MODULE_7__["getWindowLoadTime"])();

    // TODO: Finalize if these are the events we are going to emit and what the final console events going to be
    _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_8__["default"].addEvent('app_performance_metric', 'console_window_loaded', null, null, { load_time: loadTime });

    Object(_electron_ElectronService__WEBPACK_IMPORTED_MODULE_3__["getLaunchParams"])().
    then(([_w, params]) => {
      if (params.triggerSource === 'menuAction') {
        _modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_8__["default"].addEventV2({
          category: 'console',
          action: 'open_window',
          label: 'menubar' });

      }
    });
  });

});

/***/ }),

/***/ 9012:
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 9013:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var async_series__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(523);
/* harmony import */ var async_series__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(async_series__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _boot_bootAppModels__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8637);
/* harmony import */ var _boot_booted__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8746);
/* harmony import */ var _boot_bootThemeManager__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8747);
/* harmony import */ var _boot_bootConfig__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(570);
/* harmony import */ var _boot_bootConsole__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9014);
/* harmony import */ var _boot_bootCrashReporter__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8646);
/* harmony import */ var _boot_bootLogger__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(593);
/* harmony import */ var _boot_bootMessaging__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(781);
/* harmony import */ var _boot_bootSettings__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8641);
/* harmony import */ var _boot_bootTelemetry__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8644);
/* harmony import */ var _boot_bootWLModels__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(948);
/* harmony import */ var _boot_bootWindowConfig__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8689);
/* harmony import */ var _utils_DisableProcessThrottling__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8764);

















// Initialize the global window.pm.* API
window.pm = window.pm || {};

pm.init = (done) => {
  async_series__WEBPACK_IMPORTED_MODULE_0___default()([
  // Configure the window
  _boot_bootConfig__WEBPACK_IMPORTED_MODULE_4__["Config"].init({ process: 'console', ui: true }),

  // Initialize the pm.logger interface
  _boot_bootLogger__WEBPACK_IMPORTED_MODULE_7__["default"],

  // Initialize the pm.mediator event bus interface
  _boot_bootMessaging__WEBPACK_IMPORTED_MODULE_8__["default"],

  // Initialize sentry crash reporter
  _boot_bootCrashReporter__WEBPACK_IMPORTED_MODULE_6__["default"],

  // Initialize analytics interface
  _boot_bootTelemetry__WEBPACK_IMPORTED_MODULE_10__["default"],

  // Initialize the pm.settings interface
  _boot_bootSettings__WEBPACK_IMPORTED_MODULE_9__["default"],

  // Initialize the waterline indexDB models
  _boot_bootWLModels__WEBPACK_IMPORTED_MODULE_11__["default"],

  // Initialize pm.app and pm.appWindow interfaces
  _boot_bootAppModels__WEBPACK_IMPORTED_MODULE_1__["default"],

  // Initialize the theme manager
  _boot_bootThemeManager__WEBPACK_IMPORTED_MODULE_3__["default"],

  // Initialize the console window
  _boot_bootConsole__WEBPACK_IMPORTED_MODULE_5__["default"],

  // Initialize pm.window for menuManager shortcuts
  _boot_bootWindowConfig__WEBPACK_IMPORTED_MODULE_12__["bootWindowConfig"]],
  (err) => {
    Object(_boot_booted__WEBPACK_IMPORTED_MODULE_2__["default"])(err);
    if (err) {
      pm.logger.error('Error in console boot sequence', err);
    }

    // Disabling throttling for this process. This is to prevent electron from
    // throttling actions for this process even if it is running in the background
    Object(_utils_DisableProcessThrottling__WEBPACK_IMPORTED_MODULE_13__["default"])();

    done && done(err);
  });
};

/* harmony default export */ __webpack_exports__["default"] = (pm);

/***/ }),

/***/ 9014:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var async_series__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(523);
/* harmony import */ var async_series__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(async_series__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _bootShortcuts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8693);
/* harmony import */ var _bootStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8691);
/* harmony import */ var _controllers_GenericContextMenu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9015);
/* harmony import */ var _controllers_UIZoom__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8696);
/* harmony import */ var _models_ToastManager__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8683);
/* harmony import */ var _models_Toasts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8687);










/**
 * Boot the console window with stores
 * @param {*} cb
 */
function bootConsole(cb) {
  async_series__WEBPACK_IMPORTED_MODULE_0___default()([
  _bootStore__WEBPACK_IMPORTED_MODULE_2__["default"],
  _bootShortcuts__WEBPACK_IMPORTED_MODULE_1__["default"]],
  () => {
    _.assign(window.pm, {
      uiZoom: new _controllers_UIZoom__WEBPACK_IMPORTED_MODULE_4__["default"](),
      toasts: _models_Toasts__WEBPACK_IMPORTED_MODULE_6__,
      toastManager: new _models_ToastManager__WEBPACK_IMPORTED_MODULE_5__["default"](),

      // Disabling electron context menu in browser
      contextMenuManager: window.SDK_PLATFORM === 'browser' ? {} : new _controllers_GenericContextMenu__WEBPACK_IMPORTED_MODULE_3__["default"]() });


    pm.logger.info('Console~boot - Success');

    return cb && cb();
  });
}

/* harmony default export */ __webpack_exports__["default"] = (bootConsole);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 9015:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return GenericContextMenu; });
/* harmony import */ var _electron_ElectronService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1811);


class GenericContextMenu {
  constructor() {
    this.Remote = __webpack_require__(592).remote;
    this.Menu = this.Remote.Menu;
    this.MenuItem = this.Remote.MenuItem;
    this.currentSelection = '';

    /**
     * On right click in any input field, text gets automatically selected even if there was no explicit selection made before.
     * The text which gets automatically selected on right click, depends on the cursor position.
     */
    window.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      this.currentSelection = window.getSelection().toString();
      let menu = this.buildMenu(e);

      // Empty menu fix for windows native app
      if (menu && _.size(menu.items)) {
        menu.popup(Object(_electron_ElectronService__WEBPACK_IMPORTED_MODULE_0__["getCurrentWindow"])());
      }
    }, false);
  }

  buildMenu(e) {
    let menu = new this.Menu(),
    isInput = _.get(e, 'target.nodeName') === 'INPUT' || _.get(e, 'target.nodeName') === 'TEXTAREA',
    selectedText = this.currentSelection;

    // Resetting values so that context menu is not triggered on right clicking anywhere on the screen
    this.currentSelection = '';

    if (!_.isEmpty(selectedText) || isInput) {
      this.buildGenericMenu(menu);
    }
    return menu;
  }

  buildGenericMenu(menu) {

    menu.append(new this.MenuItem({
      label: '撤消',
      role: 'undo' }));

    menu.append(new this.MenuItem({
      label: '恢复',
      role: 'redo' }));

    menu.append(new this.MenuItem({ type: 'separator' }));
    menu.append(new this.MenuItem({
      label: '剪切',
      role: 'cut' }));

    menu.append(new this.MenuItem({
      label: '复制',
      role: 'copy' }));

    menu.append(new this.MenuItem({
      label: '粘贴',
      role: 'paste' }));

    menu.append(new this.MenuItem({
      label: '全选',
      role: 'selectall' }));

    menu.append(new this.MenuItem({ type: 'separator' }));
  }}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ })

/******/ });