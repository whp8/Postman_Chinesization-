(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[33],{

/***/ 9709:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EnvironmentInfoCBController; });
class EnvironmentInfoCBController {
  didCreate() {}}

/***/ })

}]);