(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[32],{

/***/ 9708:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EnvironmentInfoCBView; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2298);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1601);
/* harmony import */ var _common_components_molecule__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4068);
/* harmony import */ var _appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2862);
/* harmony import */ var _monitors_components_context_bar_MonitorContextBarList__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9689);
/* harmony import */ var _mocks_components_InfoPaneMockListing__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9690);










/**
 * Component for showing info about the environment in the context bar
 *
 * @component
 */
function EnvironmentInfoCBView(props) {
  const { id } = props.contextData,
  environment = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('EnvironmentStore').find(id),

  // @todo[EntityInTabs]: Pipe data via the EnvironmentInfoCBController
  info = environment ? {
    id: Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('CurrentUserStore').isLoggedIn ? environment.uid : id,
    createdOn: environment.createdAt,
    owner: environment.owner } :
  {};

  return /*#__PURE__*/(
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "environment-info-cb" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_4__["ContextBarViewHeader"], {
      title: "环境详情",
      onClose: props.onClose }), /*#__PURE__*/

    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "environment-info-cb__container" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_components_molecule__WEBPACK_IMPORTED_MODULE_3__["EntityMetaInfoView"], {
      userFriendlyEntityName: "environment",
      info: info }), /*#__PURE__*/

    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_mocks_components_InfoPaneMockListing__WEBPACK_IMPORTED_MODULE_6__["default"], {
      entity: "environment",
      environmentUid: info.id }), /*#__PURE__*/

    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_monitors_components_context_bar_MonitorContextBarList__WEBPACK_IMPORTED_MODULE_5__["MonitorContextBarList"], {
      entity: "environment",
      id: environment.uid }))));




}

EnvironmentInfoCBView.propTypes = {
  contextData: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  onClose: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func.isRequired };


EnvironmentInfoCBView.defaultProps = {
  contextData: {} };

/***/ })

}]);