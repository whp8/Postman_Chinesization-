(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[40],{

/***/ 9732:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = __importDefault(__webpack_require__(2));
const styled_components_1 = __importDefault(__webpack_require__(37));
const aether_1 = __webpack_require__(9);
const molecule_1 = __webpack_require__(4068);
const ContextBarViewHeader_1 = __webpack_require__(2862);
const InfoContainer = styled_components_1.default.div `
  padding: var(--spacing-zero) var(--spacing-s);
`;
function contextBarView(props) {
    const { id } = props.contextData, info = {
        id
    };
    return (react_1.default.createElement(aether_1.Flex, { direction: 'column' },
        react_1.default.createElement(ContextBarViewHeader_1.ContextBarViewHeader, { title: '流详情', onClose: props.onClose }),
        react_1.default.createElement(InfoContainer, null,
            react_1.default.createElement(molecule_1.EntityMetaInfoView, { userFriendlyEntityName: 'flow', info: info }))));
}
exports.default = contextBarView;


/***/ })

}]);