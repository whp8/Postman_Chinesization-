(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[51],{

/***/ 14686:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CommentsContextBarView; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2293);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1601);
/* harmony import */ var _js_utils_util__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1628);
/* harmony import */ var _collaboration_services_ContextBarCommentService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5052);
/* harmony import */ var _collaboration_components_comments_InlineCommentDrawer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5050);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _js_modules_services_InlineCommentTransformerService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5053);
/* harmony import */ var _appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2862);
/* harmony import */ var _common_APIOffline_APIOffline__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7507);
/* harmony import */ var _collaboration_services_PermissionService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5055);
/* harmony import */ var _collaboration_constants_comments__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2222);
/* harmony import */ var _collaboration_services_CollaborationNavigationService__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1843);
var _class;











let


CommentsContextBarView = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class CommentsContextBarView extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      loading: true,
      loadError: false,
      hasError: false,
      isOpenFilterSelected: true,
      isResolvedFilterSelected: false,
      isScrollable: true };


    this.rightOverlayModalRef = null;

    this.parseError = this.parseError.bind(this);
    this.handleRetry = this.handleRetry.bind(this);
    this.setCommentDrawerRef = this.setCommentDrawerRef.bind(this);
    this.stopScroll = this.stopScroll.bind(this);
    this.handleClose = this.handleClose.bind(this);
  }

  async componentDidMount() {
    this.setState({ loading: true, loadError: false });

    _js_modules_services_InlineCommentTransformerService__WEBPACK_IMPORTED_MODULE_7__["default"].handleAnalytics('api', 'view', 'api');

    _collaboration_services_ContextBarCommentService__WEBPACK_IMPORTED_MODULE_4__["default"].getComments({
      model: this.props.contextData.commentModel,
      modelId: this.props.contextData.commentModelId }).

    then(() => {
      /**
       * When ContextBarCommentService.getComments resolves it is not guaranteed that
       * CommentStore is fully done populating
       * hence we use requestIdleCallback to defer setting the loaded flag as true
       */
      requestIdleCallback(() => {
        Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('CommentStore').setLoaded(true);
        this.setState({ loading: false, loadError: false });
      });
    }).
    catch((e) => {
      this.setState({ loading: false, loadError: true });
    });

    // Permissions
    let permissions = ['addComment', 'deleteComment', 'resolveComment'],
    apiId = this.props.contextData.commentModelId,
    { addComment, deleteComment, resolveComment } = await Object(_collaboration_services_PermissionService__WEBPACK_IMPORTED_MODULE_10__["fetchPermissions"])(permissions, apiId, _collaboration_constants_comments__WEBPACK_IMPORTED_MODULE_11__["MODEL_TYPE"].API);

    this.setState({
      addCommentPermission: addComment,
      deleteCommentPermission: deleteComment,
      resolveCommentPermission: resolveComment });

  }

  componentDidUpdate() {
    if (!this.state.isResolvedFilterSelected) {
      const commentStore = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('CommentStore'),
      activeComment = commentStore.find(commentStore.activeCommentId),
      activeCommentAnnotation = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('AnnotationStore').find(_.get(activeComment, 'annotationId'));

      _.get(activeCommentAnnotation, 'status.resolved') && this.handleResolvedFilter();
    }
  }

  parseError(e) {
    if (!e.isFriendly) {
      return '';
    }

    return e.message;
  }

  handleRetry() {
    this.setState({ loading: true, loadError: false });

    return _collaboration_services_ContextBarCommentService__WEBPACK_IMPORTED_MODULE_4__["default"].getComments({
      model: this.props.contextData.commentModel,
      modelId: this.props.contextData.commentModelId }).

    then(() => {
      this.setState({ loading: false, loadError: false });
    }).
    catch((e) => {
      this.setState({ loading: false, loadError: true });
    });
  }

  setCommentDrawerRef(node) {
    this.commentDrawerRef = node;

    // Added as a hack to fix a bug where @ mentions
    // would crash the UI trying to create portal on `commentDrawerRef`
    // when it is not present
    this.commentDrawerRef && this.forceUpdate();
  }

  stopScroll(isScrollable) {
    this.setState({ isScrollable: !isScrollable });
  }

  handleClose() {
    this.props.onClose && this.props.onClose();

    // Removing comment query parameter from the URL when comment context bar is closed
    _collaboration_services_CollaborationNavigationService__WEBPACK_IMPORTED_MODULE_12__["default"].removeCommentQueryParam();
  }

  render() {
    let allComments,
    { commentModel, commentModelId, schemaId } = this.props.contextData || {};

    allComments = _.filter(Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('CommentStore').values, (comment) => {
      return comment.model === commentModel && comment.modelId === commentModelId;
    });

    const comments = _.sortBy(_.filter(allComments, (comment) => !comment.anchor ||
    comment.anchor === `${commentModel}/${commentModelId}`), 'createdAt') || [],
    title = this.props.contextData.model.name,
    currentUser = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('CurrentUserStore') || {},
    teamUserStore = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('TeamUserStore'),
    teamUsersMap = _.reduce(teamUserStore.values, (res, user) => {
      res[user.id] = {
        name: user.name,
        id: user.id,
        username: user.username,
        email: user.email,
        profilePicUrl: user.profilePicUrl,
        roles: user.roles };


      return res;
    }, {}),
    teamUsers = Object.values(teamUsersMap),
    isOffline = !Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('SyncStatusStore').isSocketConnected,
    isAdmin = _js_utils_util__WEBPACK_IMPORTED_MODULE_3__["default"].isUserAdmin(currentUser),
    annotationOrder = _.reduce((allComments || []).reverse(), (result, comment) => {
      if (!result.includes(comment.annotationId)) {
        result.push(comment.annotationId);
      }

      return result;
    }, []),
    commentStore = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('CommentStore'),
    activeComment = commentStore.find(commentStore.activeCommentId),
    setActiveComment = commentStore.setActiveCommentId;

    /**
     * For comments belonging to multiple API versions appropriate
     * versionId is to be sent as query param for comments link.
     * Hence here we create a map of annotationId to versionId to be sent as commentLinkParam
     */
    let commentLinkParams = _.reduce(allComments || [], (result, comment) => {
      let schemaId = comment && comment.anchor && _.get(comment.anchor.split('/'), '[3]'),
      version = (this.props.contextData.versions || []).filter((version) => schemaId === _.get(version, 'schema[0]')),
      versionId = _.get(version, '[0].id');

      versionId && (result[comment.annotationId] = { version: versionId });

      return result;
    }, {});

    if (isOffline && this.state.loading) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_8__["ContextBarViewHeader"], { onClose: this.props.onClose, title: '评论' }), /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_APIOffline_APIOffline__WEBPACK_IMPORTED_MODULE_9__["default"], { origin: "context-bar" })));


    }

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()({ 'comment-drawer-container': true, 'no-scroll': !this.state.isScrollable }),
        ref: this.setCommentDrawerRef }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_8__["ContextBarViewHeader"], { onClose: this.handleClose, title: '评论' }), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "comment-drawer" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_collaboration_components_comments_InlineCommentDrawer__WEBPACK_IMPORTED_MODULE_5__["default"], {
        editor: _.get(this.props.contextData, 'editor'),
        comments: allComments,
        requestComments: comments,
        isOpenFilterSelected: true,
        addCommentPermission: this.state.addCommentPermission,
        deleteCommentPermission: this.state.deleteCommentPermission,
        isAdmin: isAdmin,
        isOffline: isOffline,
        loading: this.state.loading,
        loadError: this.state.loadError,
        hasError: this.state.hasError,
        teamUsers: teamUsers,
        teamUsersMap: teamUsersMap,
        onRetry: this.handleRetry,
        user: currentUser,
        title: title,
        stopScroll: this.stopScroll,
        commentRef: this.commentDrawerRef,
        commentLinkDisabled: _.get(this.props.contextData, 'commentLinkDisabled'),
        model: 'api',
        modelId: _.get(this.props.contextData, 'commentModelId'),
        commentLinkParams: commentLinkParams,
        origin: "contextBar",
        anchor: _.get(this.props.contextData, 'anchor') }))));




  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ })

}]);