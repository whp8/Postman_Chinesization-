(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[58],{

/***/ 14705:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ReleaseChangelogContextBarViewController; });
/* harmony import */ var _postman_date_helper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2304);
/* harmony import */ var _postman_date_helper__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_postman_date_helper__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _schema_services_ChangelogService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(14699);
/* harmony import */ var _js_stores_CollectionActivityFeedStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8449);
/* harmony import */ var _services_APIDevService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2255);
function _extends() {_extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};return _extends.apply(this, arguments);}





// @TODO: Move this to a service to serve as a common place for both release and API version changelog
// Purpose: Fetch and combine the data as needed for the combined changelog view
class ReleaseChangelogContextBarViewController {

  async fetchChangelog(model) {
    try {
      let combinedChangeLog = [],
      schemaChangeLog = [],
      fetchAllChangelog = [],
      collectionChangelogStores = [],
      fetchSchemaPromise = this.handleFetchSchemaChangelog(model);

      fetchAllChangelog.push(fetchSchemaPromise);

      this.handleFetchCollectionChangelog(model, fetchAllChangelog, collectionChangelogStores);

      // Resolve all promises to fetch changelogs
      const groupedChangelogs = await Promise.all(fetchAllChangelog);

      // First element in schema changelog
      schemaChangeLog = _.head(groupedChangelogs);

      // Adding an extra field 'changeType' with value as 'schema'
      // Using this key SchemaChange will be rendered as this is a schema change
      combinedChangeLog = schemaChangeLog.revisions.map((change) => _extends({}, change, { changeType: 'schema', enableRestore: false }));

      // Adding an extra field 'changeType' with value as 'collection'
      // Using this key CollectionChange will be rendered as this is a collection change
      _.map(collectionChangelogStores, (collectionChangelogStore) => {
        const collectionChangelog = _.map(_.get(collectionChangelogStore, 'feeds', []), (change) => _extends({},
        change, { changeType: 'collection',
          meta: collectionChangelogStore.meta,
          collectionUid: _.get(collectionChangelogStore, 'collectionUid'),
          enableRestore: false }));


        combinedChangeLog = _.concat(combinedChangeLog, collectionChangelog);
      });

      // Chronologically sorting combined changelog in descending order
      combinedChangeLog = _.
      chain(combinedChangeLog).
      sortBy('createdAt').
      reverse().
      value();

      const releases = await _services_APIDevService__WEBPACK_IMPORTED_MODULE_3__["default"].getAllReleases(_.get(model, 'api.id'), _.get(model, 'apiVersion.id'), 'gitTag'),
      releaseGroups = this.groupChangesByRelease(combinedChangeLog, releases),
      currentReleaseGroup = _.find(releaseGroups, (releaseGroup) => releaseGroup.id === _.get(model, 'activeRelease.id'));

      return currentReleaseGroup;
    }
    catch (err) {
      throw err;
    }
  }

  groupChangesByRelease(changelog, releases) {
    // @TODO remove this and ensure from server the releases are pre sorted
    let releaseGroups = _.
    chain(releases).
    sortBy('createdAt').
    reverse().
    value();

    // Pushing Unreleased changes block to the beginning of releases
    releaseGroups.unshift({
      name: 'Unreleased Changes',
      id: 'unreleasedChanges' });


    let changeIterator = 0,
    releaseIterator = 0;

    while (changeIterator < changelog.length) {
      const change = changelog[changeIterator],
      currentRelease = releaseGroups[releaseIterator],
      nextRelease = releaseGroups[releaseIterator + 1];

      if (releaseIterator === releaseGroups.length - 1 || change.createdAt > nextRelease.createdAt) {
        !currentRelease.changelog ? currentRelease.changelog = [change] :
        currentRelease.changelog.push(change);

        changeIterator++;
      } else
      {
        releaseIterator++;
      }
    }

    releaseGroups = releaseGroups.map((releaseGroup) => {
      const changesGroupedByDate = _postman_date_helper__WEBPACK_IMPORTED_MODULE_0___default.a.getDateGroups(releaseGroup.changelog, 'createdAt', 'MMMM D, YYYY');

      return _extends({}, releaseGroup, { changesGroupedByDate });
    });

    return releaseGroups;
  }

  handleFetchSchemaChangelog(model) {
    const maxId = null,
    apiId = _.get(model, 'api.id'),
    versionId = _.get(model, 'apiVersion.id'),
    schemaId = _.get(model, 'activeRelease.entities.schemas[0].entityId');

    // Handle Schema doesn't exist case gracefully
    if (!schemaId) {
      return Promise.resolve({ revisions: [] });
    }

    return Object(_schema_services_ChangelogService__WEBPACK_IMPORTED_MODULE_1__["fetchChangelog"])(apiId, versionId, schemaId, maxId);
  }

  handleFetchCollectionChangelog(model, fetchAllChangelog, collectionChangelogStores) {
    _.map(_.get(model, 'activeRelease.entities'), (relationType) => {
      _.map(relationType, (relation) => {
        const collectionChangeLogStore = new _js_stores_CollectionActivityFeedStore__WEBPACK_IMPORTED_MODULE_2__["default"]();

        fetchAllChangelog.push(collectionChangeLogStore.initialize(relation.entityId));
        collectionChangelogStores.push(collectionChangeLogStore);
      });
    });
  }}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ })

}]);