(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[57],{

/***/ 14704:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ReleaseChangelogContextBarView; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2293);
/* harmony import */ var _appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2862);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _api_version_context_bar_api_version_changelog_APIVersionChangelogGroup_APIVersionChangelogGroup__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(14689);
/* harmony import */ var _js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2322);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1601);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2325);
/* harmony import */ var _schema_components_ErrorChangelog__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(14692);
/* harmony import */ var _schema_components_OfflineChangelog__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(14691);
var _class;










let


ReleaseChangelogContextBarView = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class ReleaseChangelogContextBarView extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      releaseGroup: {},
      isLoading: true,
      loadingErr: false };


    this.fetchChangelogs = this.fetchChangelogs.bind(this);
  }

  componentDidMount() {
    this.fetchChangelogs();
  }

  getRefreshTextClass() {
    return classnames__WEBPACK_IMPORTED_MODULE_3___default()({
      'release-changelog-context-view-wrapper__refresh-button': true,
      'release-changelog-context-view-wrapper__refresh-button__loading': this.state.isLoading });

  }

  getRefreshIconText() {
    const isOffline = !Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('SyncStatusStore').isSocketConnected;

    if (isOffline) {
      return '联网以执行此操作';
    }

    if (this.state.isLoading) {
      return '请稍等...';
    }

    return '刷新更新日志';
  }

  fetchChangelogs() {
    this.setState({
      releaseGroup: {},
      isLoading: true,
      loadingErr: false });


    this.props.controller.fetchChangelog(_.get(this.props, 'contextData.model', {})).
    then((releaseGroup) => {
      this.setState({
        releaseGroup: releaseGroup,
        isLoading: false });

    }).catch((error) => {
      this.setState({
        isLoading: false,
        loadingErr: true });

    });
  }

  renderChangelog() {
    const isOffline = !Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('SyncStatusStore').isSocketConnected;

    if (isOffline && this.state.isLoading) {
      return /*#__PURE__*/ (

        // @TODO: Recreate these base components for Release changelog
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_schema_components_OfflineChangelog__WEBPACK_IMPORTED_MODULE_10__["default"], null));

    }

    if (this.state.isLoading) {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_5__["default"], null);
    }

    if (this.state.loadingErr) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_schema_components_ErrorChangelog__WEBPACK_IMPORTED_MODULE_9__["default"], {
          onRetry: this.fetchChangelogs }));

    }

    const model = _.get(this.props, 'contextData.model', {});

    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "release-changelog" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_api_version_context_bar_api_version_changelog_APIVersionChangelogGroup_APIVersionChangelogGroup__WEBPACK_IMPORTED_MODULE_4__["default"], {
      model: model,
      release: this.state.releaseGroup,
      promoteTab: _.get(this.props, 'contextData.promoteTab'),
      isLastRelease: true }));


  }

  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "release-changelog-context-view-wrapper" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_2__["ContextBarViewHeader"], {
        title: this.props.title,
        onClose: this.props.onClose }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_8__["Button"], {
        className: this.getRefreshTextClass(),
        tooltip: this.getRefreshIconText(),
        tooltipImmediate: true,
        type: "tertiary",
        onClick: this.fetchChangelogs,
        disabled: this.state.isLoading ||
        !Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('SyncStatusStore').isSocketConnected }, /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_7__["Icon"], {
        name: "icon-action-refresh-stroke" }))),



      this.renderChangelog()));


  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ })

}]);