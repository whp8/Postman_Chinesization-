(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[56],{

/***/ 14703:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ReleaseInfoContextBarView; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2293);
/* harmony import */ var _appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2862);
/* harmony import */ var _js_utils_ClipboardHelper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2346);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2325);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3737);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _js_utils_util__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1628);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_Avatar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4190);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1601);
var _class;










const COPIED_TICK_DURATION = 3000;let


ReleaseInfoContextBarView = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class ReleaseInfoContextBarView extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      isCopyingReleaseId: false };


    this.handleCopyReleaseIdToClipboard = this.handleCopyReleaseIdToClipboard.bind(this);
    this.renderReleaseEditor = this.renderReleaseEditor.bind(this);
  }

  componentWillUnmount() {
    clearTimeout(this.copiedTimeout);
  }

  /**
   * Copies releaseId to clipboard and changes icon state for copy status
   * from copy to success tick and then back to copy icon.
   */
  handleCopyReleaseIdToClipboard() {
    const releaseId = _.get(this.props, 'contextData.model.activeRelease.id', '');

    if (this.state.isCopyingReleaseId) {
      return;
    }

    _js_utils_ClipboardHelper__WEBPACK_IMPORTED_MODULE_3__["default"].copy(releaseId);

    this.setState({ isCopyingReleaseId: true },
    () => {
      this.copiedTimeout = setTimeout(
      () => this.setState({ isCopyingReleaseId: false }),
      COPIED_TICK_DURATION);

    });
  }

  renderReleaseEditor(userId) {
    const currentUserStore = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('CurrentUserStore');

    if (userId) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: "release-info-editors__editor",
          key: userId }, /*#__PURE__*/

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Avatar__WEBPACK_IMPORTED_MODULE_8__["default"], {
          ref: "avatar",
          size: "medium",
          userId: userId }), /*#__PURE__*/

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "release-info-editors__editor--name" },
        _js_utils_util__WEBPACK_IMPORTED_MODULE_7__["default"].getUserNameForId(userId, currentUserStore))));



    }

    return '无效的用户';
  }

  renderReleaseIdCopyStatusIcon() {
    if (this.state.isCopyingReleaseId) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_5__["Icon"], {
          name: "icon-state-success-stroke",
          className: "pm-icon pm-icon-normal success-tick-icon" }));


    }

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_5__["Icon"], {
        name: "icon-action-copy-stroke",
        className: "pm-icon pm-icon-normal" }));


  }

  render() {
    const release = _.get(this.props, 'contextData.model.activeRelease', {}),
    userFriendlyReleaseCreatedAt = moment__WEBPACK_IMPORTED_MODULE_6___default()(_.get(release, 'createdAt')).format('DD MMM YYYY, h:mm A'),
    userId = _.get(release, 'createdBy'),
    releaseId = _.get(release, 'id');

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "release-info-context-view-wrapper" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_2__["ContextBarViewHeader"], {
        title: '发行详情',
        onClose: this.props.onClose }), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "release-info-context-view" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "release-info-context-view__entity" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "release-info-context-view__entity__label" }, "发行 ID"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "release-info-context-view__entity__content" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "release-info-context-view__entity__content__id--entity",
        title: releaseId },

      releaseId), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_4__["Button"], {
        tooltip: "拷贝",
        type: "icon",
        onClick: this.handleCopyReleaseIdToClipboard },

      this.renderReleaseIdCopyStatusIcon()))), /*#__PURE__*/



      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "release-info-context-view__entity" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "release-info-context-view__entity__label" }, "创建者"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "release-info-context-view__entity__content" },
      this.renderReleaseEditor(userId))), /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "release-info-context-view__entity" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "release-info-context-view__entity__label" }, "创建于"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "release-info-context-view__entity__content" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "release-info-context-view__entity__content__id",
        title: userFriendlyReleaseCreatedAt },

      userFriendlyReleaseCreatedAt))))));






  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ })

}]);