(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[77],{

/***/ 17878:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return RelatedCollectionsCBView; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(518);
/* harmony import */ var uuid_v4__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(uuid_v4__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1595);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2293);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2325);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1601);
/* harmony import */ var _services_SearchService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2888);
/* harmony import */ var _js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2322);
/* harmony import */ var _utils_index__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8167);
/* harmony import */ var _appsdk_components_link_Link__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2687);
/* harmony import */ var _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1812);
/* harmony import */ var _runtime_repl_collection_api_CollectionInterface__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2369);
/* harmony import */ var _RelatedCollectionListItem__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(17879);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(2886);
var _class;














let


RelatedCollectionsCBView = Object(mobx_react__WEBPACK_IMPORTED_MODULE_3__["observer"])(_class = class RelatedCollectionsCBView extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);this.







































































































































































    handleCollectionFork = (collectionId, index) => {
      // Using custom onFork function as the ForkButton component does not add Analytics event

      _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_12__["default"].addEventV2AndPublish({
        category: 'related',
        action: 'fork',
        label: 'collection-forked',
        value: index,
        entityType: 'collection',
        entityId: collectionId,
        traceId: this.traceId });


      if (!Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('CurrentUserStore').isLoggedIn) {
        pm.mediator.trigger('showSignInModal', {
          type: 'fork',
          origin: 'fork_collection_modal' });


        return;
      }

      return Object(_runtime_repl_collection_api_CollectionInterface__WEBPACK_IMPORTED_MODULE_13__["collectionActions"])(collectionId, 'fork', null, { origin: 'request-contextbar' });
    };this.state = { isLoading: true, relatedCollections: [], loadError: false, loadEmpty: false, hasMoreResults: false, loadingMore: false, requestUrl: '', currentOffset: 0 };this.traceId = '';this.fetchRelatedCollections = _.debounce(this.fetchRelatedCollections.bind(this), 1000);this.sanitizedCountPlaceholder = this.sanitizedCountPlaceholder.bind(this);this.getCollectionUrl = this.getCollectionUrl.bind(this);this.requestOrigin = 'contextBarRecommendation';this.handleCollectionFork = this.handleCollectionFork.bind(this);this.sanitizedCountPlaceholder = this.sanitizedCountPlaceholder.bind(this);this.hideForkInfo = true;this.relatedCollectionsList = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createRef();this.handleScroll = _.debounce(this.handleScroll.bind(this), 1000);}componentDidMount() {const traceIdFromCallout = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('SearchStore').relatedCollectionsTraceId;this.traceId = traceIdFromCallout ? traceIdFromCallout : uuid_v4__WEBPACK_IMPORTED_MODULE_1___default()();let { type: entityType, id: entityId } = this.props.contextData;_js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_12__["default"].addEventV2AndPublish({ category: 'related', action: 'initiate', entityType, entityId, traceId: this.traceId }); // Fetch related collections every time the user changes request or environment
    this.disposePreviewReaction = Object(mobx__WEBPACK_IMPORTED_MODULE_2__["reaction"])(() => {let editor = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('EditorStore').find(this.props.contextData.editorId),editorModel = editor && editor.model,request = editorModel.resourceToSave(),activeEnvId = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveEnvironmentStore').id;return request.url + activeEnvId;}, () => {this.fetchRelatedCollections(this.props.contextData.editorId);});this.fetchRelatedCollections(this.props.contextData.editorId);}componentWillUnmount() {this.disposePreviewReaction && this.disposePreviewReaction();_.invoke(this.relatedCollectionsList, 'removeEventListener', 'scroll');}handleScroll() {if (this.relatedCollectionsList.scrollTop + this.relatedCollectionsList.clientHeight >= this.relatedCollectionsList.scrollHeight) {!this.state.loadingMore && this.state.hasMoreResults && this.loadMoreCollections();}}loadMoreCollections() {this.setState({ loadingMore: true });const { requestUrl, currentOffset } = this.state;_services_SearchService__WEBPACK_IMPORTED_MODULE_8__["default"].getRequestRelatedCollections(requestUrl, this.traceId, this.props.contextData.parentCollectionUid, this.requestOrigin, _constants__WEBPACK_IMPORTED_MODULE_15__["RELATED_COLLECTIONS_CB_COUNT"], currentOffset).then((response) => {let collectionResults = _.get(response, 'data', []),currentData = this.state.relatedCollections;this.setState({ relatedCollections: _.concat(currentData, collectionResults), hasMoreResults: response.meta.total > currentOffset + _constants__WEBPACK_IMPORTED_MODULE_15__["RELATED_COLLECTIONS_CB_COUNT"], currentOffset: currentOffset + _constants__WEBPACK_IMPORTED_MODULE_15__["RELATED_COLLECTIONS_CB_COUNT"], loadingMore: false });}).catch((err) => {pm.logger.error('RelatedCollectionCBView~loadMoreCollections: Failed to fetch more related collections');this.setState({ loadingMore: false });});} /**
   * @param {Number} infoCount - Metric count
   * @param {String} infoType - Metric name, e.g. forks, views, etc
   * @returns {String} sanitizedMetric - User friendly metric count
   */sanitizedCountPlaceholder(infoCount, infoType) {if (_.isUndefined(infoCount)) {infoCount = 0;}infoCount = _utils_index__WEBPACK_IMPORTED_MODULE_10__["default"].convertToUserFriendlyMetric(infoCount);return `${infoCount} ${infoType}`;} /**
   * Grey matter of the component, fetches related collections from the request editor
   *
   * @param {String} editorId - Active editor id from which request url would be extracted
   */fetchRelatedCollections(editorId) {this.setState({ isLoading: true, loadError: false, relatedCollections: [] });this.props.controller.getResolvedRequest(editorId).then((requestUrl) => {this.setState({ requestUrl });if (requestUrl === '' || requestUrl.length === 0) {return {};}return _services_SearchService__WEBPACK_IMPORTED_MODULE_8__["default"].getRequestRelatedCollections(requestUrl, this.traceId, this.props.contextData.parentCollectionUid, this.requestOrigin, _constants__WEBPACK_IMPORTED_MODULE_15__["RELATED_COLLECTIONS_CB_COUNT"]);}).then((searchResponse) => {let filteredCollections = _.get(searchResponse, 'data', []);if (filteredCollections.length === 0) {this.setState({ relatedCollections: [], isLoading: false });} else {let { type: entityType, id: entityId } = this.props.contextData;_js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_12__["default"].addEventV2AndPublish({ category: 'related', action: 'view', value: filteredCollections.length, entityType, entityId, traceId: this.traceId });this.setState({ relatedCollections: filteredCollections, isLoading: false, currentOffset: _constants__WEBPACK_IMPORTED_MODULE_15__["RELATED_COLLECTIONS_CB_COUNT"], hasMoreResults: searchResponse.meta.total > _constants__WEBPACK_IMPORTED_MODULE_15__["RELATED_COLLECTIONS_CB_COUNT"] }, () => {this.relatedCollectionsList.addEventListener('scroll', this.handleScroll);});}}).catch((err) => {pm.logger.error('RelatedCollectionCBView~fetchRelatedCollections: Failed to fetch related collections');this.setState({ relatedCollections: [], isLoading: false, loadError: true });});} /**
   * Generates the redirection url for displayed related collections
   *
   * @param {Object} collection - Context about the collection
   * @returns {String} Redirection url string for the input collection
   */getCollectionUrl(collection) {// @TODO - Will be replaced by FQURL once missing data points are available
    return `${window.postman_explore_url}/v1/backend/redirect?type=${collection.entityType}&id=${collection.id}&publisherType=${collection.publisherType}&publisherId=${collection.publisherId}`;} /**
   * Maps the fetched related collections in the Context bar
   *
   * @param {Object} collections - Collections to be mapped
   * @returns {JSX}
   */getCollectionList(collections) {if (collections.length === 0) {
      return;
    }

    let { type: entityType, id: entityId } = this.props.contextData;

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "related-collections-cb__list", ref: (ref) => this.relatedCollectionsList = ref },

      collections.map((collectionOverview, index) => {
        const collection = collectionOverview.document,
        redirectUrl = this.getCollectionUrl(collection);

        return /*#__PURE__*/(
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_RelatedCollectionListItem__WEBPACK_IMPORTED_MODULE_14__["default"], { key: index,
            collection: collection,
            redirectUrl: redirectUrl,
            sanitizedCountPlaceholder: this.sanitizedCountPlaceholder,
            hideForkInfo: this.hideForkInfo,
            traceId: this.traceId,
            contextData: this.props.contextData,
            handleCollectionFork: this.handleCollectionFork,
            index: index }));


      }),

      this.state.loadingMore && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "related-collections-cb__list-load-more" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_9__["default"], null)), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "related-collections-cb__list-footer" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, "探索更多集合在"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { type: "link-subtle" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_components_link_Link__WEBPACK_IMPORTED_MODULE_11__["default"], {
        to: `${window.postman_explore_redirect_url}/collections`,
        className: "lead-link",
        onClick: () => {
          _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_12__["default"].addEventV2AndPublish({
            category: 'related',
            action: 'click',
            label: 'explore',
            entityType,
            entityId,
            traceId: this.traceId });

        } }, "公共API网络")), ".")));




  }

  /**
   * Renders Server/Client error state
   *
   * @returns {JSX}
   */
  getErrorState() {
    let errorHeading = '无法加载相关集合',
    errorSubheading = '无法加载相关集合. 尝试重新加载.',
    editorId = this.props.contextData.editorId;

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "related-collections-cb__error" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_5__["IllustrationInternalServerError"], null), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "related-collections-cb__error-message-subheading" }, errorSubheading), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_5__["Button"], {
        text: "重新加载",
        type: "outline",
        size: "small",
        onClick: () => this.fetchRelatedCollections(editorId) })));



  }

  /**
   * Renders the state when no collections is available for the given request url
   *
   * @returns {JSX}
   */
  getEmptyState() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "related-collections-cb__empty-state" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_5__["IllustrationNoCollection"], null), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "related-collections-cb__empty-state-heading" }, "没有相关的集合"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "related-collections-cb__empty-state-subheading" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, "尝试不同的请求或探索集合在"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { type: "link-subtle" }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_components_link_Link__WEBPACK_IMPORTED_MODULE_11__["default"], { to: window.postman_explore_redirect_url, className: "lead-link" }, "公共API网络")))));



  }

  render() {
    let { isLoading, relatedCollections, loadError } = this.state;

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "related-collections-cb" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: classnames__WEBPACK_IMPORTED_MODULE_4___default()('right-context-bar-header', this.props.className) }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", { className: "right-context-bar__title" }, this.props.title, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_5__["Badge"], { status: "info", text: "测试", className: "related-collections-cb-badge" })), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "right-context__actions-container" },
      this.props.children, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_6__["Button"], {
        className: "context-bar-actions__button",
        type: "tertiary",
        onClick: this.props.onClose }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_5__["Icon"], {
        name: "icon-action-close-stroke",
        className: "right-context-bar__close-icon" })))),




      !isLoading ?
      !loadError ?
      relatedCollections.length > 0 ? /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "related-collections-cb__container" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "related-collections-cb__subheading" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_5__["Text"], { type: "body-medium", color: "content-color-secondary" }, "发现最符合您要求的公共集合")),



      this.getCollectionList(relatedCollections)) :



      this.getEmptyState() :


      this.getErrorState() : /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "related-collections-cb__loader" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_9__["default"], { className: "related-collections-cb__loader-item" }))));




  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 17879:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return RelatedCollectionListItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9);
/* harmony import */ var _appsdk_components_link_Link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2687);
/* harmony import */ var _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1812);
/* harmony import */ var _version_control_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4502);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1601);







/**
 * Return collection item for Related collection in Context bar
 *
 * @param {Object} props
 * @returns RelatedCollectionListItem
 */
function RelatedCollectionListItem(props) {
  const { collection: { id, name, publisherName, workspaces, views, forkLabel }, redirectUrl, index } = props;

  return /*#__PURE__*/(
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "related-collections-cb__list-item" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "related-collections-cb__list-item-details" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "related-collections-cb__list-item-profile-icon" }), /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "related-collections-cb__list-item-info" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "related-collections-cb__list-item-title-wrapper" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["Text"], { color: "content-color-primary" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["Text"], {
      type: "link-subtle",
      className: "related-collections-cb__list-item-title" }, /*#__PURE__*/

    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_components_link_Link__WEBPACK_IMPORTED_MODULE_2__["default"], { to: redirectUrl, onClick: (e) => {
        _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_3__["default"].addEventV2AndPublish({
          category: 'related',
          action: 'view-collection',
          value: index,
          label: 'public-collection',
          entityType: 'collection',
          entityId: id,
          traceId: props.traceId });

      } },
    name)))), /*#__PURE__*/



    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "related-collections-cb__list-item-meta" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "related-collections-cb__list-item-meta-row" },
    forkLabel && /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "related-collections-cb__list-item-fork-label" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["Icon"], { name: "icon-action-fork-stroke-small",
      color: "content-color-secondary",
      size: "small",
      className: "related-collections-cb__list-item-fork-label-icon" }), /*#__PURE__*/

    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "related-collections-cb__list-item-fork-label-text" }, forkLabel))), /*#__PURE__*/



    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "related-collections-cb__list-item-meta-row" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["Text"], { type: "body-medium", color: "content-color-secondary" },
    publisherName)), /*#__PURE__*/


    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "related-collections-cb__list-item-meta-row" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["Icon"], {
      name: "icon-action-view-stroke-small",
      color: "content-color-tertiary",
      size: "small",
      className: "related-collections-cb__list-item-meta-row-icon" }), /*#__PURE__*/

    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["Text"], { type: "body-medium", color: "content-color-secondary" },
    props.sanitizedCountPlaceholder(views, 'views')))))), /*#__PURE__*/





    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "related-collections-cb__list-item-fork-button" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_version_control_components__WEBPACK_IMPORTED_MODULE_4__["ForkButton"], {
      modelId: id,
      model: "collection",
      origin: "request-contextbar",
      disabled: !Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('SyncStatusStore').isSocketConnected,
      disabledTooltip: "在线创建分叉或查看现有分叉.",
      className: "related-collections-cb__list-item-fork-button",
      onFork: () => props.handleCollectionFork(id, index),
      workspaceId: _.get(workspaces, '0.id') }))));





}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ })

}]);