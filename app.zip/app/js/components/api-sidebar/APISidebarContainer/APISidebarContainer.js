(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[48],{

/***/ 14677:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return APISidebarContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2293);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _js_components_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2314);
/* harmony import */ var _APISidebarMenu_APISidebarMenu__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(14678);
/* harmony import */ var _APISidebarList_APISidebarList__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(14679);
/* harmony import */ var _js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2856);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1601);
/* harmony import */ var _services_APIPermissionService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7279);
/* harmony import */ var _common_APIOffline_APIOffline__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7507);
/* harmony import */ var _appsdk_workbench_TabService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2377);
/* harmony import */ var _navigation_constants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5198);
/* harmony import */ var _api_version_CreateAPIVersionModal_CreateAPIVersionModal__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7282);
var _class;













let


APISidebarContainer = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class APISidebarContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.apiListStore;
    this.apiSidebarStore;

    this.focus = this.focus.bind(this);
    this.focusNext = this.focusNext.bind(this);
    this.focusPrev = this.focusPrev.bind(this);
    this.selectItem = this.selectItem.bind(this);
    this.renameItem = this.renameItem.bind(this);
    this.handleDeleteShortcut = this.handleDeleteShortcut.bind(this);
    this.toggleDeleteModal = this.toggleDeleteModal.bind(this);
    this.toggleRemoveFromWSModal = this.toggleRemoveFromWSModal.bind(this);
    this.onVersionCreate = this.onVersionCreate.bind(this);
  }

  focus() {
    let sidebar = Object(react_dom__WEBPACK_IMPORTED_MODULE_2__["findDOMNode"])(this.refs.sidebar);
    sidebar && sidebar.focus();
  }

  isWorkspaceMember() {
    return Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveWorkspaceStore').isMember;
  }

  isLoggedIn() {
    return Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('CurrentUserStore').isLoggedIn;
  }

  getKeyMapHandlers() {
    return {
      nextItem: pm.shortcuts.handle('nextItem', this.focusNext),
      prevItem: pm.shortcuts.handle('prevItem', this.focusPrev),
      select: pm.shortcuts.handle('select', this.selectItem),
      delete: pm.shortcuts.handle('delete', this.handleDeleteShortcut),
      rename: pm.shortcuts.handle('rename', this.renameItem) };

  }

  focusNext(e) {
    e && e.preventDefault();
    this.apiSidebarStore.focusNext();
  }

  focusPrev(e) {
    e && e.preventDefault();
    this.apiSidebarStore.focusPrev();
  }

  selectItem() {
    this.apiSidebarStore.openEditor(this.apiSidebarStore.activeItem);
  }

  renameItem() {
    let apiId = this.apiSidebarStore.activeItem;

    // Show showSignInModal if user is not signed in
    if (!this.isLoggedIn()) {
      return pm.mediator.trigger('showSignInModal', {
        type: 'rename_API',
        origin: 'API_sidebar',
        continueUrl: new URL(window.location.href) });

    }

    if (!this.isWorkspaceMember()) {
      return pm.mediator.trigger('openUnjoinedWorkspaceModal');
    }

    apiId && this.refs.list.refs[apiId].handleEditName();
  }

  handleDeleteShortcut() {
    if (!this.isWorkspaceMember()) {
      return pm.mediator.trigger('openUnjoinedWorkspaceModal');
    }

    if (!Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('CurrentUserStore').isLoggedIn) {
      return pm.mediator.trigger('showSignInModal', {
        type: 'delete_API',
        origin: 'API_sidebar',
        continueUrl: new URL(window.location.href) });

    }

    let id = this.apiSidebarStore.activeItem,
    name = id && _.find(this.apiSidebarStore.sortedAPIs, (api) => api.id === id).name;

    id && name && this.toggleDeleteModal(id, name);
  }

  toggleDeleteModal(apiId) {
    pm.mediator.trigger('showAPIDeleteModal', apiId);
  }

  toggleRemoveFromWSModal(apiId) {
    const canDeleteAPI = _services_APIPermissionService__WEBPACK_IMPORTED_MODULE_8__["default"].hasPermission(this.apiListStore.permissions, 'delete', 'api', apiId),
    canShareAPI = _services_APIPermissionService__WEBPACK_IMPORTED_MODULE_8__["default"].hasPermission(this.apiListStore.permissions, 'share', 'api', apiId);

    pm.mediator.trigger('showRemoveFromWorkspaceModal', apiId, {
      type: 'api',
      origin: 'sidebar',
      disableDelete: !canDeleteAPI,
      disableShare: !canShareAPI },
    () => {
      // Close tab after removing the API from workspace
      _appsdk_workbench_TabService__WEBPACK_IMPORTED_MODULE_10__["default"].closeByRoute(_navigation_constants__WEBPACK_IMPORTED_MODULE_11__["OPEN_API_URL"], { apiId: apiId });
    });
  }

  onVersionCreate(apiId) {
    pm.mediator.trigger('showCreateAPIVersionModal', { apiId });
  }

  render() {
    this.apiSidebarStore = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('APISidebarStore');
    this.apiListStore = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('APIListStore');

    // The API isConsistentlyOffline is only supposed to be used to show the offline state view to the user when he has been consistently offline.
    // For disabling the actions on lack of connectivity, please rely on the socket connected state itself for now.
    // Otherwise, there is a chance of data loss if we let the user perform actions when we are attempting a connection.
    const isConsistentlyOffline = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('SyncStatusStore').isConsistentlyOffline;

    let searchQuery = this.apiSidebarStore.searchQuery;

    if (isConsistentlyOffline && !this.apiListStore.isLoaded) {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_APIOffline_APIOffline__WEBPACK_IMPORTED_MODULE_9__["default"], { origin: "sidebar" });
    }

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_3__["default"], { handlers: this.getKeyMapHandlers() }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-sidebar", ref: "sidebar" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_APISidebarMenu_APISidebarMenu__WEBPACK_IMPORTED_MODULE_4__["default"], {
        ref: "menu",
        apiListStore: this.apiListStore }), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_6__["default"], { identifier: "api" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_APISidebarList_APISidebarList__WEBPACK_IMPORTED_MODULE_5__["default"], {
        ref: "list",
        apiListStore: this.apiListStore,
        apiSidebarStore: this.apiSidebarStore,
        searchQuery: searchQuery,

        toggleDeleteModal: this.toggleDeleteModal,
        toggleRemoveFromWSModal: this.toggleRemoveFromWSModal,
        onVersionCreate: this.onVersionCreate })))));





  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 14678:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return APISidebarMenu; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2293);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1601);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2325);
/* harmony import */ var _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1812);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9);
/* harmony import */ var _js_containers_apps_requester_sidebar_SidebarListActions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9025);
/* harmony import */ var _constants_Permissions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7278);
/* harmony import */ var _services_APIPermissionService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7279);
/* harmony import */ var _js_services_NavigationService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1801);
/* harmony import */ var _constants_APITooltips__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7201);
var _class;












let


APISidebarMenu = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class APISidebarMenu extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      refreshDisabled: false,
      isCreateAPIModalOpen: false };


    this.getAddIconText = this.getAddIconText.bind(this);
    this.openCreateAPIModal = this.openCreateAPIModal.bind(this);
    this.handleSearchChange = this.handleSearchChange.bind(this);

    this.store = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('APISidebarStore');
  }

  openCreateAPIModal() {
    // Show showSignInModal if user is not signed in
    if (!Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('CurrentUserStore').isLoggedIn) {
      return pm.mediator.trigger('showSignInModal', {
        type: 'createAPI',
        origin: 'API_sidebar',
        continueUrl: new URL(window.location.href),
        subtitle: '您需要一个账户才能继续探索Postman.' });

    }

    _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_5__["default"].addEventV2({
      category: 'api',
      action: 'start_create_flow',
      label: 'sidebar',
      value: 1 });


    _js_services_NavigationService__WEBPACK_IMPORTED_MODULE_10__["default"].transitionTo('build.api.new');
  }

  getAddIconText(isOffline, canCreateAPI) {
    if (isOffline) {
      return _constants_APITooltips__WEBPACK_IMPORTED_MODULE_11__["IS_OFFLINE_TOOLTIP_MSG"];
    }

    if (!canCreateAPI) {
      return _constants_Permissions__WEBPACK_IMPORTED_MODULE_8__["API_PERMISSION_ERROR"];
    }

    return '创建新的API';
  }

  componentWillUnmount() {
    clearTimeout(this.enableRefreshTimeout);
  }

  handleSearchChange(query) {
    this.store.setSearchQuery(query);
  }

  render() {
    const isOnline = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('SyncStatusStore').isSocketConnected,
    canAddAPI = isOnline && !this.props.apiListStore.isCreating,
    canRefresh = canAddAPI && !this.state.refreshDisabled && !this.props.apiListStore.isHydrating,
    currentWorkspaceId = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_2__["getStore"])('ActiveWorkspaceStore').id,
    canCreateAPI = _services_APIPermissionService__WEBPACK_IMPORTED_MODULE_9__["default"].hasPermission(this.props.apiListStore.permissions, 'create', 'workspace', currentWorkspaceId);

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_containers_apps_requester_sidebar_SidebarListActions__WEBPACK_IMPORTED_MODULE_7__["default"], {
        createNewConfig: {
          tooltip: this.getAddIconText(!isOnline, canCreateAPI),
          disabled: !canAddAPI || !canCreateAPI,
          onCreate: this.openCreateAPIModal,
          xPathIdentifier: 'addAPI' },

        onSearch: this.handleSearchChange,
        searchQuery: this.store.searchQuery }));


  }}) || _class;

/***/ }),

/***/ 14679:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return APISidebarList; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2293);
/* harmony import */ var _js_modules_services_ShareModalService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2373);
/* harmony import */ var _js_modules_services_ManageRolesModalService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2374);
/* harmony import */ var _js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2856);
/* harmony import */ var _APISidebarListItem_APISidebarListItem__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(14680);
/* harmony import */ var _APISidebarListEmptyItem_APISidebarListEmptyItem__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(14682);
/* harmony import */ var _appsdk_sidebar_SidebarLoadingState_SidebarLoadingState__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7771);
/* harmony import */ var _js_services_NavigationService__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1801);
var _class;









let


APISidebarList = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class APISidebarList extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleSelect = this.handleSelect.bind(this);
    this.handleRename = this.handleRename.bind(this);
    this.handleRemoveFromWS = this.handleRemoveFromWS.bind(this);
    this.handleExpandToggle = this.handleExpandToggle.bind(this);
  }

  /**
   * Handles the toggling or setting visibility value of child entities
   * for a given entity
   * @param {APIEntityMetaItemStore} value - Value of selected entity from sidebar
   * @param {Boolean} newVisibility - If passed this value will be set for
   *  child entities else toggling is done
   */
  handleExpandToggle(selectedParent, newVisibility) {
    const curEntityId = selectedParent.id,
    curEntityType = selectedParent.type,
    newEntityVisibility = _.isUndefined(newVisibility) ?
    !selectedParent.areChildEntitiesVisible : newVisibility;

    selectedParent.update({ areChildEntitiesVisible: newEntityVisibility });

    // Make child list visible
    _.forEach(selectedParent.childEntities.values, (childEntity) => {
      childEntity.update({ isVisible: newEntityVisibility });
    });
  }

  handleSelect(selectedParent) {
    const curEntityId = selectedParent.id,
    curEntityType = selectedParent.type;

    if (!curEntityId) {
      return;
    }

    switch (curEntityType) {
      case 'api':{
          // set focus and open in editor
          this.props.apiSidebarStore.openEditor(curEntityId);

          // Preventing toggling to ensure child entities aren't closed on
          // even numbered clicks on entity
          this.handleExpandToggle(selectedParent, true);

          return;
        }

      case 'apiVersion':{
          // Navigate to version tab
          // set focus and open in editor
          _js_services_NavigationService__WEBPACK_IMPORTED_MODULE_8__["default"].transitionTo('build.apiVersion', { apiId: `${selectedParent.parentEntityId}`, versionId: `${curEntityId}` });

          return;
        }}

  }

  handleRemoveFromWS(api) {
    if (!api) {
      return;
    }

    let { apiSidebarStore } = this.props;

    this.props.apiListStore.removeFromWorkspace(api.id, api.name).
    then(() => {

      // Switch focus if selected item got removed
      if (api.id === apiSidebarStore.activeItem) {
        apiSidebarStore.focusPrev({ openEditor: false });
      }

      this.props.toggleRemoveFromWSModal();
    });
  }

  handleRename(apiId, oldName, newName) {
    this.props.apiListStore.rename(apiId, newName).
    catch(() => _.invoke(this.refs, `${apiId}.inlineInput.setState`, { value: oldName }));
  }

  renderAPIEntitiesGroup(entity, apiSidebarStore) {
    if (!entity.isVisible) {
      return;
    }

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_4__["default"], { identifier: entity.id, key: entity.id }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_APISidebarListItem_APISidebarListItem__WEBPACK_IMPORTED_MODULE_5__["default"], {
        ref: entity.id,
        key: entity.id,
        id: entity.id,

        name: entity.name,
        type: entity.type,
        editable: entity.isEditable,
        isPublic: entity.isPublic,
        shared: Boolean(entity.team),
        selected: apiSidebarStore.activeItem === entity.id,
        entity: entity,

        onSelect: this.handleSelect,
        onExpandToggle: this.handleExpandToggle,
        onRename: this.handleRename,
        onDelete: this.props.toggleDeleteModal,
        onShare: _js_modules_services_ShareModalService__WEBPACK_IMPORTED_MODULE_2__["shareAPI"],
        onManageRole: _js_modules_services_ManageRolesModalService__WEBPACK_IMPORTED_MODULE_3__["manageRolesOnAPI"],
        onRemoveFromWorkspace: this.props.toggleRemoveFromWSModal,
        onVersionCreate: this.props.onVersionCreate })),




      // Recurse and render child entities
      _.map(entity.childEntities.values, (childEntity) =>
      this.renderAPIEntitiesGroup(childEntity, apiSidebarStore))));



  }

  render() {
    const apiSidebarStore = this.props.apiSidebarStore,
    sortedApis = apiSidebarStore.sortedAPIs;

    if (_.get(this.props, 'apiListStore.isStoreHydrating')) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-sidebar-list is-empty" }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_sidebar_SidebarLoadingState_SidebarLoadingState__WEBPACK_IMPORTED_MODULE_7__["default"], null)));


    }

    if (_.isEmpty(sortedApis)) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-sidebar-list is-empty" }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_APISidebarListEmptyItem_APISidebarListEmptyItem__WEBPACK_IMPORTED_MODULE_6__["default"], {
          query: this.props.searchQuery,
          apiListStore: this.props.apiListStore })));



    }

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-sidebar-list" },

      _.map(sortedApis, (apiItem) => {
        return this.renderAPIEntitiesGroup(apiItem, apiSidebarStore);
      })));



  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 14680:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return APISidebarListItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2293);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7281);
/* harmony import */ var _js_services_UIEventService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2165);
/* harmony import */ var _js_constants_UIEventConstants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2857);
/* harmony import */ var _js_containers_apps_requester_sidebar_SidebarListItem__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9023);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1601);
/* harmony import */ var _js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2845);
/* harmony import */ var _api_editor_common_APIStatusIcon_APIStatusIcon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7309);
/* harmony import */ var _js_services_NavigationService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1801);
/* harmony import */ var _util_TooltipText__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7277);
/* harmony import */ var _services_APIPermissionService__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7279);
/* harmony import */ var _js_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4332);
/* harmony import */ var _constants_Permissions__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7278);
/* harmony import */ var _constants_APITooltips__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(7201);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(2325);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(9);
/* harmony import */ var _runtime_repl_collection_api_CollectionSidebar__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(14681);
var _class;




















const ENTITY_TYPE_TO_INDENT_FACTOR = {
  api: 0,
  apiVersion: 1 };let



APISidebarListItem = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class APISidebarListItem extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      isEntityGroupOpen: false };


    this.handleEditName = this.handleEditName.bind(this);
    this.handleRenameSubmit = this.handleRenameSubmit.bind(this);
    this.handleDropdownActionSelect = this.handleDropdownActionSelect.bind(this);
    this.openAPIInNewTab = this.openAPIInNewTab.bind(this);
    this.getStatusIndicators = this.getStatusIndicators.bind(this);
    this.containerRef = this.containerRef.bind(this);
    this.handleClick = this.handleClick.bind(this);
    this.handleOpenChildGroup = this.handleOpenChildGroup.bind(this);
  }

  componentDidMount() {
    this.setState({ isEntityGroupOpen: _.get(this.props, 'entity.areChildEntitiesVisible') });

    this.unsubscribeHandler = _js_services_UIEventService__WEBPACK_IMPORTED_MODULE_4__["default"].subscribe(_js_constants_UIEventConstants__WEBPACK_IMPORTED_MODULE_5__["SAMPLE_API_IMPORT"], (api) => {

      // id of the imported sample API in lessons
      const apiId = _.get(api, 'data.id');

      this.openAPIInNewTab(apiId);
    });
  }

  componentWillUnmount() {
    this.unsubscribeHandler && this.unsubscribeHandler();
  }

  openAPIInNewTab(apiId) {
    _js_services_NavigationService__WEBPACK_IMPORTED_MODULE_10__["default"].transitionTo('build.api', { apiId }, {}, { additionalContext: { isNew: true } });
  }

  componentDidUpdate(prevProps) {
    if (!prevProps.selected && this.props.selected) {
      let $node = Object(react_dom__WEBPACK_IMPORTED_MODULE_2__["findDOMNode"])(this.listItem);
      $node && $node.scrollIntoViewIfNeeded && $node.scrollIntoViewIfNeeded();
    }
  }

  containerRef(ele) {
    this.listItem = ele;
  }

  handleClick() {
    this.setState({
      isEntityGroupOpen: true });


    this.props.onSelect && this.props.onSelect(this.props.entity);
  }

  handleDropdownActionSelect(action) {
    if (this.shouldBlockAction(action)) {
      return;
    }

    switch (action) {

      case _constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_3__["ACTION_TYPE_CREATE_VERSION"]:
        this.props.onVersionCreate(this.props.id);
        return;
      case _constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_3__["ACTION_TYPE_SHARE"]:
        this.props.onShare(this.props.id);
        return;
      case _constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_3__["ACTION_TYPE_MANAGE_ROLES"]:
        this.props.onManageRole(this.props.id);
        return;
      case _constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_3__["ACTION_TYPE_DELETE"]:
        this.props.onDelete(this.props.id);
        return;
      case _constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_3__["ACTION_TYPE_REMOVE_FROM_WORKSPACE"]:
        this.props.onRemoveFromWorkspace(this.props.id);
        return;
      case _constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_3__["ACTION_TYPE_RENAME"]:
        this.handleEditName();
        return;}

  }

  handleEditName() {
    _.invoke(this.listItem, 'editText');
  }

  /**
   * Return true for action type '管理角色', '删除', '从工作区中移除' and '重命名'
   * based on whether the user is a member of active workspace or not.
   *
   * Return false if action type is '共享API'.
   * @param {String} action - action type
   */
  shouldBlockAction(action) {
    // Check whether the user is signed in or not
    if (!Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('CurrentUserStore').isLoggedIn) {
      pm.mediator.trigger('showSignInModal', {
        type: `${action}_API`,
        origin: 'API_sidebar',
        continueUrl: new URL(window.location.href) });


      return true;
    }

    if (action !== _constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_3__["ACTION_TYPE_SHARE"]) {

      // Check whether the user is a member of active workspace or not
      let isWorkspaceMember = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveWorkspaceStore').isMember;
      if (!isWorkspaceMember) {
        pm.mediator.trigger('openUnjoinedWorkspaceModal');

        return true;
      }
    }

    // Don't block if user is a member or action type is '共享API'
    return false;
  }

  handleRenameSubmit(newName) {
    const isOffline = !Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('SyncStatusStore').isSocketConnected;

    if (isOffline) {
      pm.toasts.error('联网以执行此操作');
      return;
    }

    this.props.onRename(this.props.id, this.props.name, newName);
  }

  getStatusIndicators() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null,
      this.props.type === 'apiVersion' && this.props.entity.visibility === 'private' && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_17__["IconActionHideStrokeSmall"], {
        title: "仅对编辑者可见",
        className: "hide-icon" }), /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_api_editor_common_APIStatusIcon_APIStatusIcon__WEBPACK_IMPORTED_MODULE_9__["default"], {
        isPublic: this.props.isPublic,
        isShared: this.props.shared,
        isEditable: this.props.editable })));



  }

  getActions() {
    let isOffline = !Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('SyncStatusStore').isSocketConnected;
    const permissions = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('APIListStore').permissions;
    const currentWorkspaceId = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('ActiveWorkspaceStore').id;
    const canManageRolesOnAPI = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('CurrentUserStore').team;
    const canRenameAPI = _services_APIPermissionService__WEBPACK_IMPORTED_MODULE_12__["default"].hasPermission(permissions, 'rename', 'api', this.props.id);
    const canRemoveAPIFromWorkspace = _services_APIPermissionService__WEBPACK_IMPORTED_MODULE_12__["default"].hasPermission(permissions, 'removeFromWorkspace', 'workspace', currentWorkspaceId);
    const canDeleteAPI = _services_APIPermissionService__WEBPACK_IMPORTED_MODULE_12__["default"].hasPermission(permissions, 'delete', 'api', this.props.id);
    const canShareAPI = _services_APIPermissionService__WEBPACK_IMPORTED_MODULE_12__["default"].hasPermission(permissions, 'share', 'api', this.props.id);

    return [
    {
      type: _constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_3__["ACTION_TYPE_CREATE_VERSION"],
      label: '创建版本',
      isDisabled: isOffline },

    {
      type: _constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_3__["ACTION_TYPE_SHARE"],
      label: '共享API',
      isDisabled: isOffline || !canShareAPI,
      hasPermission: canShareAPI },

    {
      type: _constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_3__["ACTION_TYPE_MANAGE_ROLES"],
      label: '管理角色',
      isDisabled: isOffline || !canManageRolesOnAPI,

      // permitting users based of whether they are a part of team or not and
      // disabling manage roles option accordingly.
      disabledText: !isOffline && !canManageRolesOnAPI && _constants_Permissions__WEBPACK_IMPORTED_MODULE_14__["MANAGE_ROLES_DISABLED_TEXT"],
      hasPermission: canManageRolesOnAPI },

    {
      type: _constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_3__["ACTION_TYPE_RENAME"],
      label: '重命名',
      isDisabled: isOffline || !canRenameAPI,
      hasPermission: canRenameAPI,
      shortcut: 'rename' },

    {
      type: _constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_3__["ACTION_TYPE_REMOVE_FROM_WORKSPACE"],
      label: '从工作区中移除',
      isDisabled: isOffline || !canRemoveAPIFromWorkspace,
      hasPermission: canRemoveAPIFromWorkspace },

    {
      type: _constants_APIActionsConstants__WEBPACK_IMPORTED_MODULE_3__["ACTION_TYPE_DELETE"],
      label: '删除',
      isDisabled: isOffline || !canDeleteAPI,
      shortcut: 'delete' }];


  }

  getMenuItems() {
    return _.chain(this.getActions()).
    map((action) => {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_8__["MenuItem"], {
          key: action.type,
          refKey: action.type,
          disabled: action.isDisabled,
          disabledText: Object(_util_TooltipText__WEBPACK_IMPORTED_MODULE_11__["default"])(action.isDisabled, !action.hasPermission, action.disabledText) }, /*#__PURE__*/

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", { className: "api-action-item" }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "dropdown-menu-item-label" },
        action.label),


        action.shortcut && /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "dropdown-menu-item-shortcut" }, Object(_js_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_13__["getShortcutByName"])(action.shortcut)))));




    }).value();
  }

  getActionsMenuItems() {
    if (_.get(this.props, 'type') === 'apiVersion') {
      return;
    }

    const menuItems = this.getMenuItems();

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_8__["DropdownMenu"], {
        className: 'api-dropdown-menu',
        "align-right": true },

      menuItems));


  }

  handleOpenChildGroup(event) {
    // Preventing event propagation to ensure
    // redundant handler calls aren't made
    event.stopPropagation();

    this.setState((prevState) => {
      return {
        isEntityGroupOpen: !prevState.isEntityGroupOpen };

    });

    this.props.onExpandToggle(this.props.entity);
  }

  renderLeftArrow(isHovered, isDropdownOpen) {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "api-sidebar-list__item__left-section" },


      _.times(ENTITY_TYPE_TO_INDENT_FACTOR[_.get(this.props, 'type')], () => {
        return /*#__PURE__*/(
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-sidebar-list__item__left-section__indent" }));

      }),


      (_.get(this.props, 'type') !== 'apiVersion' ||
      _.get(this.props.entity, 'workbenchModel.featureBranch.collectionListModel')) && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_16__["Button"], {
        type: "icon",
        className: "api-sidebar-list__item__left-section__toggle-list",
        onClick: this.handleOpenChildGroup }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_17__["Icon"], {
        name: _.get(this.state, 'isEntityGroupOpen') ? 'icon-direction-down' : 'icon-direction-right' })))));






  }

  render() {
    const icon = _.get(this.props, 'type') === 'apiVersion' ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_17__["IconDescriptiveVersionsStroke"], null) : null,
    entity = this.props.entity;

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_containers_apps_requester_sidebar_SidebarListItem__WEBPACK_IMPORTED_MODULE_6__["default"], {
        ref: this.containerRef,
        icon: icon,
        text: this.props.name,
        isSelected: this.props.selected,
        onClick: this.handleClick,
        onRename: this.handleRenameSubmit,
        statusIndicators: this.getStatusIndicators,
        moreActions: this.getActionsMenuItems(),
        onActionsDropdownSelect: this.handleDropdownActionSelect,
        leftMetaComponent: this.renderLeftArrow.bind(this) }),

      _.get(entity, 'workbenchModel.featureBranch.collectionListModel') &&
      _.get(this.state, 'isEntityGroupOpen') && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_runtime_repl_collection_api_CollectionSidebar__WEBPACK_IMPORTED_MODULE_18__["default"], {
        model: _.get(entity, 'workbenchModel.featureBranch.collectionListModel') })));




  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 14681:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CollectionSidebar; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2293);
/* harmony import */ var _sidebar_CollectionSidebarListContainer_CollectionSidebarListContainer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9653);
var _class;


let


CollectionSidebar = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class CollectionSidebar extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  render() {
    const { model } = this.props;

    if (!model) {
      return null;
    }

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_sidebar_CollectionSidebarListContainer_CollectionSidebarListContainer__WEBPACK_IMPORTED_MODULE_2__["default"], {
        isNested: true,
        model: model }));


  }}) || _class;

/***/ }),

/***/ 14682:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return APISidebarListEmptyItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2293);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2325);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1601);
/* harmony import */ var _js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2322);
/* harmony import */ var _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1812);
/* harmony import */ var _js_modules_services_AuthHandlerService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3770);
/* harmony import */ var _appsdk_sidebar_SidebarEmptyState_SidebarEmptyState__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9027);
/* harmony import */ var _appsdk_sidebar_SidebarNoResultsFound_SidebarNoResultsFound__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8228);
/* harmony import */ var _js_services_NavigationService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1801);
/* harmony import */ var _services_APIPermissionService__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7279);
/* harmony import */ var _util_TooltipText__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7277);
var _class;












let


APISidebarListEmptyItem = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class APISidebarListEmptyItem extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      isCreateAPIModalOpen: false };


    this.handleOffline = this.handleOffline.bind(this);
    this.handleLoggedOut = this.handleLoggedOut.bind(this);
    this.getComponent = this.getComponent.bind(this);
    this.openCreateAPIModal = this.openCreateAPIModal.bind(this);
  }

  openCreateAPIModal() {
    _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_6__["default"].addEventV2({
      category: 'api',
      action: 'start_create_flow',
      label: 'sidebar',
      value: 1 });


    _js_services_NavigationService__WEBPACK_IMPORTED_MODULE_10__["default"].transitionTo('build.api.new');
  }

  handleOffline() {
    this.props.apiListStore.reload();
  }

  handleLoggedOut() {
    _js_modules_services_AuthHandlerService__WEBPACK_IMPORTED_MODULE_7__["default"].initiateLogin();
  }

  getComponent(title, description, buttonText, handler) {
    const isOffline = !_.get(Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('SyncStatusStore'), 'isSocketConnected'),
    currentWorkspaceId = _.get(Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('ActiveWorkspaceStore'), 'id'),
    hasPermissionToCreateAPI = _services_APIPermissionService__WEBPACK_IMPORTED_MODULE_11__["default"].hasPermission(this.props.apiListStore.permissions, 'create', 'workspace', currentWorkspaceId);

    const canCreateAPI = !isOffline && !_.get(this.props, 'apiListStore.isCreating') && hasPermissionToCreateAPI;

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_sidebar_SidebarEmptyState_SidebarEmptyState__WEBPACK_IMPORTED_MODULE_8__["default"], {
        illustration: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_2__["IllustrationNoAPI"], null),
        title: title,
        message: description,
        action: {
          label: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, this.props.apiListStore.isCreating ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_5__["default"], null) : buttonText),
          handler: handler,
          tooltip: Object(_util_TooltipText__WEBPACK_IMPORTED_MODULE_12__["default"])(!canCreateAPI, !hasPermissionToCreateAPI) },

        hasPermissions: canCreateAPI }));


  }

  getContent() {
    let isLoggedOut = !Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('CurrentUserStore').isLoggedIn,
    isOffline = !Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('SyncStatusStore').isSocketConnected,
    title = '',
    description = '',
    buttonText = '';

    if (isLoggedOut) {
      title = '登录以创建API';
      description = 'API在一致的架构下定义了相关的集合和环境.';
      buttonText = '登录以创建API';

      return this.getComponent(title, description, buttonText, this.handleLoggedOut);
    }

    if (this.props.query && _.isEmpty(this.props.apiListStore.sortedAPIs)) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_sidebar_SidebarNoResultsFound_SidebarNoResultsFound__WEBPACK_IMPORTED_MODULE_9__["default"], { searchQuery: this.props.query, illustration: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_2__["IllustrationNoAPI"], null) }));

    }

    title = '还没有API';
    description = 'API在一致的架构下定义了相关的集合和环境.';
    buttonText = '创建一个API';
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null,
      this.getComponent(title, description, buttonText, this.openCreateAPIModal)));


  }

  render() {
    return (
      this.getContent());

  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ })

}]);