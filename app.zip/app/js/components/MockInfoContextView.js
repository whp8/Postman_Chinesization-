(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[14],{

/***/ 9028:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return MockInfoContextView; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3737);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2293);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1595);
/* harmony import */ var _js_components_activity_feed_ActivityItemComponents__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9029);
/* harmony import */ var _appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2862);
/* harmony import */ var _js_utils_ClipboardHelper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2346);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2325);
/* harmony import */ var _js_components_base_Avatar__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4190);
/* harmony import */ var _js_components_base_Tooltips__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2326);
/* harmony import */ var _js_services_NavigationService__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1801);
/* harmony import */ var _version_control_common_ForkLabel__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3191);
/* harmony import */ var _js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2322);
/* harmony import */ var _services_CollectionService__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8255);
/* harmony import */ var _js_modules_services_APIService__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1865);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(1601);
/* harmony import */ var _components_MockOffline__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(2841);
/* harmony import */ var _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(1812);
/* harmony import */ var _report_embeddable_components_EmbeddedReport__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(9032);
var _class;






















// Duration for which we will show the success state after performing the Copy action
const SHOW_COPY_SUCCESS_DURATION = 3000;let


MockInfoContextView = Object(mobx_react__WEBPACK_IMPORTED_MODULE_4__["observer"])(_class = class MockInfoContextView extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      idCopySuccess: false,
      urlCopySuccess: false,
      isUserTooltipVisible: false,
      collection: null,
      fetchingCollection: true,
      errorFetchingCollection: false,
      isOffline: false };


    this.tooltipRef = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createRef();

    this.handleCopyId = this.handleCopyId.bind(this);
    this.handleCopyUrl = this.handleCopyUrl.bind(this);
    this.handleCollectionClick = this.handleCollectionClick.bind(this);
    this.handleEnvironmentClick = this.handleEnvironmentClick.bind(this);
    this.getUserIcon = this.getUserIcon.bind(this);
    this.getUserName = this.getUserName.bind(this);
    this.showUserTooltip = this.showUserTooltip.bind(this);
    this.hideUserTooltip = this.hideUserTooltip.bind(this);
    this.fetchCollection = this.fetchCollection.bind(this);
    this.handleRequestAccess = this.handleRequestAccess.bind(this);
  }

  componentDidMount() {
    this.syncStatusStoreReactionDisposer = Object(mobx__WEBPACK_IMPORTED_MODULE_5__["reaction"])(() => Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_17__["getStore"])('SyncStatusStore').isSocketConnected, (isSocketConnected) => {
      !isSocketConnected && (
      this.state.fetchingCollection || this.state.errorFetchingCollection) &&
      this.setState({ isOffline: true });

      isSocketConnected &&
      this.setState({ isOffline: false }, () => {
        this.fetchCollection();
      });
    }, {
      fireImmediately: true });

  }

  componentWillUnmount() {
    clearTimeout(this.clearIdCopySuccessTimeout);
    clearTimeout(this.clearUrlCopySuccessTimeout);

    this.syncStatusStoreReactionDisposer && this.syncStatusStoreReactionDisposer();
  }

  fetchCollection() {
    const collection = Object(mobx__WEBPACK_IMPORTED_MODULE_5__["toJS"])(_.get(this.props, 'contextData.collection'));

    if (!_.get(this.props, 'contextData.active') || _.get(collection, '_isAccessible') === false) {
      this.setState({ fetchingCollection: false, errorFetchingCollection: false });

      return;
    }

    this.setState({ fetchingCollection: true, errorFetchingCollection: false });

    Object(_services_CollectionService__WEBPACK_IMPORTED_MODULE_15__["fetchCollection"])(_.get(this.props, 'contextData.collection.id')).
    then((collection) => {
      this.setState({ collection: collection, fetchingCollection: false, errorFetchingCollection: false });
    }).
    catch((err) => {
      this.setState({ collection: null, fetchingCollection: false, errorFetchingCollection: true });
    });
  }

  handleCopyId() {
    if (this.state.idCopySuccess) {
      return;
    }

    _js_utils_ClipboardHelper__WEBPACK_IMPORTED_MODULE_8__["default"].copy(_.get(this.props, 'contextData.id', ''));

    this.setState(
    { idCopySuccess: true },
    () => {
      this.clearIdCopySuccessTimeout = setTimeout(
      () => this.setState({ idCopySuccess: false }),
      SHOW_COPY_SUCCESS_DURATION);

    });

  }

  handleCopyUrl() {
    if (this.state.urlCopySuccess) {
      return;
    }

    _js_utils_ClipboardHelper__WEBPACK_IMPORTED_MODULE_8__["default"].copy(_.get(this.props, 'contextData.url', ''));

    _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_19__["default"].addEventV2({
      category: 'mock',
      action: 'copy_url',
      label: 'mock_info_context_bar',
      entityId: _.get(this.props, 'contextData.id'),
      traceId: _.get(this.props, 'contextData.traceId') });


    this.setState(
    { urlCopySuccess: true },
    () => {
      this.clearUrlCopySuccessTimeout = setTimeout(
      () => this.setState({ urlCopySuccess: false }),
      SHOW_COPY_SUCCESS_DURATION);

    });

  }

  handleCollectionClick() {
    const collectionId = _.get(this.props, 'contextData.collection.id', '');

    _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_19__["default"].addEventV2({
      category: 'mock',
      action: 'view_collection',
      label: 'mock_info_context_bar',
      entityId: _.get(this.props, 'contextData.id'),
      traceId: _.get(this.props, 'contextData.traceId') });


    _js_services_NavigationService__WEBPACK_IMPORTED_MODULE_12__["default"].transitionTo('collection.openWithWsSelect', { cid: collectionId });
  }

  handleEnvironmentClick() {
    const environmentId = _.get(this.props, 'contextData.environment.id', '');

    _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_19__["default"].addEventV2({
      category: 'mock',
      action: 'view_environment',
      label: 'mock_info_context_bar',
      entityId: _.get(this.props, 'contextData.id'),
      traceId: _.get(this.props, 'contextData.traceId') });


    _js_services_NavigationService__WEBPACK_IMPORTED_MODULE_12__["default"].transitionTo('environment.openWithWsSelect', { eid: environmentId });
  }

  handleRequestAccess(entityType, entityId, type) {
    _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_19__["default"].addEventV2({
      category: 'mock',
      action: 'initiate_request_access_' + entityType,
      label: 'mock_info_context_bar',
      entityId: _.get(this.props, 'contextData.id'),
      traceId: _.get(this.props, 'contextData.traceId') });


    Object(_js_modules_services_APIService__WEBPACK_IMPORTED_MODULE_16__["openAuthenticatedRoute"])(`${pm.dashboardUrl}/request-access?entityType=${entityType}&entityId=${entityId}&type=${type}`);
  }

  getIcon(isCopied) {
    if (isCopied) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["Icon"], {
          name: "icon-state-success-stroke",
          className: "mock-info-context-view__entity__content__button__success" }));


    } else
    {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["Icon"], {
          name: "icon-action-copy-stroke",
          className: "mock-info-context-view__entity__content__button__copy" }));


    }
  }

  getUserIcon(user = {}) {
    if (user.isAccessible) {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_activity_feed_ActivityItemComponents__WEBPACK_IMPORTED_MODULE_6__["ProfilePic"], { id: user.id });
    }

    // Private/Anonymous User
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Avatar__WEBPACK_IMPORTED_MODULE_10__["default"], {
        size: "small",
        userId: user.id,
        customPic: user.profilePicUrl }));


  }

  getUserName(user = {}) {
    if (user.isAccessible) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_activity_feed_ActivityItemComponents__WEBPACK_IMPORTED_MODULE_6__["User"], {
          id: user.id,
          name: user.name || user.username }));


    }

    // Private/Anonymous User
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
        className: "activity-item-user",
        ref: this.tooltipRef,
        onMouseEnter: this.showUserTooltip,
        onMouseLeave: this.hideUserTooltip },

      user.name),

      this.tooltipRef.current && !user.isPublic && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Tooltips__WEBPACK_IMPORTED_MODULE_11__["Tooltip"], {
        immediate: true,
        show: this.state.isUserTooltipVisible,
        target: this.tooltipRef.current,
        placement: "bottom" }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Tooltips__WEBPACK_IMPORTED_MODULE_11__["TooltipBody"], null, "此用户资料是私有的."))));






  }

  showUserTooltip() {
    this.setState({ isUserTooltipVisible: true });
  }

  hideUserTooltip() {
    this.setState({ isUserTooltipVisible: false });
  }

  render() {
    const mock = _.get(this.props, 'contextData', {}),
    createdAt = moment__WEBPACK_IMPORTED_MODULE_2___default()(mock.createdAt).format('DD MMM YYYY, h:mm A');

    if (!this.state.isOffline && this.state.fetchingCollection) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view-loading" }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_14__["default"], null)));


    }

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view-wrapper" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_7__["ContextBarViewHeader"], {
        title: this.props.title,
        onClose: this.props.onClose }),


      this.state.isOffline && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_MockOffline__WEBPACK_IMPORTED_MODULE_18__["default"], { origin: "context-bar" }),


      !this.state.isOffline && this.state.errorFetchingCollection && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view__error__wrapper" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view__error" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["IllustrationInternalServerError"], null), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view__error__content" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view__error__content__header" }, "出了些问题"), /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view__error__content__sub-header" }, "发生意外错误. 请再试一次.")), /*#__PURE__*/



      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_9__["Button"], {
        className: "btn-small mock-info-context-view__error__retry-button",
        type: "primary",
        onClick: this.fetchCollection }, "再试一次"))),








      !(this.state.isOffline || this.state.errorFetchingCollection) && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view__entity" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view__entity__label" }, "ID"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view__entity__content" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "mock-info-context-view__entity__content__id",
        title: mock.id },

      mock.id), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_9__["Button"], {
        className: "mock-info-context-view__entity__content__button",
        tooltip: this.state.idCopySuccess ? '已拷贝' : '拷贝模拟ID',
        type: "icon",
        onClick: this.handleCopyId },

      this.getIcon(this.state.idCopySuccess)))), /*#__PURE__*/



      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view__entity" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view__entity__label" }, "创建者"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view__entity__content" },
      mock.createdBy && this.getUserIcon(mock.createdBy),
      mock.createdBy && this.getUserName(mock.createdBy))), /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view__entity" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view__entity__label" }, "创建于"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view__entity__content" },
      createdAt)), /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view__entity" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view__entity__label" }, "模拟服务器URL"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view__entity__content" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "mock-info-context-view__entity__content__url",
        title: mock.url },

      mock.url), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_9__["Button"], {
        className: "mock-info-context-view__entity__content__button",
        tooltip: this.state.urlCopySuccess ? '已拷贝' : '拷贝模拟URL',
        type: "icon",
        onClick: this.handleCopyUrl },

      this.getIcon(this.state.urlCopySuccess)))), /*#__PURE__*/



      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view__entity" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view__entity__label" }, "集合"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view__entity__content" },

      _.get(mock, 'collection._isDeleted') ? /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, "关联的集合已被删除") :




      _.get(mock, 'collection._isAccessible') === false && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, "集合无法访问", /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "mock-info-context-view__entity__content__request-access",
        onClick: () => this.handleRequestAccess('collection', _.get(mock, 'collection.id'), 'share_entity') }, "请求访问")),







      !_.get(mock, 'collection._isDeleted') && _.get(mock, 'collection._isAccessible') && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "mock-info-context-view__entity__content__collection",
        title: _.get(mock, 'collection.name'),
        onClick: this.handleCollectionClick },

      _.get(mock, 'collection.name')),



      _.get(this.state, 'collection.meta.forkedFrom') && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view__entity__content__collection-fork-label" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_version_control_common_ForkLabel__WEBPACK_IMPORTED_MODULE_13__["default"], {
        baseEntity: {
          id: _.get(this.state, 'collection.meta.forkedFrom.id'),
          name: _.get(this.state, 'collection.meta.forkedFrom.name'),
          model: 'collection' },

        forkedEntity: {
          forkLabel: _.get(this.state, 'collection.meta.forkedFrom.forkName') },

        label: _.get(this.state, 'collection.meta.forkedFrom.forkName'),
        size: "large" })),




      !_.get(mock, 'collection._isDeleted') && _.get(mock, 'collection._isAccessible') && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        title: _.get(mock, 'collection.versionName'),
        className: classnames__WEBPACK_IMPORTED_MODULE_3___default()({
          'mock-info-context-view__entity__content__collection-version-tag': true,
          'mock-info-context-view__entity__content__collection-version-tag__current':
          _.isEqual(_.get(mock, 'collection.versionTag'), 'latest') }) },


      _.get(mock, 'collection.versionName')))), /*#__PURE__*/




      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view__entity" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view__entity__label" }, "环境"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view__entity__content" },
      _.get(mock.environment, 'name') ? /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "mock-info-context-view__entity__content__environment",
        title: _.get(mock, 'environment.name'),
        onClick: this.handleEnvironmentClick },

      _.get(mock, 'environment.name')) : /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "mock-info-context-view__entity__content__environment-empty" },
      _.get(mock, 'environment._isDeleted') &&
      '关联的环境已被删除',


      _.get(mock, 'environment._isAccessible') === false && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, "环境无法访问", /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "mock-info-context-view__entity__content__request-access",
        onClick: () => this.handleRequestAccess('environment', _.get(mock, 'environment.id'), 'share_entity') }, "请求访问")),






      !_.get(mock, 'environment') && '无环境'))), /*#__PURE__*/





      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_report_embeddable_components_EmbeddedReport__WEBPACK_IMPORTED_MODULE_20__["default"], { entityId: this.props.contextData.id, reportId: "mockUsage" }))));





  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 9032:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EmbeddedReport; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _charts_AreaChart__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9033);
/* harmony import */ var _services_EmbeddedReportingService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9034);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1422);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(uuid__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1812);
/* harmony import */ var _js_utils_util__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1628);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1601);
function _extends() {_extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};return _extends.apply(this, arguments);}







const reportHandlerMapping = {
  mockUsage: {
    metric: 'hits',
    title: '模拟使用情况',
    service: _services_EmbeddedReportingService__WEBPACK_IMPORTED_MODULE_2__["default"].mockUsage,
    ChartComponent: _charts_AreaChart__WEBPACK_IMPORTED_MODULE_1__["default"],
    valueKey: 'mockUsage',
    analyticsData: {
      entityType: 'mock' } },


  monitorUsage: {
    metric: 'hits',
    title: '监视器使用情况',
    service: _services_EmbeddedReportingService__WEBPACK_IMPORTED_MODULE_2__["default"].monitorUsage,
    ChartComponent: _charts_AreaChart__WEBPACK_IMPORTED_MODULE_1__["default"],
    valueKey: 'monitorUsage',
    analyticsData: {
      entityType: 'monitor',
      entityId: _js_utils_util__WEBPACK_IMPORTED_MODULE_5__["default"].getTeamId(Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('CurrentUserStore')) } } };




function useOnScreen(ref) {

  const [isIntersecting, setIntersecting] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);

  const observer = new IntersectionObserver(
  ([entry]) => setIntersecting(entry.isIntersecting));


  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    observer.observe(ref.current);

    // Remove the observer as soon as the component is unmounted
    return () => {observer.disconnect();};
  }, [ref]);

  return isIntersecting;
}

function EmbeddedReport({ reportId, entityId }) {
  let [usageData, setUsageData] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])([]),
  [loading, setLoading] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(true),
  [error, setError] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false),
  [viewed, setViewed] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false),
  [traceId] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(uuid__WEBPACK_IMPORTED_MODULE_3___default.a.v4()),
  isMounted = Object(react__WEBPACK_IMPORTED_MODULE_0__["useRef"])(false),
  viewElement = Object(react__WEBPACK_IMPORTED_MODULE_0__["useRef"])(),
  onScreen = useOnScreen(viewElement);

  const reportHandler = _.get(reportHandlerMapping, reportId);

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    isMounted.current = true;
    return () => {
      isMounted.current = false;
    };
  }, []);

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    if (!isMounted.current) {return;}

    reportHandler && reportHandler.service(traceId, entityId).
    then((resp) => {
      if (isMounted.current) {
        const data = resp.body.data.map((item) => ({
          timestamp: item.timestamp,
          value: _.get(item.values, reportHandler.valueKey) }));

        setUsageData(data);
        setLoading(false);
      }
    }).
    catch((err) => {
      setError(true);
      setLoading(false);
      pm.logger.error('EmbeddedReports', reportId, err);
    });
  }, [reportId, entityId]);

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    if (!loading && onScreen && !viewed) {
      _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_4__["default"].addEventV2AndPublish(_extends({
        category: 'embedded-reports',
        label: reportId,
        action: 'view',
        value: 1,
        entityType: 'mock',
        entityId: entityId,
        traceId: traceId },
      _.get(reportHandler, 'analyticsData', {})));

      setViewed(true);
    }
  }, [onScreen, loading]);

  if (!reportHandler) {
    pm.logger.error('EmbeddedReports:', 'Requested report', reportId, 'is not available yet');
    return null;
  }

  return /*#__PURE__*/(
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { ref: viewElement },
    reportHandler && /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(reportHandler.ChartComponent, { loading: loading, error: error, data: usageData, metric: reportHandler.metric,
      title: reportHandler.title })));



}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 9033:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return AreaChart; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3737);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2322);
function _extends() {_extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};return _extends.apply(this, arguments);}


class LineGraphChart extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.chartRef = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createRef();

    this.handleGraphClick = this.handleGraphClick.bind(this);
    this.initializeChart = this.initializeChart.bind(this);
  }

  componentDidMount() {
    this.initializeChart();
  }

  componentWillUnmount() {
    this.chart && this.chart.destroy();
  }

  handleGraphClick(event, items) {
    const activeItem = items[0];

    if (!activeItem) {
      return;
    }

    this.props.onDataPointClick(activeItem._index);
  }

  initializeChart() {
    if (!this.props.chartJs) {
      return;
    }

    const ctx = this.chartRef.current.getContext('2d'),
    values = Object.assign([], this.props.values),
    labels = Object.assign([], this.props.labels),
    Chart = this.props.chartJs;

    if (this.chart) {
      this.chart.destroy();
    }

    this.chart = new Chart.default(ctx, {
      type: 'line',
      data: {
        labels,
        datasets: [{
          data: values,
          backgroundColor: 'rgba(242, 107, 58, 0.1)',
          borderColor: '#FF6C37' }] },


      options: {
        events: ['mousemove', 'mouseout'],
        hover: { mode: 'nearest', onHover: this.props.onHover, intersect: false },
        legend: false,
        tooltips: {
          displayColors: false,
          cornerRadius: 3,
          titleFontFamily: 'Inter',
          titleFontSize: 12,
          bodyFontFamily: 'Inter',
          bodyFontSize: 12,
          xPadding: 8,
          yPadding: 8,
          mode: 'nearest' },

        scales: {
          yAxes: [{
            type: 'linear',
            ticks: _extends({
              fontSize: 10,
              fontFamily: 'Inter',
              maxTicksLimit: 5,
              stepSize: 1,
              padding: 4,
              beginAtZero: true },
            this.props.yLabelCallback ? { callback: this.props.yLabelCallback } : {}) }],


          xAxes: [{
            type: 'time',
            time: {
              parser: 'YYYY-MM-DD HH:mm:ss',
              tooltipFormat: 'll',
              minUnit: 'day',
              displayFormats: {
                'millisecond': 'D MMM',
                'second': 'D MMM',
                'minute': 'D MMM',
                'hour': 'D MMM',
                'day': 'D MMM',
                'week': 'll',
                'month': 'MMM YYYY',
                'quarter': '[Q]Q - YYYY',
                'year': 'YYYY' } },


            gridLines: {
              display: false,
              drawBorder: false },

            ticks: {
              fontSize: 10,
              fontFamily: 'Inter' } }] } } });





  }

  render() {
    if (this.props.error) {
      return '加载图表时出错. 请重新加载页面.';
    }

    if (this.props.chartJs) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("canvas", {
          height: "150px",
          ref: this.chartRef }));


    }

    return '我们无法加载此报告. 请刷新页面重试.';
  }}


/**
 * Body for the line graph
 *
 * @param {Object} props - React props
 */
function LineGraphBody(props) {
  let labels = props.data.map((item) => item.timestamp),
  values = props.data.map((item) => item.value),
  [summary, setSummary] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])();

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    setSummary(`${_.last(values) || 0} ${props.metric} on ${moment__WEBPACK_IMPORTED_MODULE_1___default()(_.last(labels), 'YYYY-MM-DD').format('MMM DD')}`);
  }, [props.data]);

  if (props.loading) {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "embeddable-report-graph-card__loader" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_2__["default"], null)));


  }

  if (props.error) {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "embeddable-report-graph-card__empty" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h5", { className: "pm-h5 embeddable-report-graph-card__empty__title" }, "报告未加载."), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", { className: "embeddable-report-graph-card__empty__body" }, "那是不应该发生的. 尝试刷新页面.")));


  }

  const onHover = (event, element) => {
    if (event.type === 'mouseout') {
      setSummary(`${_.last(values) || 0} ${props.metric} on ${moment__WEBPACK_IMPORTED_MODULE_1___default()(_.last(labels), 'YYYY-MM-DD HH:mm:ss').format('MMM DD')}`);
    } else
    {
      setSummary(`${_.get(values, _.get(element, [0, '_index']), 0)} ${props.metric} on ${moment__WEBPACK_IMPORTED_MODULE_1___default()(_.get(labels, _.get(element, [0, '_index'])), 'YYYY-MM-DD HH:mm:ss').format('MMM DD')}`);
    }
  };
  return /*#__PURE__*/(
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", { className: "embeddable-report-graph-card__summary" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, summary), /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", { className: "embeddable-report-graph-card__summary__disclaimer" }, "UTC 时间")), /*#__PURE__*/

    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(LineGraphChart, {
      chartJs: props.chartJs,
      error: props.errorLoadingChartjs,
      labels: labels,
      values: values,
      onHover: onHover,
      yLabelCallback: props.yLabelCallback,
      onDataPointClick: props.onDataPointClick })));



}

/**
 * Component to show area chart
 */
class AreaChart extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      loadingChartjs: true,
      errorLoadingChartjs: false,
      loadedChartjs: false };


    this.unmounted = false;
  }

  componentDidMount() {
    __webpack_require__.e(/* import() | chart.js-legacy */ 80).then(__webpack_require__.t.bind(null, 17889, 7)).
    then((Chart) => {
      // safe setstate
      if (!this.unmounted) {
        this.Chart = Chart;

        this.setState({
          loadingChartjs: false,
          errorLoadingChartjs: false,
          loadedChartjs: true });

      }
    }).
    catch(() => {
      // safe setstate
      if (!this.unmounted) {
        this.setState({
          loadingChartjs: false,
          errorLoadingChartjs: true,
          loadedChartjs: false });

      }
    });
  }

  componentWillUnmount() {
    this.unmounted = true;
  }

  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "embeddable-report-graph-card",
        id: this.props.id }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h4", { className: "embeddable-report-graph-card__title" }, this.props.title),
      this.props.tooltip && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(IconWithTooltip, {
        align: "left",
        className: "embeddable-report-graph-card__info",
        content: this.props.tooltip,
        name: "question",
        size: "sm" }), /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(LineGraphBody, _extends({},
      this.props,
      this.state, {
        chartJs: this.Chart,
        loading: this.props.loading || this.state.loadingChartjs }))));



  }}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 9034:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _js_modules_services_RemoteSyncRequestService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1798);
/* harmony import */ var _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1812);
/* harmony import */ var _js_utils_util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1628);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1601);





/**
 * Used to return mock config settings
 */
/* harmony default export */ __webpack_exports__["default"] = ({
  mockUsage: async (traceId, mockId) => {
    let startTime = new Date();
    const url = '/ws/proxy';
    let response = await _js_modules_services_RemoteSyncRequestService__WEBPACK_IMPORTED_MODULE_0__["default"].
    request(url, {
      method: 'post',
      data: {
        method: 'post',
        service: 'report',
        path: '/reports/mock',
        body: {
          reportId: 'mockUsage',
          reportOptions: {
            timeMacro: 'P1M',
            mockId } } } });




    let endTime = new Date();
    _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_1__["default"].addEventV2AndPublish({
      category: 'embedded-reports',
      label: 'mockUsage',
      action: 'load-time',
      value: endTime - startTime,
      entityType: 'mock',
      entityId: mockId,
      traceId: traceId });

    return response;
  },
  monitorUsage: async (traceId) => {
    let startTime = new Date();
    const url = '/ws/proxy';
    let response = await _js_modules_services_RemoteSyncRequestService__WEBPACK_IMPORTED_MODULE_0__["default"].
    request(url, {
      method: 'post',
      data: {
        method: 'post',
        service: 'report',
        path: '/reports/monitor',
        body: {
          reportId: 'monitorUsage',
          reportOptions: {
            timeMacro: 'P12M' } } } });




    let endTime = new Date();
    _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_1__["default"].addEventV2AndPublish({
      category: 'embedded-reports',
      label: 'monitorUsage',
      action: 'load-time',
      value: endTime - startTime,
      entityType: 'mock',
      entityId: _js_utils_util__WEBPACK_IMPORTED_MODULE_2__["default"].getTeamId(Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('CurrentUserStore')),
      traceId: traceId });

    return response;
  } });

/***/ })

}]);