(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[13],{

/***/ 9021:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SidebarMockListing; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2293);
/* harmony import */ var react_virtualized_auto_sizer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5127);
/* harmony import */ var react_window__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3699);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1595);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1601);
/* harmony import */ var _SidebarMockListItem__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9022);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2325);
/* harmony import */ var _services_MockNavigationService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2382);
/* harmony import */ var _js_services_NavigationService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1801);
/* harmony import */ var _js_containers_apps_requester_sidebar_SidebarListActions__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9025);
/* harmony import */ var _appsdk_sidebar_SidebarNoResultsFound_SidebarNoResultsFound__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8228);
/* harmony import */ var _appsdk_sidebar_SidebarLoadingState_SidebarLoadingState__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7771);
/* harmony import */ var _appsdk_sidebar_SidebarEmptyState_SidebarEmptyState__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9027);
/* harmony import */ var _js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(2856);
/* harmony import */ var _constants_MockErrors__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(2383);
/* harmony import */ var _constants_Permissions__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(2854);
/* harmony import */ var _services_FetchPermissionService__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(2855);
/* harmony import */ var _components_MockOffline__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(2841);
/* harmony import */ var _js_components_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(2314);
var _class;
























const MIN_ROW_HEIGHT = 28,
OVERSCAN_COUNT = 10;let


SidebarMockListing = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class SidebarMockListing extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.store = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('RequesterSidebarStore');

    this.listItemRefs = {};

    this.handleCreate = this.handleCreate.bind(this);
    this.handleSearchChange = this.handleSearchChange.bind(this);
    this.handleRetry = this.handleRetry.bind(this);
    this.successHandler = this.successHandler.bind(this);
    this.handleRename = this.handleRename.bind(this);
    this.focusNext = this.focusNext.bind(this);
    this.focusPrev = this.focusPrev.bind(this);
    this.handleDeleteShortcut = this.handleDeleteShortcut.bind(this);
    this.handleRenameShortcut = this.handleRenameShortcut.bind(this);
    this.scrollToItemById = this.scrollToItemById.bind(this);
    this.resetFocusedItem = this.resetFocusedItem.bind(this);

    this.getListContainer = this.getListContainer.bind(this);
    this.getSidebarEmptyState = this.getSidebarEmptyState.bind(this);

    this.mockStore = _.get(this.props, 'controller.mockListStore');

    // Reaction for moving to the specified list item on focus shift
    this.focusReactionDisposer = Object(mobx__WEBPACK_IMPORTED_MODULE_4__["reaction"])(() => {
      return this.mockStore.focusedItem || this.mockStore.activeItem;
    },
    (itemToFocus) => {
      if (!itemToFocus) {
        return;
      }

      // `requestIdleCallback` is used because mounting and rendering of new List items is of
      // higher priority and must be done before scrolling.
      // Also, this helps in waiting for the initial loading and mounting when Mock Sidebar is mounted,
      // before the initial scroll.
      requestIdleCallback(this.scrollToItemById.bind(this, itemToFocus), { timeout: 5000 });
    },
    { fireImmediately: true });
  }

  componentWillUnmount() {
    this.focusReactionDisposer && this.focusReactionDisposer();
  }

  resetFocusedItem() {
    this.mockStore.resetFocusedItem();
  }

  handleRetry() {
    this.mockStore.reload();
  }

  scrollToItemById(itemId) {
    if (!itemId) {
      return;
    }

    const itemIndex = _.findIndex(_.get(this.mockStore, 'filteredItems'), (visibleItem) => visibleItem.id === itemId);

    // Item not found
    if (itemIndex < 0) {
      return;
    }

    this.listRef && this.listRef.scrollToItem(itemIndex);
  }

  successHandler() {
    this.mockStore.hydrate();
  }

  handleRename(data, origin) {
    this.mockStore.rename(data, { origin });
  }

  handleCreate() {
    _services_MockNavigationService__WEBPACK_IMPORTED_MODULE_9__["default"].transitionTo(
    'build.mockCreate',
    {},
    {},
    { additionalContext: { origin: 'sidebar' } });

  }

  handleSearchChange(query) {
    this.mockStore.setSearchQuery(query);
  }

  componentDidMount() {
    pm.mediator.on('refreshSidebarMockListing', this.successHandler);
  }

  componentWillUnmount() {
    pm.mediator.off('refreshSidebarMockListing', this.successHandler);
  }

  createMock() {
    _services_MockNavigationService__WEBPACK_IMPORTED_MODULE_9__["default"].transitionTo(
    'build.mockCreate',
    {},
    {},
    { additionalContext: { origin: 'sidebar_empty_listing' } });

  }

  getFilteredMocks() {
    const filteredMocks = this.mockStore.filteredItems;

    return filteredMocks;
  }

  handleDeleteShortcut() {
    const permissions = _.get(this.mockStore, 'permissions', {}),
    mock = this.mockStore.filteredItems[this.mockStore.focusedItemIndex] || this.mockStore.filteredItems[this.mockStore.activeItemIndex],
    deleteMockEnabled = Object(_services_FetchPermissionService__WEBPACK_IMPORTED_MODULE_18__["hasPermission"])(permissions, mock.id, _constants_Permissions__WEBPACK_IMPORTED_MODULE_17__["DELETE_MOCK"]);

    if (!Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('SyncStatusStore').isSocketConnected) {
      pm.toasts.error(_constants_MockErrors__WEBPACK_IMPORTED_MODULE_16__["OFFLINE_ERROR"], {
        title: '你离线了' });

    } else
    if (!Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('CurrentUserStore').isLoggedIn) {
      return pm.mediator.trigger('showSignInModal', {
        type: 'mock',
        subtitle: _constants_MockErrors__WEBPACK_IMPORTED_MODULE_16__["NOT_SIGNED_IN_ERROR"],
        origin: 'shortcut' });

    } else
    if (!Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveWorkspaceStore').isMember) {
      return pm.mediator.trigger('openUnjoinedWorkspaceModal');
    } else
    if (mock && deleteMockEnabled) {
      pm.mediator.trigger(
      'showDeleteMockModal',
      mock,
      null,
      { origin: 'shortcut' });

    } else
    {
      pm.toasts.error(_constants_MockErrors__WEBPACK_IMPORTED_MODULE_16__["PERMISSION_ERROR"]);
    }
  }

  handleRenameShortcut() {
    const permissions = _.get(this.mockStore, 'permissions', {}),
    mock = this.mockStore.filteredItems[this.mockStore.focusedItemIndex] || this.mockStore.filteredItems[this.mockStore.activeItemIndex],
    updateMockEnabled = Object(_services_FetchPermissionService__WEBPACK_IMPORTED_MODULE_18__["hasPermission"])(permissions, mock.id, _constants_Permissions__WEBPACK_IMPORTED_MODULE_17__["EDIT_MOCK"]);

    if (!Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('SyncStatusStore').isSocketConnected) {
      pm.toasts.error(_constants_MockErrors__WEBPACK_IMPORTED_MODULE_16__["OFFLINE_ERROR"], {
        title: '你离线了' });

    } else
    if (!Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('CurrentUserStore').isLoggedIn) {
      return pm.mediator.trigger('showSignInModal', {
        type: 'mock',
        subtitle: _constants_MockErrors__WEBPACK_IMPORTED_MODULE_16__["NOT_SIGNED_IN_ERROR"],
        origin: 'shortcut' });

    } else
    if (!Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveWorkspaceStore').isMember) {
      return pm.mediator.trigger('openUnjoinedWorkspaceModal');
    } else
    if (!_.get(mock, 'active')) {
      pm.toasts.error(_constants_MockErrors__WEBPACK_IMPORTED_MODULE_16__["INACTIVE_MOCK"]);
    } else
    if (mock && updateMockEnabled) {
      _.invoke(this.listItemRefs[mock.id], 'handleEditName', { origin: 'shortcut' });
    } else
    {
      pm.toasts.error(_constants_MockErrors__WEBPACK_IMPORTED_MODULE_16__["PERMISSION_ERROR"]);
    }
  }

  getKeyMapHandlers() {
    return {
      nextItem: pm.shortcuts.handle('nextItem', this.focusNext),
      prevItem: pm.shortcuts.handle('prevItem', this.focusPrev),
      delete: pm.shortcuts.handle('delete', this.handleDeleteShortcut),
      rename: pm.shortcuts.handle('rename', this.handleRenameShortcut) };

  }

  focusNext(e) {
    e && e.preventDefault();

    this.mockStore.focusNext();
  }

  focusPrev(e) {
    e && e.preventDefault();

    this.mockStore.focusPrev();
  }

  getListItem({ index, style }) {
    const filteredMocks = this.getFilteredMocks(),
    mock = filteredMocks[index] || {},
    isSelected = _js_services_NavigationService__WEBPACK_IMPORTED_MODULE_10__["default"].isActive('build.mock', { mockId: mock.id }) ||
    _js_services_NavigationService__WEBPACK_IMPORTED_MODULE_10__["default"].isActive('build.mock', { mockId: mock.id }, { ctx: 'info' }) ||
    _js_services_NavigationService__WEBPACK_IMPORTED_MODULE_10__["default"].isActive('build.mockEdit', { mockId: mock.id }),
    permissions = _.get(this.mockStore, 'permissions', {});

    // Set the activeItem in mock list store every time a mock is selected
    if (isSelected) {
      this.mockStore.setActiveItem(mock.id);
    } else
    {
      // Clear the activeItem in mock list store every time an active mock tab is closed
      this.mockStore.activeItem === mock.id && this.mockStore.resetActiveItem();
    }

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_15__["default"], { identifier: mock.id }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { style: style }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_SidebarMockListItem__WEBPACK_IMPORTED_MODULE_7__["default"], {
        ref: (ref) => {this.listItemRefs[mock.id] = ref;},
        key: mock.id,
        mock: mock,
        onRename: this.handleRename,
        isSelected: this.mockStore.focusedItem === mock.id || isSelected,
        permissions: permissions,
        onResetFocusedItem: this.resetFocusedItem }))));




  }

  getTooltip() {
    const canAddMock = this.canAddMockToWorkspace();

    if (!Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('SyncStatusStore').isSocketConnected) {
      return _constants_MockErrors__WEBPACK_IMPORTED_MODULE_16__["OFFLINE_ERROR"];
    } else
    if (canAddMock) {
      return '创建模拟服务器';
    } else
    {
      return _constants_MockErrors__WEBPACK_IMPORTED_MODULE_16__["PERMISSION_ERROR"];
    }
  }

  /**
   * Helper function to check whether user can add mock to workspace
   */
  canAddMockToWorkspace() {
    const permissionStore = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('PermissionStore'),
    workspaceId = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('ActiveWorkspaceStore').id,
    canAddMock = !Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('CurrentUserStore').isLoggedIn ||
    permissionStore.can('addMock', 'workspace', workspaceId);

    return canAddMock;
  }

  getSidebarEmptyState() {
    const canAddMock = this.canAddMockToWorkspace(),
    isOnline = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('SyncStatusStore').isSocketConnected;

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_sidebar_SidebarEmptyState_SidebarEmptyState__WEBPACK_IMPORTED_MODULE_14__["default"], {
        illustration: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_5__["IllustrationNoMockServer"], null),
        title: "您没有任何模拟服务器.",
        message: "模拟服务器使您可以模拟集合中的端点及其对应的响应,而无需实际设置后端.",
        action: {
          label: '创建模拟服务器',
          handler: this.createMock,
          tooltip: this.getTooltip() },

        hasPermissions: isOnline && canAddMock }));


  }

  getListContainer() {
    const mocks = this.mockStore.values,
    filteredMocks = this.getFilteredMocks(),
    searchQuery = this.mockStore.searchQuery,
    fetchingMocks = this.mockStore.isHydrating;

    if (fetchingMocks) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_sidebar_SidebarLoadingState_SidebarLoadingState__WEBPACK_IMPORTED_MODULE_13__["default"], null));

    }

    if (mocks.length === 0 && !searchQuery) {
      return this.getSidebarEmptyState();
    }

    if (filteredMocks.length === 0) {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_sidebar_SidebarNoResultsFound_SidebarNoResultsFound__WEBPACK_IMPORTED_MODULE_12__["default"], { searchQuery: searchQuery, illustration: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_5__["IllustrationSearch"], null) });
    } else

    {
      const lister = (data) => /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mobx_react__WEBPACK_IMPORTED_MODULE_1__["Observer"], null,
      this.getListItem.bind(this, data));



      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_virtualized_auto_sizer__WEBPACK_IMPORTED_MODULE_2__["default"], null,
        ({ height, width }) => /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_window__WEBPACK_IMPORTED_MODULE_3__["FixedSizeList"], {
          height: height,
          width: width,
          itemCount: filteredMocks.length,
          ref: (ref) => {this.listRef = ref;},
          itemSize: MIN_ROW_HEIGHT,
          overscanCount: OVERSCAN_COUNT },

        lister)));




    }
  }

  render() {
    const errorFetchingMocks = this.mockStore.errorFetchingMocks,
    searchQuery = this.mockStore.searchQuery,
    isOffline = this.mockStore.isOffline,
    isSocketConnected = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('SyncStatusStore').isSocketConnected;

    if (isOffline) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_MockOffline__WEBPACK_IMPORTED_MODULE_19__["default"], { origin: "sidebar" }));

    }

    if (errorFetchingMocks) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "sidebar-mock-listing__error__wrapper" }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "sidebar-mock-listing__error" }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_5__["IllustrationInternalServerError"], null), /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "sidebar-mock-listing__error__content" }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "sidebar-mock-listing__error__content__header" }, "出了些问题"), /*#__PURE__*/


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "sidebar-mock-listing__error__content__sub-header" }, "加载模拟服务器时发生意外错误. 请再试一次.")), /*#__PURE__*/



        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_8__["Button"], {
          className: "btn-small sidebar-mock-listing__error__retry-button",
          type: "primary",
          onClick: this.handleRetry }, "再试一次"))));






    }

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "sidebar-mock-listing__container" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_containers_apps_requester_sidebar_SidebarListActions__WEBPACK_IMPORTED_MODULE_11__["default"], {
        createNewConfig: {
          tooltip: this.getTooltip(),
          disabled: !this.canAddMockToWorkspace() || !isSocketConnected,
          onCreate: this.handleCreate,
          xPathIdentifier: 'addMock' },

        onSearch: this.handleSearchChange,
        searchQuery: searchQuery }), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_20__["default"], { handlers: this.getKeyMapHandlers() }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "sidebar-mock-listing__container__list" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_15__["default"], { identifier: "mock" },

      this.getListContainer())))));






  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 9022:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SidebarMockListItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2293);
/* harmony import */ var _js_utils_ClipboardHelper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2346);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1601);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2325);
/* harmony import */ var _js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2845);
/* harmony import */ var _js_containers_apps_requester_sidebar_SidebarListItem__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9023);
/* harmony import */ var _constants_MockErrors__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2383);
/* harmony import */ var _constants_Permissions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2854);
/* harmony import */ var _services_FetchPermissionService__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2855);
/* harmony import */ var _js_modules_services_ManageRolesModalService__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2374);
/* harmony import */ var _InactiveMockIndicator__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9024);
/* harmony import */ var _js_modules_services_ShareModalService__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2373);
/* harmony import */ var _js_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(4332);
/* harmony import */ var _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1812);
var _class;
















let


SidebarMockListItem = Object(mobx_react__WEBPACK_IMPORTED_MODULE_3__["observer"])(_class = class SidebarMockListItem extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.containerRef = this.containerRef.bind(this);
    this.handleEditName = this.handleEditName.bind(this);
    this.handleCopyUrl = this.handleCopyUrl.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
    this.getMenuItems = this.getMenuItems.bind(this);
    this.getRightAlignedContainer = this.getRightAlignedContainer.bind(this);
    this.getActions = this.getActions.bind(this);
    this.getStatusIndicators = this.getStatusIndicators.bind(this);
    this.handleDropdownActionSelect = this.handleDropdownActionSelect.bind(this);
    this.handleRenameSubmit = this.handleRenameSubmit.bind(this);
    this.handleManageRoles = this.handleManageRoles.bind(this);
  }

  handleManageRoles() {
    _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_16__["default"].addEventV2({
      category: 'mock',
      action: 'initiate_manage_roles',
      label: 'sidebar',
      entityId: _.get(this.props, 'mock.id') });


    Object(_js_modules_services_ManageRolesModalService__WEBPACK_IMPORTED_MODULE_12__["manageRolesOnMock"])(_.get(this.props, 'mock.id'), { origin: 'sidebar_mock_listing' });
  }

  handleDropdownActionSelect(action) {
    if (!Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('CurrentUserStore').isLoggedIn) {
      return pm.mediator.trigger('showSignInModal', {
        type: 'mock',
        subtitle: _constants_MockErrors__WEBPACK_IMPORTED_MODULE_9__["NOT_SIGNED_IN_ERROR"],
        origin: 'sidebar_mock_listing' });

    }

    if (!Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('ActiveWorkspaceStore').isMember) {
      return pm.mediator.trigger('openUnjoinedWorkspaceModal');
    }

    switch (action) {
      case 'delete':
        this.handleDelete();

        return;
      case 'rename':
        this.handleEditName({ origin: 'sidebar' });

        return;
      case 'manage-roles':
        this.handleManageRoles();

        return;
      case 'move':
        _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_16__["default"].addEventV2({
          category: 'mock',
          action: 'initiate_move',
          label: 'sidebar',
          entityId: _.get(this.props, 'mock.id') });


        Object(_js_modules_services_ShareModalService__WEBPACK_IMPORTED_MODULE_14__["moveMock"])(_.get(this.props, 'mock.id'), { origin: 'mock_sidebar' });

        return;}

  }

  containerRef(ele) {
    this.listItem = ele;
  }

  getMenuItemIconClasses(label) {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({ 'dropdown-menu-item-icon': true }, 'menu-icon--' + label);
  }

  getStatusIndicators() {
    const mockId = _.get(this.props, 'mock.id'),
    permissions = this.props.permissions || {},
    deleteMockEnabled = Object(_services_FetchPermissionService__WEBPACK_IMPORTED_MODULE_11__["hasPermission"])(permissions, mockId, _constants_Permissions__WEBPACK_IMPORTED_MODULE_10__["DELETE_MOCK"]),
    updateMockEnabled = Object(_services_FetchPermissionService__WEBPACK_IMPORTED_MODULE_11__["hasPermission"])(permissions, mockId, _constants_Permissions__WEBPACK_IMPORTED_MODULE_10__["EDIT_MOCK"]);

    return (
      !(updateMockEnabled && deleteMockEnabled) && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_2__["Icon"], {
        name: "icon-state-locked-stroke",
        color: "content-color-tertiary",
        className: "mock-status-icon",
        size: "small",
        title: "只读" }));


  }

  handleDelete() {
    pm.mediator.trigger(
    'showDeleteMockModal',
    this.props.mock,
    null,
    { origin: 'sidebar' });

  }

  getMockUrl() {
    return _.get(this.props, 'mock.url', '');
  }

  handleCopyUrl() {
    _js_utils_ClipboardHelper__WEBPACK_IMPORTED_MODULE_4__["default"].copy(this.getMockUrl());

    pm.toasts.success('模拟URL已拷贝');

    _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_16__["default"].addEventV2({
      category: 'mock',
      action: 'copy_url',
      label: 'sidebar',
      entityId: _.get(this.props, 'mock.id') });

  }

  getActions() {
    const currentUser = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('CurrentUserStore'),
    mockId = _.get(this.props, 'mock.id'),
    permissions = this.props.permissions || {},
    isOnline = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('SyncStatusStore').isSocketConnected,
    deleteMockEnabled = isOnline && (!currentUser.isLoggedIn ||
    Object(_services_FetchPermissionService__WEBPACK_IMPORTED_MODULE_11__["hasPermission"])(permissions, mockId, _constants_Permissions__WEBPACK_IMPORTED_MODULE_10__["DELETE_MOCK"])),
    updateMockEnabled = isOnline && _.get(this.props, 'mock.active') && (!currentUser.isLoggedIn ||
    Object(_services_FetchPermissionService__WEBPACK_IMPORTED_MODULE_11__["hasPermission"])(permissions, mockId, _constants_Permissions__WEBPACK_IMPORTED_MODULE_10__["EDIT_MOCK"])),
    manageRolesEnabled = isOnline && _.get(this.props, 'mock.active') && (!currentUser.isLoggedIn ||
    Object(_services_FetchPermissionService__WEBPACK_IMPORTED_MODULE_11__["hasPermission"])(permissions, mockId, _constants_Permissions__WEBPACK_IMPORTED_MODULE_10__["UPDATE_MOCK_ROLES"]) && !!currentUser.team),
    moveMockEnabled = isOnline && Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('FeatureFlagsStore').isEnabled('moveMocks') &&
    _.get(this.props, 'mock.active') && (!currentUser.isLoggedIn ||
    Object(_services_FetchPermissionService__WEBPACK_IMPORTED_MODULE_11__["hasPermission"])(permissions, mockId, _constants_Permissions__WEBPACK_IMPORTED_MODULE_10__["MOVE_MOCK"]));

    let actions = [
    {
      type: 'rename',
      label: '重命名',
      isEnabled: updateMockEnabled,
      xpathLabel: 'rename',
      shortcut: 'rename' },

    {
      type: 'manage-roles',
      label: '管理角色',
      isEnabled: manageRolesEnabled,
      xpathLabel: 'manageRoles' }];



    if (Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('FeatureFlagsStore').isEnabled('moveMocks')) {
      actions.push({
        type: 'move',
        label: '移动',
        isEnabled: moveMockEnabled,
        xpathLabel: 'moveMock' });

    }

    // Making sure that delete is the last option
    actions.push({
      type: 'delete',
      label: '删除',
      isEnabled: deleteMockEnabled,
      xpathLabel: 'delete',
      shortcut: 'delete' });


    return actions;
  }

  getDisabledText(isDisabled, actionType) {
    if (isDisabled) {
      let defaultMessage = _constants_MockErrors__WEBPACK_IMPORTED_MODULE_9__["PERMISSION_ERROR"],
      manageRolesMessage = _constants_MockErrors__WEBPACK_IMPORTED_MODULE_9__["NO_TEAM"];

      if (!_.get(this.props, 'mock.active')) {
        if (actionType === 'delete') {
          const deleteMockEnabled = !Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('CurrentUserStore').isLoggedIn || Object(_services_FetchPermissionService__WEBPACK_IMPORTED_MODULE_11__["hasPermission"])(_.get(this.props, 'mockStore.permissions', {}), _.get(this.props, 'mock.id'), _constants_Permissions__WEBPACK_IMPORTED_MODULE_10__["DELETE_MOCK"]);

          if (!deleteMockEnabled) {
            return defaultMessage;
          }
        } else {
          return _constants_MockErrors__WEBPACK_IMPORTED_MODULE_9__["INACTIVE_MOCK"];
        }
      }

      if (!Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('SyncStatusStore').isSocketConnected) {
        return _constants_MockErrors__WEBPACK_IMPORTED_MODULE_9__["OFFLINE_ERROR"];
      }

      switch (actionType) {
        case 'manage-roles':
          const permissions = this.props.permissions || {},
          mockId = _.get(this.props, 'mock.id'),
          manageRolesPermission = Object(_services_FetchPermissionService__WEBPACK_IMPORTED_MODULE_11__["hasPermission"])(permissions, mockId, _constants_Permissions__WEBPACK_IMPORTED_MODULE_10__["UPDATE_MOCK_ROLES"]);

          if (manageRolesPermission && !Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_5__["getStore"])('CurrentUserStore').team) {
            return manageRolesMessage;
          }

          return defaultMessage;

        default:
          return defaultMessage;}

    }
  }

  handleEditName(options = {}) {
    this.setState({ origin: options.origin }, () => {
      _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_16__["default"].addEventV2({
        category: 'mock',
        action: 'initiate_rename',
        label: options.origin,
        entityId: _.get(this.props, 'mock.id') });

    });

    _.invoke(this.listItem, 'editText');
  }

  handleRenameSubmit(value) {
    if (_.get(this.props, 'mock.name') === value) {
      return;
    }

    const editPayload = {
      id: _.get(this.props, 'mock.id'),
      name: value };


    this.props.onRename(editPayload, this.state.origin);

    _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_16__["default"].addEventV2({
      category: 'mock',
      action: 'submit_rename',
      label: this.state.origin,
      entityId: _.get(this.props, 'mock.id') });

  }

  getRouteConfig() {
    return {
      routeIdentifier: 'build.mock',
      routeParams: {
        mockId: _.get(this.props, 'mock.id') } };


  }

  getOptions() {
    return {
      additionalContext: { origin: 'sidebar' } };

  }

  getMenuItems() {
    return _.chain(this.getActions()).
    map((action) => {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["MenuItem"], {
          key: action.type,
          refKey: action.type,
          disabled: !action.isEnabled,
          disabledText: this.getDisabledText(!action.isEnabled, action.type) }, /*#__PURE__*/

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", { className: "mock-action-item" }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "dropdown-menu-item-label" }, action.label),

        action.shortcut && /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "dropdown-menu-item-shortcut" }, Object(_js_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_15__["getShortcutByName"])(action.shortcut)))));




    }).value();
  }

  getRightAlignedContainer(isHovered, isMoreActionsDropdownOpen) {
    const classNames = classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'sidebar-mock-list-item__actions': true,
      hovered: isHovered });


    if (!isHovered && !isMoreActionsDropdownOpen) {
      if (_.get(this.props, 'mock.active')) {
        return null;
      }

      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "inactive-mock-indicator__sidebar_fixed" }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_InactiveMockIndicator__WEBPACK_IMPORTED_MODULE_13__["default"], null)));


    }

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null,

      !_.get(this.props, 'mock.active') && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_InactiveMockIndicator__WEBPACK_IMPORTED_MODULE_13__["default"], null), /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_6__["Button"], {
        className: "sidebar-action-btn",
        tooltip: "拷贝模拟URL",
        type: "icon",
        onClick: this.handleCopyUrl }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_2__["Icon"], {
        name: "icon-action-copy-stroke",
        className: "pm-icon pm-icon-normal" }))));





  }

  getActionsMenuItems() {
    const menuItems = this.getMenuItems();

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["DropdownMenu"], {
        className: 'mocks-dropdown-menu',
        "align-right": true },

      menuItems));


  }

  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_containers_apps_requester_sidebar_SidebarListItem__WEBPACK_IMPORTED_MODULE_8__["default"], {
        ref: this.containerRef,
        text: _.get(this.props, 'mock.name', ''),
        isSelected: this.props.isSelected,
        onClick: this.props.onResetFocusedItem,
        onRename: this.handleRenameSubmit,
        rightMetaComponent: this.getRightAlignedContainer,
        moreActions: this.getActionsMenuItems(),
        statusIndicators: this.getStatusIndicators,
        onActionsDropdownSelect: this.handleDropdownActionSelect,
        routeConfig: this.getRouteConfig(),
        options: this.getOptions() }));


  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ })

}]);