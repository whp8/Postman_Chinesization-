(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[54],{

/***/ 14701:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return APIChangelogContextBarViewController; });
/* harmony import */ var _postman_date_helper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2304);
/* harmony import */ var _postman_date_helper__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_postman_date_helper__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _schema_services_ChangelogService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(14699);
/* harmony import */ var _js_stores_CollectionActivityFeedStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8449);
/* harmony import */ var _services_APIDevService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2255);
function _extends() {_extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};return _extends.apply(this, arguments);}





// Purpose: Fetch and combine the data as needed for the combined changelog view
class APIChangelogContextBarViewController {
  async fetchChangelog(model) {
    try {
      let combinedChangeLog = [],
      schemaChangeLog = [],
      fetchAllChangelog = [],
      collectionChangelogStores = [];

      const schemaChangelogFetchPromise = this.handleFetchSchemaChangelog(model);

      fetchAllChangelog.push(schemaChangelogFetchPromise);

      this.handleFetchCollectionChangelog(model, fetchAllChangelog, collectionChangelogStores);

      // Resolve all promises to fetch changelogs
      const groupedChangelogs = await Promise.all(fetchAllChangelog);

      // First element in schema changelog
      schemaChangeLog = _.head(groupedChangelogs);

      // Adding an extra field 'changeType' with value as 'schema'
      // Using this key SchemaChange will be rendered as this is a schema change
      combinedChangeLog = schemaChangeLog.revisions.map((change) => _extends({}, change, { changeType: 'schema', enableRestore: true }));

      // Adding an extra field 'changeType' with value as 'collection'
      // Using this key CollectionChange will be rendered as this is a collection change
      _.map(collectionChangelogStores, (collectionChangelogStore) => {
        const collectionChangelog = _.map(_.get(collectionChangelogStore, 'feeds', []), (change) => _extends({},
        change, { changeType: 'collection',
          meta: collectionChangelogStore.meta,
          collectionUid: _.get(collectionChangelogStore, 'collectionUid'),
          enableRestore: !(change.id === _.head(_.get(collectionChangelogStore, 'feeds', [])).id) }));


        combinedChangeLog = _.concat(combinedChangeLog, collectionChangelog);
      });

      // Chronologically sorting combined changelog in descending order
      combinedChangeLog = _.
      chain(combinedChangeLog).
      sortBy('createdAt').
      reverse().
      value();

      const releases = await model.getAllReleasesForVersion(),
      releaseGroups = this.groupChangesByRelease(combinedChangeLog, releases);

      return releaseGroups;
    }
    catch (err) {
      throw err;
    }
  }

  groupChangesByRelease(changelog, releases) {
    let releaseGroups = releases;

    // Pushing Unreleased changes block to the beginning of releases
    releaseGroups.unshift({
      name: '未发行的更改',
      id: 'unreleasedChanges' });


    let changeIterator = 0,
    releaseIterator = 0;

    while (changeIterator < changelog.length) {
      const change = changelog[changeIterator],
      currentRelease = releaseGroups[releaseIterator],
      nextRelease = releaseGroups[releaseIterator + 1];

      if (releaseIterator === releaseGroups.length - 1 || change.createdAt > nextRelease.createdAt) {
        !currentRelease.changelog ? currentRelease.changelog = [change] :
        currentRelease.changelog.push(change);

        changeIterator++;
      } else
      {
        releaseIterator++;
      }
    }

    releaseGroups = releaseGroups.map((releaseGroup) => {
      const changesGroupedByDate = _postman_date_helper__WEBPACK_IMPORTED_MODULE_0___default.a.getDateGroups(releaseGroup.changelog, 'createdAt', 'MMMM D, YYYY');

      return _extends({}, releaseGroup, { changesGroupedByDate });
    });

    return releaseGroups;
  }

  handleFetchSchemaChangelog(model) {
    const maxId = null,
    apiId = model.apiId,
    versionId = model.id,
    schemaId = _.get(model, 'schema.schemaId');

    // Handle Schema doesn't exist case gracefully
    if (!schemaId) {
      return Promise.resolve({ revisions: [] });
    }

    return Object(_schema_services_ChangelogService__WEBPACK_IMPORTED_MODULE_1__["fetchChangelog"])(apiId, versionId, schemaId, maxId);
  }

  handleFetchCollectionChangelog(model, fetchAllChangelog, collectionChangelogStores) {
    _.map(this.fetchCollectionIds(model), async (collectionId) => {
      const collectionChangeLogStore = new _js_stores_CollectionActivityFeedStore__WEBPACK_IMPORTED_MODULE_2__["default"]();

      fetchAllChangelog.push(collectionChangeLogStore.initialize(collectionId));
      collectionChangelogStores.push(collectionChangeLogStore);
    });
  }

  fetchCollectionIds(apiVersion) {
    const collectionIds = new Set(),
    relationTypes = ['documentations', 'testSuites', 'contractTests', 'integrationTests'];

    _.map(relationTypes, (relationType) => {
      _.map(_.get(apiVersion, `${relationType}.relations`, []), (relation) => {
        collectionIds.add(relation.modelId);
      });
    });

    // Using Set to avoid duplicate items changelog
    // This situation would arise when same collection was used to create multiple relations
    return Array.from(collectionIds);
  }}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ })

}]);