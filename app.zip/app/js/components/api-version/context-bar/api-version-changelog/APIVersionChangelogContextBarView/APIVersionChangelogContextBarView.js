(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[53],{

/***/ 14688:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return APIVersionChangelogContextBarView; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2293);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1595);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2862);
/* harmony import */ var _APIVersionChangelogGroup_APIVersionChangelogGroup__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(14689);
/* harmony import */ var _js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2322);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1601);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2325);
/* harmony import */ var _schema_components_ErrorChangelog__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(14692);
/* harmony import */ var _schema_components_OfflineChangelog__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(14691);
/* harmony import */ var _release_EditRelease_EditReleaseModal__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7506);
/* harmony import */ var _release_DeleteRelease_DeleteReleaseModal__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7505);
/* harmony import */ var _util_TooltipText__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7277);
/* harmony import */ var _js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(2845);
/* harmony import */ var _js_services_NavigationService__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1801);
/* harmony import */ var _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(1812);
var _class;



















const IS_UNRELEASED = (release) => _.get(release, 'id') === 'unreleasedChanges';let


APIVersionChangelogContextBarView = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class APIVersionChangelogContextBarView extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      releaseGroups: [],
      isLoading: true,
      loadingErr: false,
      isEditReleaseOpen: false,
      releaseName: '',
      releaseDescription: '',
      releaseToEdit: null,
      isDeleteReleaseOpen: false,
      releaseToDelete: null,
      releaseVisibility: false };


    this.fetchChangelogs = this.fetchChangelogs.bind(this);
    this.setEditReleaseModalOpen = this.setEditReleaseModalOpen.bind(this);
    this.setDeleteReleaseModalOpen = this.setDeleteReleaseModalOpen.bind(this);
  }

  componentDidMount() {
    this.fetchChangelogs();

    // @TODO: Remove usage of this reaction and instead use releases as observable
    // to track changes and update UI
    this.isReleaseChanging = Object(mobx__WEBPACK_IMPORTED_MODULE_2__["reaction"])(
    () => _.get(this.props, 'contextData.model.isLoadingAddRelease') ||
    _.get(this.props, 'contextData.model.isUpdatingRelease') ||
    _.get(this.props, 'contextData.model.isDeletingRelease'),
    (isLoadingRelease) => {
      // Fetch logs again once Release loading finishes after any CUD operation on releases
      if (!isLoadingRelease) {
        this.fetchChangelogs();
      }
    });

  }

  componentWillUnmount() {
    this.isReleaseChanging && this.isReleaseChanging();
  }

  getRefreshTextClass() {
    return classnames__WEBPACK_IMPORTED_MODULE_3___default()({
      'api-changelog-context-view-wrapper__refresh-button': true,
      'api-changelog-context-view-wrapper__refresh-button__loading': this.state.isLoading });

  }

  getRefreshIconText() {
    if (!Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('SyncStatusStore').isSocketConnected) {
      return '联网以执行此操作';
    }

    if (this.state.isLoading) {
      return '请稍等...';
    }

    return '刷新更新日志';
  }

  fetchChangelogs() {
    this.setState({
      releaseGroups: [],
      isLoading: true,
      loadingErr: false });


    // Deferring changelog fetch until schema is loaded
    // @TODO, account for relations as well
    Object(mobx__WEBPACK_IMPORTED_MODULE_2__["when"])(
    () => !_.get(this.props, 'contextData.schemaLoading'),
    () => {
      this.props.controller.fetchChangelog(_.get(this.props, 'contextData.model', {})).
      then((releaseGroups) => {
        this.setState({
          releaseGroups: releaseGroups,
          isLoading: false });

      }).catch((e) => {
        this.setState({
          isLoading: false,
          loadingErr: true });

      });
    });
  }

  /**
   * Handler method when an action is clicked
   * @param {String} action
   */
  handleReleaseActionSelect(release, action) {
    const releaseId = _.get(release, 'id'),
    releaseName = _.get(release, 'name'),
    releaseDescription = _.get(release, 'description'),
    releaseVisibility = _.get(release, 'visibility');

    switch (action) {
      case 'edit':{
          _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_17__["default"].addEventV2({
            category: 'release',
            action: 'initiate_edit',
            label: 'changelog',
            value: 1,
            entityId: releaseId });


          return this.setEditReleaseModalOpen(true, releaseId, releaseName, releaseDescription, releaseVisibility);
        }

      case 'delete':{
          _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_17__["default"].addEventV2({
            category: 'release',
            action: 'initiate_delete',
            label: 'changelog',
            value: 1,
            entityId: releaseId });


          return this.setDeleteReleaseModalOpen(true, releaseId);
        }}

  }

  handleNameClick(release) {
    const releaseId = _.get(release, 'id'),
    versionId = _.get(this.props, 'contextData.model.id'),
    apiId = _.get(this.props, 'contextData.model.apiId');

    if (releaseId === 'unreleasedChanges') {
      return;
    }

    _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_17__["default"].addEventV2({
      category: 'release',
      action: 'view',
      label: 'changelog',
      value: 1,
      entityId: releaseId });


    // To promote the API tab to permanent if in preview mode
    _.get(this.props, 'contextData.promoteTab') &&
    _.isFunction(this.props.contextData.promoteTab) &&
    this.props.contextData.promoteTab();

    _js_services_NavigationService__WEBPACK_IMPORTED_MODULE_16__["default"].transitionTo('build.release',
    {
      apiId: apiId,
      apiVersionId: versionId,
      releaseId: `${releaseId}` });


  }

  renderViewRelease(release) {
    if (IS_UNRELEASED(release)) {
      return;
    }

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-changelog__content__view-release" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_8__["Button"], {
        onClick: this.handleNameClick.bind(this, release),
        type: "plain",
        text: "查看此发行" }), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_8__["IconDirectionForward"], { className: "button-icon" })));


  }

  renderReleaseActions(release) {
    const canUpdateRelease = _.get(this.props.contextData.model, 'apiPermissionStore.canUpdateRelease'),
    isUpdateReleaseDisabled = !canUpdateRelease,
    isOffline = !Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('SyncStatusStore').isSocketConnected,
    isEditOrDeleteReleaseDisabled = isOffline,
    isDropdownItemDisabled = isEditOrDeleteReleaseDisabled || isUpdateReleaseDisabled;

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_15__["Dropdown"], {
        className: "api-changelog__header__release-actions__dropdown",
        onSelect: this.handleReleaseActionSelect.bind(this, release) }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_15__["DropdownButton"], {
        dropdownStyle: "nocaret",
        type: "custom" }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_8__["Button"], {
        type: "tertiary",
        icon: "icon-action-options-stroke",
        size: "small",
        className: "api-changelog__header__release-actions__dropdown__button" })), /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_15__["DropdownMenu"], { "align-right": true }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_15__["MenuItem"], {
        disabled: isDropdownItemDisabled,
        disabledText: Object(_util_TooltipText__WEBPACK_IMPORTED_MODULE_14__["default"])(isDropdownItemDisabled, !this.canUpdateRelease),
        refKey: "edit" }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, "编辑")), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_15__["MenuItem"], {
        disabled: isDropdownItemDisabled,
        disabledText: Object(_util_TooltipText__WEBPACK_IMPORTED_MODULE_14__["default"])(isDropdownItemDisabled, !this.canUpdateRelease),
        refKey: "delete" }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, "删除"))))));





  }

  renderChangelog() {
    const isOffline = !Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('SyncStatusStore').isSocketConnected;
    const canUpdateRelease = _.get(this.props.contextData.model, 'apiPermissionStore.canUpdateRelease');

    if (isOffline && this.state.isLoading) {
      return /*#__PURE__*/ (

        // @TODO: Recreate these base components for API changelog
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_schema_components_OfflineChangelog__WEBPACK_IMPORTED_MODULE_11__["default"], null));

    }

    if (this.state.isLoading) {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_6__["default"], null);
    }

    if (this.state.loadingErr) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_schema_components_ErrorChangelog__WEBPACK_IMPORTED_MODULE_10__["default"], {
          onRetry: this.fetchChangelogs }));

    }

    const model = _.get(this.props, 'contextData.model', {});

    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-changelog" },
    _.map(this.state.releaseGroups, (release, releaseIndex) => /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_APIVersionChangelogGroup_APIVersionChangelogGroup__WEBPACK_IMPORTED_MODULE_5__["default"], {
      model: model,
      release: release,
      promoteTab: _.get(this.props, 'contextData.promoteTab'),
      setEditReleaseModalOpen: this.setEditReleaseModalOpen,
      setDeleteReleaseModalOpen: this.setDeleteReleaseModalOpen,
      canUpdateRelease: canUpdateRelease,
      renderActions: this.renderReleaseActions.bind(this, release),
      renderViewRelease: this.renderViewRelease.bind(this, release),
      isLastRelease: releaseIndex === _.get(this.state.releaseGroups, 'length') - 1,
      handleRefresh: this.fetchChangelogs })));



  }

  setEditReleaseModalOpen(isEditReleaseOpen, releaseToEdit, releaseName, releaseDescription, releaseVisibility) {
    this.setState({ isEditReleaseOpen, releaseToEdit, releaseName, releaseDescription, releaseVisibility });
  }

  setDeleteReleaseModalOpen(isDeleteReleaseOpen, releaseToDelete) {
    this.setState({ isDeleteReleaseOpen, releaseToDelete });
  }

  render() {
    const model = _.get(this.props, 'contextData.model', {});

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-changelog-context-view-wrapper" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_4__["ContextBarViewHeader"], {
        title: this.props.title,
        onClose: this.props.onClose }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_9__["Button"], {
        className: this.getRefreshTextClass(),
        tooltip: this.getRefreshIconText(),
        tooltipImmediate: true,
        type: "tertiary",
        onClick: this.fetchChangelogs,
        disabled: this.state.isLoading ||
        !Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_7__["getStore"])('SyncStatusStore').isSocketConnected }, /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_8__["Icon"], {
        name: "icon-action-refresh-stroke" }))),



      this.renderChangelog(), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_release_EditRelease_EditReleaseModal__WEBPACK_IMPORTED_MODULE_12__["default"], {
        origin: "changelog",
        isOpen: _.get(this.state, 'isEditReleaseOpen'),
        releaseId: this.state.releaseToEdit,
        releaseName: this.state.releaseName,
        releaseVisibility: this.state.releaseVisibility,
        releaseDescription: this.state.releaseDescription,
        apiId: model.apiId,
        apiVersionId: _.get(model, 'id')

        // @TODO: Remove usage of this once transient states are not required at version store level
        , model: model,
        toggleUpdateReleaseModal: this.setEditReleaseModalOpen }), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_release_DeleteRelease_DeleteReleaseModal__WEBPACK_IMPORTED_MODULE_13__["default"], {
        origin: "changelog",
        isOpen: _.get(this.state, 'isDeleteReleaseOpen'),
        releaseId: this.state.releaseToDelete,
        apiId: model.apiId,
        apiVersionId: model.id,
        deleteReleaseHandler: model.deleteRelease

        // @TODO: Remove usage of this once transient states are not required at version store level
        , model: model,
        isDeletingRelease: _.get(model, 'isDeletingRelease'),
        toggleDeleteReleaseModal: this.setDeleteReleaseModalOpen })));



  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ })

}]);