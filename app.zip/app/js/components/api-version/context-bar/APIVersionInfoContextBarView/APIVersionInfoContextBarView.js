(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[55],{

/***/ 14702:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return APIVersionInfoContextBarView; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2293);
/* harmony import */ var _appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2862);
/* harmony import */ var _js_utils_ClipboardHelper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2346);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2325);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3737);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _common_UserProfile_UserProfile__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(14685);
/* harmony import */ var _common_APIOffline_APIOffline__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7507);
var _class;function _extends() {_extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};return _extends.apply(this, arguments);}









const COPIED_TICK_DURATION = 3000;let


APIVersionInfoContextBarView = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class APIVersionInfoContextBarView extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      entityIdCopied: {
        id: false,
        versionId: false,
        schemaId: false } };



    this.handleCopyToClipboard = this.handleCopyToClipboard.bind(this);
  }

  componentWillUnmount() {
    clearTimeout(this.copiedTimeout);
  }

  /**
   * Copies data to clipboard and changes icon state for meta info from copy to success tick, triggered when copy icon is clicked.
   * @param {String} path its the path to the key we want to copy from props.contextData, possible values are id, versionId and schemaId
   */
  handleCopyToClipboard(path) {
    if (_.get(this.state.entityIdCopied, path)) {
      return;
    }

    _js_utils_ClipboardHelper__WEBPACK_IMPORTED_MODULE_3__["default"].copy(_.get(this.props.contextData, path, ''));

    this.setState((prevState) => {
      return { entityIdCopied: _extends({},
        prevState.entityIdCopied, {
          [path]: true }) };

    },
    () => {
      this.copiedTimeout = setTimeout(
      () => this.setState((prevState) => {
        return { entityIdCopied: _extends({},
          prevState.entityIdCopied, {
            [path]: false }) };


      }),
      COPIED_TICK_DURATION);

    });
  }

  render() {
    const api = _.get(this.props, 'contextData', {}),
    userFriendlyVersionCreatedAt = moment__WEBPACK_IMPORTED_MODULE_6___default()(api.versionCreatedAt).format('DD MMM YYYY, h:mm A');

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-info-context-view-wrapper" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_2__["ContextBarViewHeader"], {
        title: 'API 版本详情',
        onClose: this.props.onClose }),

      api.isOffline ? /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_APIOffline_APIOffline__WEBPACK_IMPORTED_MODULE_8__["default"], { origin: "context-bar" }) : /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-info-context-view" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-info-context-view__entity" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-info-context-view__entity__label" }, "版本"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-info-context-view__entity__content" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "api-info-context-view__entity__content__id",
        title: api.versionName },

      api.versionName))), /*#__PURE__*/



      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-info-context-view__entity" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-info-context-view__entity__label" }, "版本 ID"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-info-context-view__entity__content" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "api-info-context-view__entity__content__id--entity",
        title: api.versionId },

      api.versionId), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_4__["Button"], {
        tooltip: "拷贝",
        type: "icon",
        onClick: () => this.handleCopyToClipboard('versionId') },

      _.get(this.state.entityIdCopied, 'versionId') ? /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_5__["Icon"], {
        name: "icon-state-success-stroke",
        className: "pm-icon pm-icon-normal success-tick-icon" }) : /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_5__["Icon"], {
        name: "icon-action-copy-stroke",
        className: "pm-icon pm-icon-normal" })))),






      this.props.contextData.schemaId && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-info-context-view__entity" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-info-context-view__entity__label" }, "架构 ID"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-info-context-view__entity__content" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "api-info-context-view__entity__content__id--entity",
        title: this.props.contextData.schemaId },

      this.props.contextData.schemaId), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_4__["Button"], {
        tooltip: "拷贝",
        type: "icon",
        onClick: () => this.handleCopyToClipboard('schemaId') },

      _.get(this.state.entityIdCopied, 'schemaId') ? /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_5__["Icon"], {
        name: "icon-state-success-stroke",
        className: "pm-icon pm-icon-normal success-tick-icon" }) : /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_5__["Icon"], {
        name: "icon-action-copy-stroke",
        className: "pm-icon pm-icon-normal" })))), /*#__PURE__*/






      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-info-context-view__entity" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-info-context-view__entity__label" }, "创建者"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-info-context-view__entity__content" },

      _.get(api, 'versionCreatedBy.id') ? /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_UserProfile_UserProfile__WEBPACK_IMPORTED_MODULE_7__["default"], {
        id: _.get(api, 'versionCreatedBy.id'),
        name: _.get(api, 'versionCreatedBy.name'),
        username: _.get(api, 'versionCreatedBy.username'),
        profileLink: _.get(api, 'versionCreatedBy.profileLink'),
        isAccessible: _.get(api, 'versionCreatedBy.isAccessible') }) :


      '无效的用户')), /*#__PURE__*/




      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-info-context-view__entity" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-info-context-view__entity__label" }, "创建于"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "api-info-context-view__entity__content" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "api-info-context-view__entity__content__id",
        title: userFriendlyVersionCreatedAt },

      userFriendlyVersionCreatedAt))))));







  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ })

}]);