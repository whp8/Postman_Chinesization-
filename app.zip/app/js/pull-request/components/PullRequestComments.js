(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[43],{

/***/ 9746:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EmptyState", function() { return EmptyState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return PullRequestComments; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2293);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1595);
/* harmony import */ var _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2327);
/* harmony import */ var _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_postman_react_click_outside__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(37);
/* harmony import */ var _js_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2371);
/* harmony import */ var _services_CommentsService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6985);
/* harmony import */ var _js_components_comments_CommentContainer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5041);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1601);
/* harmony import */ var _js_utils_util__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1628);
/* harmony import */ var _appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2862);
/* harmony import */ var _js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2322);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2325);
/* harmony import */ var _js_components_base_Text__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2863);
var _class;function _extends() {_extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};return _extends.apply(this, arguments);}
















/**
 * Empty State
 * @param {Object} props
 */
function EmptyState(props) {
  return /*#__PURE__*/(
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "pull-request-container__empty-state" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "sidebar-empty-state__icon-container" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["Icon"], { className: "sidebar-empty-state__icon", size: "large", color: "content-color-tertiary", name: props.icon })), /*#__PURE__*/

    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "sidebar-empty-state__title" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h4", null, props.title)), /*#__PURE__*/

    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "sidebar-empty-state__body" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Text__WEBPACK_IMPORTED_MODULE_14__["default"], { type: "body-medium", value: props.message }))));



}let



PullRequestComments = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_4___default()(_class = class PullRequestComments extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
    this.state = {
      input: '',
      open: props.open,
      creating: false,
      updating: [],
      deleting: [],
      loadError: null,
      deleteError: null,
      updateError: null,
      creatorDetails: null,
      loading: this.props.loadingComments,
      comments: {},
      hasError: false,
      showEntityComments: false,
      showPullRequestComments: _.get(this.props, 'contextData.showComments'),
      modelId: _.get(this.props, 'contextData.modelId') || this.props.modelId,
      model: _.get(this.props, 'contextData.model') || this.props.model,
      anchor: this.props.anchor };


    this.handleFocus = this.handleFocus.bind(this);
    this.handleFetch = this.handleFetch.bind(this);
    this.handleUpdate = this.handleUpdate.bind(this);
    this.handleCreate = this.handleCreate.bind(this);
    this.handleRetry = this.handleRetry.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
    this.setListRef = this.setListRef.bind(this);
    this.parseError = this.parseError.bind(this);
    this.parseTags = this.parseTags.bind(this);
    this.isOnline = this.isOnline.bind(this);
    this.initiate = this.initiate.bind(this);
    this.handleClickOutside = this.handleClickOutside.bind(this);
    this.handleHideComments = this.handleHideComments.bind(this);
    this.toggleEntityComments = this.toggleEntityComments.bind(this);
    this.processComments = this.processComments.bind(this);
  }

  componentDidMount() {
    this.props.entityComments ? this.processComments(this.props.comments) : this.initiate();
  }

  initiate() {
    this.fetchCommentDisposer = Object(mobx__WEBPACK_IMPORTED_MODULE_3__["reaction"])(() => Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('SyncStatusStore').isSocketConnected, (isSocketConnected) => {
      if (isSocketConnected) {
        this.handleFetch();
      }
    }, { fireImmediately: true });
  }

  componentWillUnmount() {
    this.fetchCommentDisposer && this.fetchCommentDisposer();
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (!this.props.loading && nextProps.loading || this.props.loading && !nextProps.loading) {
      this.setState({ loading: nextProps.loading });
    }

    if ((_.get(this.props, 'comments.comments') || []).length > 0) {
      this.processComments(this.props.comments);
    }
  }

  handleClickOutside() {
    // close comments when clicked outside
    this.handleHideComments();
  }

  toggleEntityComments() {
    this.setState((prevState) => ({ showEntityComments: !prevState.showEntityComments }));
  }

  handleHideComments() {
    this.state.showEntityComments && this.setState({ showEntityComments: false });
  }

  scrollToEnd() {
    if (!this.listRef) {
      return;
    }
    const maxScrollTop = this.listRef.scrollHeight - this.listRef.clientHeight;
    this.listRef.scrollTop = maxScrollTop > 0 ? maxScrollTop : 0;
  }

  handleFocus() {
    this.props.focusRightOverlay && this.props.focusRightOverlay();
  }

  /**
   * Parse comment tags data
   */
  parseTags(data, users) {
    if (!data) {
      return null;
    }

    return Object.keys(data).reduce((res, tag) => {
      res[tag] = _extends({},
      data[tag] || {}, {
        id: `${_.get(data, [tag, 'id'])}`,
        userDetails: _.get(users, _.get(data, [tag, 'id'])) });


      return res;
    }, {});
  }

  parseError(e) {
    if (!e) {
      return '';
    }

    return e.message;
  }

  isOnline() {
    return Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('SyncStatusStore').isSocketConnected;
  }

  setListRef(node) {
    this.listRef = node;
  }

  handleUpdate(data) {
    if (!this.isOnline()) {
      pm.toasts.error('您需要在线才能更新评论.');
      return;
    }

    this.setState((prevState) => ({ updating: _.union(prevState.updating, [data.id]) }));

    return _services_CommentsService__WEBPACK_IMPORTED_MODULE_7__["default"].updateComment(
    data.id,
    data.body,
    data.tags).
    then((response) => {
      this.setState((prevState) => ({
        hasError: false,
        updating: _.remove(prevState.updating, data.id),
        comments: _extends({},
        this.state.comments || {}, {
          [_.get(response, 'comment.id')]: _extends({},
          this.state.comments[_.get(response, 'comment.id')], {
            body: _.get(response, 'comment.body'),
            tags: this.parseTags(_.get(response, 'comment.tags')),
            updatedAt: _.get(response, 'comment.updatedAt') }) }) }));




      this.handleFocus();
    }).catch((e) => {
      pm.toasts.error(this.parseError(e) || '更新评论时发生错误.', { title: '无法保存评论' });
      this.setState((prevState) => ({
        hasError: true,
        updating: _.remove(prevState.updating, data.id),
        updatingError: this.parseError(e) }));


      this.handleFocus();
    });
  }

  handleCreate(data, tags) {
    if (!this.isOnline()) {
      pm.toasts.error('您需要联网才能评论.');
      return;
    }

    this.setState({ creating: true });

    _services_CommentsService__WEBPACK_IMPORTED_MODULE_7__["default"].createComment(
    this.state.model,
    this.state.modelId,
    data,
    tags,
    this.state.anchor || _.get(this.props, 'contextData.anchor')).
    then((response) => {
      this.setState({
        hasError: false,
        creating: false,
        comments: _extends({},
        this.state.comments || {}, {
          [_.get(response, 'comment.id')]: {
            body: _.get(response, 'comment.body'),
            tags: this.parseTags(_.get(response, 'comment.tags')),
            id: _.get(response, 'comment.id'),
            updatedAt: _.get(response, 'comment.updatedAt'),
            createdAt: _.get(response, 'comment.createdAt'),
            createdBy: _.get(response, 'comment.createdBy'),
            creatorDetails: {
              friendly: Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('CurrentUserStore').name || Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('CurrentUserStore').username || Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('CurrentUserStore').email,
              id: Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('CurrentUserStore').id,
              profilePicUrl: Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('CurrentUserStore').profile_pic_url } } }) },



      this.scrollToEnd);
    }).catch((e) => {
      this.setState({
        creating: false,
        hasError: true });

      pm.toasts.error(this.parseError(e) || '创建评论时发生错误.', { title: '无法保存评论' });
    });
  }

  handleDelete(commentId) {
    if (!this.isOnline()) {
      pm.toasts.error('您需要在线才能删除评论.');
      return;
    }

    this.setState((prevState) => ({ deleting: _.union(prevState.deleting, [commentId]) }));

    return _services_CommentsService__WEBPACK_IMPORTED_MODULE_7__["default"].deleteComment(commentId).
    then(() => {
      this.setState((prevState) => ({
        deleting: _.remove(prevState.deleting, commentId),
        comments: _.omit(this.state.comments, [commentId]) }));


      this.handleFocus();
    }).catch((e) => {
      this.setState((prevState) => ({
        deleting: _.remove(prevState.deleting, commentId),
        deletingError: this.parseError(e) }));

      pm.toasts.error(this.parseError(e) || '删除评论时发生错误.');

      this.handleFocus();
    });
  }

  processComments(body, postProcessState) {
    const filteredComments = (body.comments || []).filter((e) => e.anchor === this.state.anchor || _.get(this.props, 'contextData.anchor'));

    this.setState(_extends({
      comments: filteredComments && filteredComments.reduce((result, comment) => {
        if (body.createdBy && body.createdBy[comment.createdBy]) {
          result[comment.id] = Object.assign(comment, {
            tags: this.parseTags(comment.tags, body.users),
            creatorDetails: _extends({},
            body.createdBy[comment.createdBy], {
              friendly: body.createdBy[comment.createdBy].friendly || body.createdBy[comment.createdBy].username || body.createdBy[comment.createdBy].email,
              id: `${body.createdBy[comment.createdBy].id}`,
              profilePicUrl: body.createdBy[comment.createdBy].profilePicUrl }) });


        }

        return result;
      }, {}),
      updating: filteredComments,
      deleting: filteredComments },
    postProcessState),
    this.scrollToEnd);

    this.handleFocus();
  }

  handleFetch() {
    const { showEntityComments: currShowEntityCommentsState } = this.state;

    this.setState({
      loading: true,
      loadError: null,
      showEntityComments: false });


    _services_CommentsService__WEBPACK_IMPORTED_MODULE_7__["default"].getComments(this.state.model, this.state.modelId, this.state.anchor || _.get(this.props, 'contextData.anchor')).
    then((body) => {
      this.processComments(body, { loading: false, showEntityComments: currShowEntityCommentsState });
    }).catch((e) => {
      this.setState({
        loading: false,
        loadError: this.parseError(e),
        showEntityComments: currShowEntityCommentsState });

      this.handleFocus();
    });
  }

  handleRetry() {
    !Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('SyncStatusStore').isSocketConnected ?
    pm.toasts.error('重新在线后即可执行此操作', {
      title: '你离线了' }) :

    this.handleFetch();
  }

  render() {
    const currentUserStore = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('CurrentUserStore'),
    teamUserStore = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('TeamUserStore'),
    currentUser = {
      name: currentUserStore.name,
      isLoggedIn: currentUserStore.isLoggedIn,
      userName: currentUserStore.username_email,
      id: currentUserStore.id,
      organizations: currentUserStore.organizations,
      teamSyncEnabled: currentUserStore.teamSyncEnabled,
      profilePicUrl: currentUserStore.profile_pic_url },

    teamUsers = teamUserStore.values || [],
    isAdmin = _js_utils_util__WEBPACK_IMPORTED_MODULE_10__["default"].isUserAdmin(currentUser),
    isOffline = !Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('SyncStatusStore').isSocketConnected,
    teamUsersMap = _.reduce(teamUserStore.values, (res, user) => {
      res[user.id] = {
        name: user.name,
        id: user.id,
        username: user.username,
        email: user.email,
        profilePicUrl: user.profilePicUrl };


      return res;
    }, {});

    if (this.state.showPullRequestComments && isOffline) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: _.get(this.props, 'contextData.className') || this.props.className }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_11__["ContextBarViewHeader"], {
          title: this.props.title,
          onClose: this.props.onClose }), /*#__PURE__*/

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(EmptyState, {
          icon: "icon-state-offline-stroke",
          title: "检查您的连接",
          message: "在线以查看评论" })));



    }

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: _.get(this.props, 'contextData.className') || this.props.className },
      _.get(this.props, 'contextData.type') === 'pullRequest' ? /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_11__["ContextBarViewHeader"], {
        title: this.props.title,
        onClose: this.props.onClose }) : /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "pull-request-entity-comments__label",
        onClick: this.toggleEntityComments }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["Icon"], {
        name: "icon-action-comments-stroke",
        color: "content-color-secondary",
        className: "pull-request-entity-comments__icon" }),

      this.state.loading ? /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_12__["default"], { className: "pull-request-entity-comments__loading" }) : /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_13__["Button"], {
        className: "pull-request-entity-comments__count",
        size: "small" },

      Object.keys(this.state.comments || {}).length)),




      (this.state.showEntityComments || this.state.showPullRequestComments) && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_comments_CommentContainer__WEBPACK_IMPORTED_MODULE_8__["Comments"], _extends({
        addCommentPermission: true },
      _.pick(this.state, ['updating', 'creating', 'deleting', 'loadError', 'deleteError', 'updateError']), {
        className: _.get(this.props, 'contextData.className') || this.props.commentClassName,
        data: _.sortBy(this.state.comments || [], 'createdAt'),
        isAdmin: isAdmin,
        isOffline: isOffline,
        loading: this.state.loading,
        setListRef: this.setListRef,
        teamUsers: teamUsers,
        teamUsersMap: teamUsersMap,
        user: currentUser,
        onClose: this.props.onClose || this.handleHideComments,
        onCommentCreate: this.handleCreate,
        onCommentDelete: this.handleDelete,
        onCommentUpdate: this.handleUpdate,
        onRetry: this.handleRetry,
        onUserClick: (id) => {Object(_js_models_services_DashboardService__WEBPACK_IMPORTED_MODULE_6__["openTeamUserProfile"])(id);},
        hasError: this.state.hasError }))));




  }}) || _class) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ })

}]);