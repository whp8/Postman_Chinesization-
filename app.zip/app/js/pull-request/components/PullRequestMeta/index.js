(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[41],{

/***/ 9733:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return PullRequestMeta; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(515);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(37);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9);
/* harmony import */ var _infoComponents__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9734);
/* harmony import */ var _appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2862);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2166);









const prStatusMap = {
  merged: '已合并',
  declined: '已拒绝' };


const PRMetaRoot = styled_components__WEBPACK_IMPORTED_MODULE_2__["default"].div`
  /** increasing specificity */
  .pull-request-meta__header.pull-request-meta__header {
    padding-bottom: ${({ theme }) => theme['spacing-l']};
  }
`;

class PullRequestMeta extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);
  }

  get isActivePR() {
    return [_constants__WEBPACK_IMPORTED_MODULE_6__["PR_STATES"].OPEN, _constants__WEBPACK_IMPORTED_MODULE_6__["PR_STATES"].APPROVED].includes(
    lodash__WEBPACK_IMPORTED_MODULE_1___default.a.get(this.props.contextData, 'pullRequest.status'));

  }

  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(PRMetaRoot, null, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_5__["ContextBarViewHeader"], {
        title: "拉取请求详情",
        onClose: this.props.onClose,
        className: "pull-request-meta__header" }), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "pull-request-meta" },

      !this.isActivePR && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_infoComponents__WEBPACK_IMPORTED_MODULE_4__["Info"], {
        title: `${
        prStatusMap[lodash__WEBPACK_IMPORTED_MODULE_1___default.a.get(this.props.contextData, 'pullRequest.status')]
        }由` }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_infoComponents__WEBPACK_IMPORTED_MODULE_4__["User"], {
        user: lodash__WEBPACK_IMPORTED_MODULE_1___default.a.get(this.props.contextData, 'pullRequest.updatedBy') })), /*#__PURE__*/




      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_infoComponents__WEBPACK_IMPORTED_MODULE_4__["Info"], { title: "创建者" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_infoComponents__WEBPACK_IMPORTED_MODULE_4__["User"], {
        user: lodash__WEBPACK_IMPORTED_MODULE_1___default.a.get(this.props.contextData, 'pullRequest.createdBy') })), /*#__PURE__*/



      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_infoComponents__WEBPACK_IMPORTED_MODULE_4__["Info"], { title: "创建于" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_infoComponents__WEBPACK_IMPORTED_MODULE_4__["Date"], {
        date: lodash__WEBPACK_IMPORTED_MODULE_1___default.a.get(this.props.contextData, 'pullRequest.createdAt'),
        format: "DD MMM YYYY" })),



      this.isActivePR && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_infoComponents__WEBPACK_IMPORTED_MODULE_4__["Info"], { title: "最后更新" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_infoComponents__WEBPACK_IMPORTED_MODULE_4__["Date"], {
        date: lodash__WEBPACK_IMPORTED_MODULE_1___default.a.get(this.props.contextData, 'pullRequest.updatedAt'),
        relative: true })), /*#__PURE__*/




      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_infoComponents__WEBPACK_IMPORTED_MODULE_4__["Info"], { title: "评审员" },
      lodash__WEBPACK_IMPORTED_MODULE_1___default.a.get(this.props.contextData, 'pullRequest.reviewers.length', 0) ? /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("ul", { className: "pull-request-reviewers-list" },
      lodash__WEBPACK_IMPORTED_MODULE_1___default()(this.props.contextData).get('pullRequest.reviewers', []).map(
      (reviewer) => /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_infoComponents__WEBPACK_IMPORTED_MODULE_4__["User"], {
        key: reviewer.id,
        user: reviewer,
        renderRight: () => {
          return (
            reviewer.status === _constants__WEBPACK_IMPORTED_MODULE_6__["PR_STATES"].APPROVED && /*#__PURE__*/
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_3__["Badge"], { text: "已批准", status: "success" }));

        } }))) : /*#__PURE__*/





      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_3__["Text"], { type: "body-medium", color: "content-color-primary" }, "没有评审员")))));








  }}

/***/ }),

/***/ 9734:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Info", function() { return Info; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Date", function() { return Date; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "User", function() { return User; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9);
/* harmony import */ var moment_timezone__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2278);
/* harmony import */ var moment_timezone__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment_timezone__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(37);
/* harmony import */ var _js_components_base_Avatar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4190);
/* harmony import */ var _common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6930);








const InfoRoot = styled_components__WEBPACK_IMPORTED_MODULE_3__["default"].div`
  & + & {
    margin-top: ${({ theme }) => theme['spacing-xl']};
  }

  .pr-meta-info__title {
    margin-bottom: ${({ theme }) => theme['spacing-s']};
  }

  .pr-meta-info__content {
    display: flex;
  }
`;

/**
 * Renders one meta information of the pull request.
 * @param {*} props
 * @param {string} props.title
 * @param {React.ReactChild} props.children
 */
function Info(props) {
  const { title, children } = props;

  return /*#__PURE__*/(
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(InfoRoot, null, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["Heading"], {
      type: "h6",
      text: title,
      color: "content-color-secondary",
      className: "pr-meta-info__title" }), /*#__PURE__*/

    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["Flex"], null, children)));


}

/**
 * Renders a date with the specified format or format function from moment.
 * @param {*} props
 * @param {string} props.date
 * @param {string} props.format
 */
function Date(props) {
  const { date, format, relative } = props;
  let formattedDate;

  if (relative) {
    formattedDate = moment_timezone__WEBPACK_IMPORTED_MODULE_2___default()(date).fromNow();
  } else
  if (format) {
    formattedDate = moment_timezone__WEBPACK_IMPORTED_MODULE_2___default()(date).format(format);
  }

  return /*#__PURE__*/(
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_1__["Text"], { type: "body-medium", color: "content-color-primary" },
    formattedDate));


}

const UserRoot = styled_components__WEBPACK_IMPORTED_MODULE_3__["default"].li`
  display: flex;
  width: 100%;

  .space-filler {
    flex: auto;
  }
`;

/**
 * Renders a user list Item
 * @param {*} props
 * @returns
 */
function User(props) {
  const { user, renderRight } = props;

  return /*#__PURE__*/(
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(UserRoot, null, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Avatar__WEBPACK_IMPORTED_MODULE_4__["default"], { size: "medium", userId: user.id, customPic: user.profilePicUrl }), /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common__WEBPACK_IMPORTED_MODULE_5__["Username"], {
      className: "pull-request-user__name",
      currentUserId: user.id,
      id: user.id,
      user: user }), /*#__PURE__*/

    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", { className: "space-filler" }),
    renderRight && renderRight()));


}

/***/ })

}]);