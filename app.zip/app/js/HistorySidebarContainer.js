(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[36],{

/***/ 9712:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HistorySidebarContainer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2327);
/* harmony import */ var _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_postman_react_click_outside__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2293);
/* harmony import */ var _postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1601);
/* harmony import */ var _postman_app_monolith_renderer_js_modules_model_event__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1600);
/* harmony import */ var _postman_app_monolith_renderer_js_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1846);
/* harmony import */ var _runtime_repl_history_HistorySidebar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9713);
/* harmony import */ var _runtime_repl_history_HistoryService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2270);
/* harmony import */ var _runtime_repl_history_api_HistoryInterface__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2261);
/* harmony import */ var _postman_app_monolith_renderer_js_containers_new_button_CreateNewXService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8060);
/* harmony import */ var _runtime_repl_request_websocket_base_api_WebSocketRequestInterface__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5122);
/* harmony import */ var _runner_api_RunnerInterface__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2376);
/* harmony import */ var _common_ToastHelpers__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2353);
/* harmony import */ var _common_WorkspaceHelpers__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2287);
/* harmony import */ var _HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9714);
/* harmony import */ var _common_components_molecule__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(4068);
/* harmony import */ var _runner_RunnerHelper__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4514);
var _class;


















let



HistorySidebarContainer = _postman_react_click_outside__WEBPACK_IMPORTED_MODULE_1___default()(_class = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class HistorySidebarContainer extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.store = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('HistorySidebarStore');

    this.focus = this.focus.bind(this);
    this.handleLoadRequestDebounced = _.debounce(this.handleLoadRequest, 100, { leading: true }).bind(this);
    this.handleLoadCollectionRunDebounced = _.debounce(this.handleLoadCollectionRun, 100, { leading: true }).bind(this);
    this.handleLoadWebSocketHistoryDebounced = _.debounce(this.handleLoadWebSocketHistory, 100,
    { leading: true }).bind(this);
    this.handleActiveRequestChange = this.handleActiveRequestChange.bind(this);
    this.handleAddToCollection = this.handleAddToCollection.bind(this);
    this.handleDeleteMultiple = this.handleDeleteMultiple.bind(this);
    this.handleItemSelect = this.handleItemSelect.bind(this);
    this.handleSelectAction = this.handleSelectAction.bind(this);
    this.handleSelectHistoryAction = this.handleSelectHistoryAction.bind(this);
    this.handleSelectCollectionRunAction = this.handleSelectCollectionRunAction.bind(this);
    this.handleSelectWebSocketHistoryAction = this.handleSelectWebSocketHistoryAction.bind(this);
  }

  UNSAFE_componentWillMount() {
    pm.mediator.on('activeRequestChanged', this.handleActiveRequestChange);
  }

  componentWillUnmount() {
    pm.mediator.off('activeRequestChanged', this.handleActiveRequestChange);
  }

  focus() {
    _.invoke(this, 'refs.history.focus');
  }

  selectNext() {
    _.invoke(this, 'refs.history.selectNext');
  }

  handleActiveRequestChange(requestId) {
    if (!this.store.itemExists(requestId)) {
      this.store.resetSelection();

      return;
    }

    this.store.resetSelection([requestId]);
  }

  handleClickOutside(e) {
    if (!_.isEmpty(this.store.getSelectedItems())) {
      const modalElm = document.getElementsByClassName('ReactModal__Content')[0],
      visibleDropdownElm = document.querySelector('.history-sidebar-multiple-request-selected-dropdown');

      // Exclude both delete modal & more actions dropdown from the reset selection condition.
      if (modalElm && modalElm.contains(e.target) || visibleDropdownElm && visibleDropdownElm.contains(e.target)) {
        return;
      }

      this.store.resetSelection();
    }
  }

  handleLoadRequest(id, newTab = false) {
    if (!id) {
      return;
    }

    _runtime_repl_history_HistoryService__WEBPACK_IMPORTED_MODULE_7__["default"].openHistoryInTab(id, {
      newTab,
      preview: true });

  }

  handleLoadCollectionRun(id, newTab = false) {
    if (!id) {
      return;
    }

    const { uid } = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('RunnerRunStore').find(id) || {};

    Object(_runner_api_RunnerInterface__WEBPACK_IMPORTED_MODULE_11__["openRunInTab"])(uid, { newTab, preview: !newTab });
  }

  handleLoadWebSocketHistory(id, forceNew = false) {
    if (!id) {
      return;
    }

    Object(_runtime_repl_request_websocket_base_api_WebSocketRequestInterface__WEBPACK_IMPORTED_MODULE_10__["openWebSocketHistoryTab"])(id, { forceNew, preview: !forceNew });
  }

  handleItemSelect({ id, type }, modifiers = {}) {
    const isOsxPlatform = _.includes(navigator.platform, 'Mac');

    if (modifiers.shiftKey && (isOsxPlatform ? modifiers.metaKey : modifiers.ctrlKey)) {
      if (type === 'collectionrun') {
        this.handleLoadCollectionRunDebounced(id, true);
      } else if (type === 'websockethistory') {
        this.handleLoadWebSocketHistoryDebounced(id, true);
      } else {
        this.handleLoadRequestDebounced(id, true);
      }

      pm.mediator.trigger('focusSidebar');
    } else if (modifiers.ctrlKey || modifiers.metaKey) {// Select multiple requests
      if (this.store.isItemSelected(id)) {
        this.store.unselectItem(id);
      } else {
        this.store.selectItem(id);
      }
    } else {
      if (type === 'collectionrun') {
        this.handleLoadCollectionRunDebounced(id, false);
      } else if (type === 'websockethistory') {
        this.handleLoadWebSocketHistoryDebounced(id, false);
      } else {
        this.handleLoadRequestDebounced(id, false);
      }

      pm.mediator.trigger('focusSidebar');

      this.store.resetSelection([id]);
    }
  }

  handleAddToCollection(options = {}) {
    const { requests } = options,

    selectedItems = _.isEmpty(requests) ? this.store.getSelectedItems() : requests;

    if (_.isEmpty(selectedItems)) {
      return;
    }

    Object(_runtime_repl_history_api_HistoryInterface__WEBPACK_IMPORTED_MODULE_8__["convertHistoryToRequests"])(selectedItems, { populateIfPartial: true }).
    then((requests) => {
      if (_.size(requests) === 1) {
        requests[0] && pm.mediator.trigger('showAddToCollectionModal', requests[0], { from: options.from });
      } else {
        pm.mediator.trigger('addRequestsToCollection', requests, options);
      }
    });
  }

  handleToggleHistoryResponseSaving() {
    if (!Object(_common_WorkspaceHelpers__WEBPACK_IMPORTED_MODULE_13__["isWorkspaceMember"])()) {
      if (Object(_common_WorkspaceHelpers__WEBPACK_IMPORTED_MODULE_13__["canJoinWorkspace"])()) {
        return pm.mediator.trigger('openUnjoinedWorkspaceModal');
      }

      if (!Object(_common_WorkspaceHelpers__WEBPACK_IMPORTED_MODULE_13__["isLoggedIn"])()) {
        return pm.mediator.trigger('showSignInModal', {
          type: 'history',
          origin: 'history_save_response' });

      }

      return pm.toasts.error('您没有执行该操作所需的权限.');
    }

    const workspaceSettings = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('ActiveWorkspaceStore').settings,
    enableHistoryResponseSaving = workspaceSettings && workspaceSettings.enableHistoryResponseSaving,

    // Compute the new value after toggle
    newSettings = { enableHistoryResponseSaving: !enableHistoryResponseSaving };

    return Object(_postman_app_monolith_renderer_js_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_5__["default"])(Object(_postman_app_monolith_renderer_js_modules_model_event__WEBPACK_IMPORTED_MODULE_4__["createEvent"])('updateSettings', 'workspace', { id: Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('ActiveWorkspaceStore').id, settings: newSettings })).
    catch((e) => {
      const errorMessage = e.isFriendly ? e.message : '无法更新工作区设置';

      pm.toasts.error(errorMessage, { dedupeId: 'ws-settings-error' });
    });
  }

  resetHistorySelection(nextSelection) {
    if (nextSelection && nextSelection.id) {
      this.store.resetSelection([nextSelection.id]);
    } else {
      this.store.resetSelection();
    }
  }

  handleDeleteMultiple(ref, nextSelection) {
    const permissionStore = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('PermissionStore'),
    runStore = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('RunnerRunStore');

    if (!Object(_common_WorkspaceHelpers__WEBPACK_IMPORTED_MODULE_13__["isWorkspaceMember"])()) {
      if (Object(_common_WorkspaceHelpers__WEBPACK_IMPORTED_MODULE_13__["canJoinWorkspace"])()) {
        return pm.mediator.trigger('openUnjoinedWorkspaceModal');
      }

      if (!Object(_common_WorkspaceHelpers__WEBPACK_IMPORTED_MODULE_13__["isLoggedIn"])()) {
        return pm.mediator.trigger('showSignInModal', {
          type: 'history',
          origin: 'history_delete_multiple' });

      }

      return pm.toasts.error('您没有执行该操作所需的权限.');
    }

    if (!Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('OnlineStatusStore').userCanSave) {
      return Object(_common_ToastHelpers__WEBPACK_IMPORTED_MODULE_12__["showOfflineActionDisabledToast"])();
    }

    return Promise.resolve().
    then(() => {
      if (ref === 'all') {
        Object(_postman_app_monolith_renderer_js_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_5__["default"])(Object(_postman_app_monolith_renderer_js_modules_model_event__WEBPACK_IMPORTED_MODULE_4__["createEvent"])('deleteAllInWorkspace', 'history', Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('ActiveWorkspaceStore').id));
        runStore.deleteRun(_.map(runStore.values, (run) => run.id));

        Object(_runtime_repl_request_websocket_base_api_WebSocketRequestInterface__WEBPACK_IMPORTED_MODULE_10__["deleteWebSocketHistory"])();
      } else if (ref === 'selected') {
        if (permissionStore.can('delete', 'history')) {
          Object(_postman_app_monolith_renderer_js_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_5__["default"])(Object(_postman_app_monolith_renderer_js_modules_model_event__WEBPACK_IMPORTED_MODULE_4__["createEvent"])('deleteMultiple', 'history', { ids: this.store.getSelectedItems() }, null, null));
        } else {
          pm.toasts.error('您没有权限删除历史.');
        }

        if (permissionStore.can('delete', 'collectionrun')) {
          Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('RunnerRunStore').deleteRun(this.store.getSelectedItems());
        } else {
          pm.toasts.error('您没有权限删除集合运行.');
        }

        Object(_runtime_repl_request_websocket_base_api_WebSocketRequestInterface__WEBPACK_IMPORTED_MODULE_10__["deleteWebSocketHistory"])(this.store.getSelectedItems());
      }
    }).

    then(() => {
      this.resetHistorySelection(nextSelection);
    }).

    catch(() => {
      this.resetHistorySelection(nextSelection);
    });
  }

  handleAddRequestToService(options, event) {
    const {
      requests,
      defaultCollectionName = '',
      from = '' } =
    options,

    selectedItems = _.isEmpty(requests) ? this.store.getSelectedItems() : requests;

    if (_.isEmpty(selectedItems)) {
      return;
    }

    Object(_runtime_repl_history_api_HistoryInterface__WEBPACK_IMPORTED_MODULE_8__["convertHistoryToRequests"])(selectedItems).
    then((requests) => {
      if (!_.isEmpty(requests)) {
        const opts = {
          name: defaultCollectionName,
          from };


        _postman_app_monolith_renderer_js_containers_new_button_CreateNewXService__WEBPACK_IMPORTED_MODULE_9__["default"].create(event, { requests, opts }, null, { from: 'history_sidebar' });
      }
    });
  }

  handleSelectHistoryAction(action, options) {
    switch (action) {
      case _HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_SAVE"]:
        if (!Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('OnlineStatusStore').userCanSave) {
          return Object(_common_ToastHelpers__WEBPACK_IMPORTED_MODULE_12__["showOfflineActionDisabledToast"])();
        }

        this.handleAddToCollection(options);
        break;

      case _HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_MONITOR"]:
        this.handleAddRequestToService(options, 'openCreateNewMonitorModal');
        break;

      case _HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_DOCUMENT"]:
        this.handleAddRequestToService(options, 'openCreateNewDocumentationModal');
        break;

      case _HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_MOCK"]:
        this.handleAddRequestToService(options, 'openCreateNewMockModal');
        break;

      case _HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_DELETE"]:
        if (!Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('OnlineStatusStore').userCanSave) {
          return Object(_common_ToastHelpers__WEBPACK_IMPORTED_MODULE_12__["showOfflineActionDisabledToast"])();
        }

        Object(_postman_app_monolith_renderer_js_modules_pipelines_user_action__WEBPACK_IMPORTED_MODULE_5__["default"])(Object(_postman_app_monolith_renderer_js_modules_model_event__WEBPACK_IMPORTED_MODULE_4__["createEvent"])('deleteMultiple', 'history', { ids: options.requests }, null, null));
        break;

      default:}

  }

  handleSelectCollectionRunAction(action, options) {
    switch (action) {
      case _HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_DELETE"]:
        if (!Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('OnlineStatusStore').userCanSave) {
          return Object(_common_ToastHelpers__WEBPACK_IMPORTED_MODULE_12__["showOfflineActionDisabledToast"])();
        }

        Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('RunnerRunStore').deleteRun(options.runs);
        break;

      case _HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_DOWNLOAD"]:
        return Object(_runner_RunnerHelper__WEBPACK_IMPORTED_MODULE_16__["exportRuns"])(options.runs);

      default:
        pm.logger.warn(`HistorySidebarContainer~handleSelectCollectionRunAction: ${action} - action not handled`);}

  }

  handleSelectWebSocketHistoryAction(action, options) {
    switch (action) {
      case _HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_DELETE"]:
        if (!Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('OnlineStatusStore').userCanSave) {
          return Object(_common_ToastHelpers__WEBPACK_IMPORTED_MODULE_12__["showOfflineActionDisabledToast"])();
        }

        Object(_runtime_repl_request_websocket_base_api_WebSocketRequestInterface__WEBPACK_IMPORTED_MODULE_10__["deleteWebSocketHistory"])(options.websockethistory);
        break;

      default:}

  }


  handleSelectAction(entityType, action, options) {
    if (!Object(_common_WorkspaceHelpers__WEBPACK_IMPORTED_MODULE_13__["isWorkspaceMember"])()) {
      if (Object(_common_WorkspaceHelpers__WEBPACK_IMPORTED_MODULE_13__["canJoinWorkspace"])()) {
        return pm.mediator.trigger('openUnjoinedWorkspaceModal');
      }

      if (!Object(_common_WorkspaceHelpers__WEBPACK_IMPORTED_MODULE_13__["isLoggedIn"])()) {
        return pm.mediator.trigger('showSignInModal', {
          type: 'history',
          origin: `history_${action}` });

      }

      return pm.toasts.error('您没有执行该操作所需的权限.');
    }

    if (entityType === 'collectionrun') {
      if (_.size(options.runs) === 1 && action === _HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_DELETE"]) {
        this.store.unselectItem(options.runs[0]);
      }

      return options.runs && this.handleSelectCollectionRunAction(action, options);
    }

    if (entityType === 'websockethistory') {
      if (_.size(options.websockethistory) === 1 && action === _HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_DELETE"]) {
        this.store.unselectItem(options.websockethistory[0]);
      }

      return options.websockethistory && this.handleSelectWebSocketHistoryAction(action, options);
    }

    if (entityType === 'request') {
      if (_.size(options.requests) === 1 && action === _HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_14__["ACTION_TYPE_DELETE"]) {
        this.store.unselectItem(options.requests[0]);
      }

      return this.handleSelectHistoryAction(action, options);
    }

    if (entityType === 'all') {
      options.runs && this.handleSelectCollectionRunAction(action, options);
      options.requests && this.handleSelectHistoryAction(action, options);
      options.websockethistory && this.handleSelectWebSocketHistoryAction(action, options);
    }
  }

  render() {
    // The API isConsistentlyOffline is only supposed to be used to show the offline state view to the user when he has
    // been consistently offline.
    // For disabling the actions on lack of connectivity, please rely on the socket connected state itself for now.
    // Otherwise, there is a chance of data loss if we let the user perform actions when we are attempting a connection.
    const { isConsistentlyOffline } = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('SyncStatusStore');

    if (!pm.isScratchpad && isConsistentlyOffline && this.store.loading) {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_common_components_molecule__WEBPACK_IMPORTED_MODULE_15__["SidebarOfflineState"], null);
    }

    const workspaceSettings = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('ActiveWorkspaceStore').settings,
    syncStatusStore = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('SyncStatusStore'),
    currentUserStore = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('CurrentUserStore'),
    historyStore = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('HistoryStore'),
    workspaceStore = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_3__["getStore"])('ActiveWorkspaceStore'),
    enableHistoryResponseSaving = workspaceSettings && workspaceSettings.enableHistoryResponseSaving;

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_runtime_repl_history_HistorySidebar__WEBPACK_IMPORTED_MODULE_6__["default"], {
        store: this.store,
        enableHistoryResponseSaving: enableHistoryResponseSaving,
        initializing: currentUserStore.isHydrating || historyStore.isHydrating || !workspaceStore.id,
        isLoggedIn: currentUserStore.isLoggedIn,
        isSocketConnected: syncStatusStore.isSocketConnected,
        workspace: workspaceStore.id,
        onSelectAction: this.handleSelectAction,
        onDeleteMultiple: this.handleDeleteMultiple,
        onSelect: this.handleItemSelect,
        onSaveCurrentRequest: this.handleAddToCollection,
        onToggleHistoryResponseSaving: this.handleToggleHistoryResponseSaving,
        ref: "history" }));


  }}) || _class) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 9713:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HistorySidebar; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var pure_render_decorator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2846);
/* harmony import */ var pure_render_decorator__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(pure_render_decorator__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2314);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2856);
/* harmony import */ var _runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9714);
/* harmony import */ var _postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1601);
/* harmony import */ var _HistorySidebarMenu__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9715);
/* harmony import */ var _HistorySidebarList__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9718);
var _class;







let


HistorySidebar = pure_render_decorator__WEBPACK_IMPORTED_MODULE_2___default()(_class = class HistorySidebar extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.store = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('HistorySidebarStore');
    this.historyStore = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('HistoryStore');

    this.focus = this.focus.bind(this);
    this.groupItems = this.groupItems.bind(this);
    this.selectNext = this.selectNext.bind(this);
    this.selectPrev = this.selectPrev.bind(this);
    this.deleteItem = this.deleteItem.bind(this);
    this.selectItem = this.selectItem.bind(this);
    this.multiselectNextItem = this.multiselectNextItem.bind(this);
    this.multiselectPrevItem = this.multiselectPrevItem.bind(this);
  }

  getKeyMapHandlers() {
    return {
      groupItems: pm.shortcuts.handle('groupItems', this.groupItems),
      nextItem: pm.shortcuts.handle('nextItem', this.selectNext),
      prevItem: pm.shortcuts.handle('prevItem', this.selectPrev),
      delete: pm.shortcuts.handle('delete', this.deleteItem),
      multiselectNextItem: pm.shortcuts.handle('multiselectNextItem', this.multiselectNextItem),
      multiselectPrevItem: pm.shortcuts.handle('multiselectPrevtItem', this.multiselectPrevItem),
      select: pm.shortcuts.handle('select', this.selectItem),
      search: pm.shortcuts.handle('search'),
      saveCurrentRequest: (e) => {
        e && e.stopPropagation();
        this.props.onSaveCurrentRequest();
      } };

  }

  focus() {
    const $history = Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["findDOMNode"])(this.refs.history);

    $history && $history.focus();
  }

  selectNext(e) {
    e && e.preventDefault();
    const item = this.store.getNextItem();

    item && _.invoke(this, 'props.onSelect', item);
  }

  selectPrev(e) {
    e && e.preventDefault();
    const item = this.store.getPrevItem();

    item && _.invoke(this, 'props.onSelect', item);
  }

  deleteItem(e) {
    if (document.activeElement.classList.contains('history-sidebar__filter')) {
      return;
    }

    e && e.preventDefault();
    const item = this.store.getPrevItem();

    _.invoke(this, 'props.onDeleteMultiple', 'selected', item);
  }

  selectItem(e) {
    e && e.preventDefault();
    _.invoke(this, 'refs.list.selectItem');
  }

  multiselectNextItem(e) {
    e && e.preventDefault();
    const item = this.store.getNextItem();

    item && _.invoke(this, 'props.onSelect', item, { metaKey: true });
  }

  multiselectPrevItem(e) {
    e && e.preventDefault();
    const item = this.store.getPrevItem();

    item && _.invoke(this, 'props.onSelect', item, { metaKey: true });
  }

  groupItems() {
    this.props.onSelectAction && this.props.onSelectAction('all', _runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_5__["ACTION_TYPE_SAVE"], {
      requests: this.store.getSelectedItems(),
      from: 'history_multiple' });

  }

  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_keymaps_KeyMaps__WEBPACK_IMPORTED_MODULE_3__["default"], {
        handlers: this.getKeyMapHandlers(),
        keyMap: pm.shortcuts.getShortcuts() }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "history-sidebar",
        ref: "history" }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "history-sidebar-wrapper" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_HistorySidebarMenu__WEBPACK_IMPORTED_MODULE_7__["default"], {
        historySidebar: this.store,
        historyStore: this.historyStore,
        enableHistoryResponseSaving: this.props.enableHistoryResponseSaving,
        onDeleteMultiple: this.props.onDeleteMultiple,
        onSelectAction: this.props.onSelectAction.bind(this, 'all'),
        onToggleHistoryResponseSaving: this.props.onToggleHistoryResponseSaving }), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_XPaths_XPath__WEBPACK_IMPORTED_MODULE_4__["default"], { identifier: "history" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_HistorySidebarList__WEBPACK_IMPORTED_MODULE_8__["default"], {
        ref: "list",
        initializing: this.props.initializing,
        isSocketConnected: this.props.isSocketConnected,
        isLoggedIn: this.props.isLoggedIn,
        workspace: this.props.workspace,
        onDeleteMultiple: this.props.onDeleteMultiple,
        onLoadMore: this.props.onLoadMore,
        onSelect: this.props.onSelect,
        onSelectAction: this.props.onSelectAction }))))));






  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 9714:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_SAVE", function() { return ACTION_TYPE_SAVE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_MONITOR", function() { return ACTION_TYPE_MONITOR; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_DOCUMENT", function() { return ACTION_TYPE_DOCUMENT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_MOCK", function() { return ACTION_TYPE_MOCK; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_DELETE", function() { return ACTION_TYPE_DELETE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_DOWNLOAD", function() { return ACTION_TYPE_DOWNLOAD; });
const ACTION_TYPE_SAVE = 'save',
ACTION_TYPE_MONITOR = 'monitor',
ACTION_TYPE_DOCUMENT = 'document',
ACTION_TYPE_MOCK = 'mock',
ACTION_TYPE_DELETE = 'delete',
ACTION_TYPE_DOWNLOAD = 'download';

/***/ }),

/***/ 9715:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HistorySidebarMenu; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2293);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2325);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_ToggleSwitch__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4396);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2845);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_Tooltips__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2326);
/* harmony import */ var _runtime_repl_common_ToastHelpers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2353);
/* harmony import */ var _runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9714);
/* harmony import */ var _runtime_repl_runner_RunnerHelper__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4514);
/* harmony import */ var _postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1601);
/* harmony import */ var _postman_app_monolith_renderer_js_containers_apps_requester_sidebar_SidebarListActions__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9025);
/* harmony import */ var _HistoryActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9716);
/* harmony import */ var _HistoryItemActionsDropdown__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9717);
var _class;














let


HistorySidebarMenu = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class HistorySidebarMenu extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      dropdownOpen: false,
      showResponseToggleTooltip: false };


    this.handleDeleteClick = this.handleDeleteClick.bind(this);
    this.handleDropdownToggle = this.handleDropdownToggle.bind(this);
    this.handleDropdownActionSelect = this.handleDropdownActionSelect.bind(this);
    this.handleAddToCollectionClick = this.handleAddToCollectionClick.bind(this);
    this.handleDeleteSelected = this.handleDeleteSelected.bind(this);
    this.handleSearchChange = this.handleSearchChange.bind(this);
    this.handleActionsDropdownSelect = this.handleActionsDropdownSelect.bind(this);
    this.handleSaveResponseToggle = this.handleSaveResponseToggle.bind(this);
    this.showResponseToggleTooltip = this.showResponseToggleTooltip.bind(this);
    this.hideResponseToggleTooltip = this.hideResponseToggleTooltip.bind(this);
    this.disableRequestItemOptions = this.disableRequestItemOptions.bind(this);
  }

  handleAddToCollectionClick(e) {
    e.stopPropagation();
    this.props.onSelectAction(_runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_SAVE"], {
      // @note `getSelectedItems` returns the ids of requests and runs combined.
      // the handler of action should be able to handle the case when request
      // with given id does not exist
      requests: this.props.historySidebar.getSelectedItems(),
      from: 'history_multiple' });

  }

  handleDeleteClick() {
    pm.mediator.trigger('showDeleteHistoryModal', async () => {
      try {this.props.onDeleteMultiple && (await this.props.onDeleteMultiple('all'));} catch (e) {pm.logger.error('无法删除历史', e);pm.toasts.error('无法删除历史');}
    }, {
      identifier: 'all' });

  }

  handleDropdownToggle(value) {
    if (value === this.state.dropdownOpen) {
      return;
    }

    this.setState({ dropdownOpen: value });
  }

  handleDropdownActionSelect(action) {
    if (action === _runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_DELETE"]) {
      if (!Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_11__["getStore"])('OnlineStatusStore').userCanSave) {
        return Object(_runtime_repl_common_ToastHelpers__WEBPACK_IMPORTED_MODULE_8__["showOfflineActionDisabledToast"])();
      }

      pm.mediator.trigger('showDeleteHistoryModal', () => {
        this.props.onDeleteMultiple('selected');
      }, {
        identifier: 'selected' });


      return;
    }

    if (action === _runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_DOWNLOAD"]) {
      return Object(_runtime_repl_runner_RunnerHelper__WEBPACK_IMPORTED_MODULE_10__["exportRuns"])(this.props.historySidebar.getSelectedItems());
    }

    this.props.onSelectAction(action, {
      // @note `getSelectedItems` returns the ids of requests and runs combined.
      // the handler of action should be able to handle the case when request
      // with given id does not exist
      requests: this.props.historySidebar.getSelectedItems(),
      from: 'history_multiple' });

  }

  handleActionsDropdownSelect(value) {
    switch (value) {
      case 'history-sidebar--clear-all':
        this.handleDeleteClick();
        break;

      default:}

  }

  handleDeleteSelected() {
    this.handleDropdownActionSelect(_runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_DELETE"]);
  }

  disableRequestItemOptions() {
    const requestItemFocusedInHistory = _.filter(this.props.historySidebar.historyItems, (item) => this.props.historySidebar.selectedItems.has(item.id) && item.type === 'request');

    return _.isEmpty(requestItemFocusedInHistory);
  }

  showResponseToggleTooltip() {
    this.setState({ showResponseToggleTooltip: true });
  }

  hideResponseToggleTooltip() {
    this.setState({ showResponseToggleTooltip: false });
  }

  handleSaveResponseToggle(e) {
    e && e.stopPropagation(); // Prevent dropdown from closing
    this.props.onToggleHistoryResponseSaving && this.props.onToggleHistoryResponseSaving();
  }

  handleSearchChange(query) {
    this.props.historySidebar.setSearchQuery(query);
  }

  getToggleSaveResponseClasses(isDisabled) {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'dropdown-menu-item history-sidebar-menu__actions-save-response-toggle': true,
      'is-disabled': isDisabled });

  }

  render() {
    const selectionSize = this.props.historySidebar.selectedItems.size,

    { isLoggedIn } = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_11__["getStore"])('CurrentUserStore'),
    { isOffline, userCanSave } = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_11__["getStore"])('OnlineStatusStore'),
    disableClearAll = isOffline && isLoggedIn,
    disableSaveResponses = !Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_11__["getStore"])('PermissionStore').can('editMeta', 'workspace', Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_11__["getStore"])('ActiveWorkspaceStore').id);

    if (selectionSize > 1) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "history-sidebar-menu multiple-request-selected" }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "history-sidebar-menu__left" }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_3__["Text"], { type: "body-small", color: "content-color-primary" },
        selectionSize,
        ' ', "项已选择")), /*#__PURE__*/



        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "history-sidebar-menu__right" }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "history-sidebar-menu__actions-delete-history-wrapper" }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_4__["Button"], {
          disabled: !userCanSave,
          className: "history-sidebar-list-item__button__delete",
          type: "icon",
          onClick: this.handleDeleteSelected,
          tooltip: _HistoryActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_13__["ACTION_TYPE_DELETE_REQUESTS_TOOLTIP"] }, /*#__PURE__*/

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_3__["Icon"], { name: "icon-action-delete-stroke", size: "large", className: "history-sidebar-list-item__actions__delete pm-icon pm-icon-normal" })), /*#__PURE__*/

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_HistoryItemActionsDropdown__WEBPACK_IMPORTED_MODULE_14__["default"], {
          count: selectionSize,
          onSelect: this.handleDropdownActionSelect,
          onToggle: this.handleDropdownToggle,
          disableRequestSpecificActions: this.disableRequestItemOptions() })))));





    }

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "history-sidebar-menu" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_containers_apps_requester_sidebar_SidebarListActions__WEBPACK_IMPORTED_MODULE_12__["default"], {
        className: "history-sidebar__filter",
        onSearch: this.handleSearchChange,
        onActionsDropdownSelect: this.handleActionsDropdownSelect,
        searchQuery: this.props.historySidebar.searchQuery,
        moreActions: /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_6__["DropdownMenu"], { className: "history-sidebar__header-actions-dropdown--menu" },
        !_.isEmpty(this.props.historySidebar.historyItems) && /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_6__["MenuItem"], {
          className: "history-sidebar__header-actions-dropdown--menu-item history-sidebar-menu__actions-delete-history-wrapper",
          key: "history-sidebar--clear-all",
          refKey: "history-sidebar--clear-all",
          disabled: disableClearAll,
          disabledText: "你需要联网才能清除历史." }, /*#__PURE__*/

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, "全部清除")), /*#__PURE__*/


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: this.getToggleSaveResponseClasses(disableSaveResponses),
          onClick: disableSaveResponses ? undefined : this.handleSaveResponseToggle,
          ref: (r) => {this.saveResponseToggleContainerRef = r;},
          onMouseEnter: this.showResponseToggleTooltip,
          onMouseLeave: this.hideResponseToggleTooltip }, "保存响应", /*#__PURE__*/


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_ToggleSwitch__WEBPACK_IMPORTED_MODULE_5__["default"], {
          isActive: this.props.enableHistoryResponseSaving,
          activeLabel: "",
          inactiveLabel: "" }), /*#__PURE__*/

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Tooltips__WEBPACK_IMPORTED_MODULE_7__["Tooltip"], {
          className: "history-sidebar-menu--save-response__tooltip",
          show: this.state.showResponseToggleTooltip,
          target: this.saveResponseToggleContainerRef }, /*#__PURE__*/

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Tooltips__WEBPACK_IMPORTED_MODULE_7__["TooltipBody"], null,

        disableSaveResponses ? '您没有权限来执行此操作.' :
        '当关闭时,响应Header和Body将不会被保存,但响应代码、时间、大小和语言将被保存以用于报告目的.')))) })));









  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 9716:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_DELETE_REQUEST_TOOLTIP", function() { return ACTION_TYPE_DELETE_REQUEST_TOOLTIP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_DELETE_REQUESTS_TOOLTIP", function() { return ACTION_TYPE_DELETE_REQUESTS_TOOLTIP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_SAVE_REQUEST_TOOLTIP", function() { return ACTION_TYPE_SAVE_REQUEST_TOOLTIP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTION_TYPE_SAVE_REQUESTS_TOOLTIP", function() { return ACTION_TYPE_SAVE_REQUESTS_TOOLTIP; });
const ACTION_TYPE_DELETE_REQUEST_TOOLTIP = '删除请求',
ACTION_TYPE_DELETE_REQUESTS_TOOLTIP = '删除项目',
ACTION_TYPE_SAVE_REQUEST_TOOLTIP = '将请求添加到集合',
ACTION_TYPE_SAVE_REQUESTS_TOOLTIP = '将请求添加到集合';

/***/ }),

/***/ 9717:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HistoryItemActionsDropdown; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2293);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2845);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2325);
/* harmony import */ var _postman_app_monolith_renderer_js_utils_PluralizeHelper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3194);
/* harmony import */ var _runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9714);
/* harmony import */ var _runtime_repl_common_ScratchpadConstants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4378);
/* harmony import */ var _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4181);
/* harmony import */ var _postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1601);
/* harmony import */ var _postman_app_monolith_renderer_js_constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3714);
/* harmony import */ var _postman_app_monolith_renderer_js_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4332);
var _class;














const DISABLED_REQUEST_OPTIONS_TOOLTIP = '不适用于集合运行项目',
COLLECTION_RUN_EXPORT_DISABLED_TOOLTIP = '您只能导出集合运行';let


HistoryItemActionsDropdown = Object(mobx_react__WEBPACK_IMPORTED_MODULE_2__["observer"])(_class = class HistoryItemActionsDropdown extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleSelect = this.handleSelect.bind(this);
    this.handleShortcutSelect = this.handleShortcutSelect.bind(this);
    this.handleToggle = this.handleToggle.bind(this);
  }

  getKeymapHandlers() {
    return { delete: pm.shortcuts.handle('delete', this.handleShortcutSelect.bind(this, _runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_DELETE"])) };
  }

  handleShortcutSelect(action) {
    pm.mediator.trigger('focusSidebar');
    this.handleSelect(action);
  }

  handleSelect(action) {
    this.props.onSelect && this.props.onSelect(action);
    this.handleToggle(false);
  }

  handleToggle(isOpen) {
    this.props.onToggle && this.props.onToggle(isOpen);
  }

  getDropDownActionWrapperClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({ 'collection-sidebar-request-dropdown-actions-wrapper': true });
  }

  getDisabledText(isDisabled) {
    if (!isDisabled) {
      return;
    }

    if (!Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_10__["getStore"])('OnlineStatusStore').userCanSave) {
      return _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_9__["DISABLED_TOOLTIP_IS_OFFLINE"];
    }

    return _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_9__["DISABLED_TOOLTIP_NO_PERMISSION"];
  }


  render() {
    const pluralizeRequest = _postman_app_monolith_renderer_js_utils_PluralizeHelper__WEBPACK_IMPORTED_MODULE_6__["default"].pluralize({
      count: this.props.count,
      singular: '请求',
      plural: '请求' }),


    permissionStore = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_10__["getStore"])('PermissionStore'),
    { userCanSave } = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_10__["getStore"])('OnlineStatusStore'),
    canDeleteHistory = userCanSave && permissionStore.can('delete', 'history');

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: this.getDropDownActionWrapperClasses() }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_4__["Dropdown"], {
        keyMapHandlers: this.getKeymapHandlers(),
        ref: "menu",
        onSelect: this.handleSelect,
        onToggle: this.handleToggle,
        className: "collection-sidebar-request-actions-dropdown history-sidebar-multiple-request-selected-dropdown" }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_4__["DropdownButton"], {
        dropdownStyle: "nocaret",
        type: "custom" }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_5__["Button"], {
        className: "history-sidebar-list-item__button__options",
        tooltip: _postman_app_monolith_renderer_js_constants_MoreButtonTooltipConstant__WEBPACK_IMPORTED_MODULE_11__["ACTION_TYPE_VIEW_MORE_ACTIONS_TOOLTIP"] },

      ' ', /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_3__["Icon"], {
        name: "icon-action-options-stroke",
        className: "history-sidebar-list-item__actions__options pm-icon pm-icon-normal" }))), /*#__PURE__*/



      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_4__["DropdownMenu"], {
        "align-right": true }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_4__["MenuItem"], {
        refKey: _runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_SAVE"],
        disabled: !userCanSave || this.props.disableRequestSpecificActions,
        disabledText: userCanSave ? DISABLED_REQUEST_OPTIONS_TOOLTIP : _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_9__["DISABLED_TOOLTIP_IS_OFFLINE"] }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "dropdown-menu-item-label" }, `保存${pluralizeRequest}`)), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_4__["MenuItem"], {
        refKey: _runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_MONITOR"],
        disabled: !userCanSave || this.props.disableRequestSpecificActions,
        disabledText:
        userCanSave ?
        this.props.disableRequestSpecificActions ?
        DISABLED_REQUEST_OPTIONS_TOOLTIP :
        _runtime_repl_common_ScratchpadConstants__WEBPACK_IMPORTED_MODULE_8__["DISABLED_IN_SCRATCHPAD_TOOLTIP"] : _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_9__["DISABLED_TOOLTIP_IS_OFFLINE"] }, /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "dropdown-menu-item-label" }, `监视${pluralizeRequest}`)), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_4__["MenuItem"], {
        refKey: _runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_DOCUMENT"],
        disabled: !userCanSave || this.props.disableRequestSpecificActions,
        disabledText:
        userCanSave ?
        this.props.disableRequestSpecificActions ?
        DISABLED_REQUEST_OPTIONS_TOOLTIP :
        _runtime_repl_common_ScratchpadConstants__WEBPACK_IMPORTED_MODULE_8__["DISABLED_IN_SCRATCHPAD_TOOLTIP"] : _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_9__["DISABLED_TOOLTIP_IS_OFFLINE"] }, /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "dropdown-menu-item-label" }, `${pluralizeRequest}文档`)), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_4__["MenuItem"], {
        refKey: _runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_MOCK"],
        disabled: !userCanSave || this.props.disableRequestSpecificActions,
        disabledText:
        userCanSave ?
        this.props.disableRequestSpecificActions ?
        DISABLED_REQUEST_OPTIONS_TOOLTIP :
        _runtime_repl_common_ScratchpadConstants__WEBPACK_IMPORTED_MODULE_8__["DISABLED_IN_SCRATCHPAD_TOOLTIP"] : _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_9__["DISABLED_TOOLTIP_IS_OFFLINE"] }, /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "dropdown-menu-item-label" }, `模拟${pluralizeRequest}`)),


      window.SDK_PLATFORM !== 'browser' && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_4__["MenuItem"], {
        refKey: _runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_DOWNLOAD"],
        disabled: !userCanSave || !this.props.disableRequestSpecificActions,
        disabledText: userCanSave ? COLLECTION_RUN_EXPORT_DISABLED_TOOLTIP : _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_9__["DISABLED_TOOLTIP_IS_OFFLINE"] }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "dropdown-menu-item-label" }, "导出")), /*#__PURE__*/



      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_4__["MenuItem"], {
        refKey: _runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_DELETE"],
        disabled: !canDeleteHistory,
        disabledText: this.getDisabledText(!canDeleteHistory) }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "dropdown-menu-item-label" }, "删除"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "dropdown-menu-item-shortcut" }, Object(_postman_app_monolith_renderer_js_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_12__["getShortcutByName"])('delete')))))));





  }}) || _class;

/***/ }),

/***/ 9718:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HistorySidebarList; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2293);
/* harmony import */ var react_window__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3699);
/* harmony import */ var react_virtualized_auto_sizer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5127);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2325);
/* harmony import */ var _postman_app_monolith_renderer_js_utils_PluralizeHelper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3194);
/* harmony import */ var _runtime_repl_request_websocket_history_sidebar_components_WebSocketHistorySidebarListItem__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9719);
/* harmony import */ var _postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1601);
/* harmony import */ var _HistorySidebarListEmptyItem__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9720);
/* harmony import */ var _appsdk_sidebar_SidebarEmptyState_SidebarEmptyState__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9027);
/* harmony import */ var _HistoryListItem__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9721);
/* harmony import */ var _HistoryListMetaItem__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9722);
/* harmony import */ var _HistoryListErrorItem__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9723);
/* harmony import */ var _HistoryListCollectionRunItem__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9724);
/* harmony import */ var _HistorySidebarErrorState__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(9725);
/* harmony import */ var _appsdk_sidebar_SidebarLoadingState_SidebarLoadingState__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(7771);
var _class;function _extends() {_extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};return _extends.apply(this, arguments);}

















const MIN_ROW_HEIGHT = 28,
OVERSCAN_COUNT = 10,
VIEW_HISTORY_PERMISSION_ERROR = '您没有权限查看历史在这个工作区';let


HistorySidebarList = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class HistorySidebarList extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.store = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_8__["getStore"])('HistorySidebarStore');
    this.requesterSidebarStore = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_8__["getStore"])('RequesterSidebarStore');

    this.handleToggleGroup = this.handleToggleGroup.bind(this);
    this.getListItem = this.getListItem.bind(this);
    this.getItemSize = this.getItemSize.bind(this);
    this.handleClearCachedHeight = this.handleClearCachedHeight.bind(this);
    this.observeSizeChange = this.observeSizeChange.bind(this);
    this.unobserveSizeChange = this.unobserveSizeChange.bind(this);
    this.handleItemsRender = this.handleItemsRender.bind(this);
    this.handleItemsRenderDebounced = _.debounce(this.handleItemsRender, 1000);
    this.handleListScroll = this.handleListScroll.bind(this);
    this.handleListScrollDebounced = _.debounce(this.handleListScroll, 300);
    this.handleJumpToTop = this.handleJumpToTop.bind(this);
    this.handleRefresh = this.handleRefresh.bind(this);

    this.heightSet = {};

    this.resizeObserver = new ResizeObserver((entries) => {
      // eslint-disable-next-line no-unused-vars
      for (const entry of entries) {
        if (!(entry && entry.target && entry.target.dataset)) {
          return;
        }

        const { index } = entry.target.dataset;

        this.heightSet[index] = entry.target.offsetHeight;
      }

      this.handleClearCachedHeight(0);
    });
  }

  componentDidMount() {
    if (!this.props.initializing) {
      this.store.load();
    }
  }

  componentDidUpdate(prevProps) {
    // Are stores still initializing?
    if (this.props.initializing) {
      return;
    }

    // Everthing is initialized, load data
    if (prevProps.initializing) {
      this.store.load();

      return;
    }

    // Workspace has switched or user logged in, load data again and scroll to top
    if (this.props.workspace !== prevProps.workspace || this.props.isLoggedIn && !prevProps.isLoggedIn) {
      this.store.load();
      this.listRef && this.listRef.scrollTo(0);
      this.store.setScrollOffset(0);
    }
  }

  observeSizeChange(node) {
    this.resizeObserver && this.resizeObserver.observe(node);
  }

  unobserveSizeChange(node, index) {
    this.resizeObserver && this.resizeObserver.unobserve(node);
    delete this.heightSet[index];
  }

  handleClearCachedHeight(index) {
    this.listRef.resetAfterIndex(index);
  }

  handleToggleGroup(name) {
    if (this.store.isItemCollapsed(name)) {
      return this.store.expandItem(name);
    }

    this.store.collapseItem(name);
  }

  getItemSize(index) {
    const currentItem = _.get(this.store, ['historyItems', index]);

    if (currentItem.type === 'meta' || currentItem.type === 'error') {
      return MIN_ROW_HEIGHT;
    }

    return this.heightSet[index] || MIN_ROW_HEIGHT;
  }

  getListItem(data) {
    const historyItem = _.get(this.store, ['historyItems', data.index]);

    if (!historyItem) {
      return null;
    }

    if (historyItem.type === 'error') {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "history-list__error", style: data.style }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_HistoryListErrorItem__WEBPACK_IMPORTED_MODULE_13__["default"], {
          key: historyItem.name,
          onRetry: () => {
            if (historyItem.key === 'load-error') {
              return this.store.load(true);
            }

            if (historyItem.key === 'load-more-error') {
              return this.store.loadMore();
            }
          } })));



    }

    if (historyItem.type === 'meta') {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "history-list__meta", style: data.style }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_HistoryListMetaItem__WEBPACK_IMPORTED_MODULE_12__["default"], {
          name: historyItem.name,
          key: historyItem.name,
          onSelect: this.props.onSelect,
          onSelectAction: this.props.onSelectAction.bind(this, 'all'),
          items: historyItem.items,
          disableRequestSpecificActions: historyItem.disableRequestSpecificActions })));



    }

    if (historyItem.type === 'collectionrun') {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "history-list__collection-run", style: data.style }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_HistoryListCollectionRunItem__WEBPACK_IMPORTED_MODULE_14__["default"], _extends({},
        historyItem, {
          name: historyItem.name,
          hideActions: _.size(this.store.getSelectedItems()) > 1,
          key: historyItem.id,
          selected: this.store.isItemSelected(historyItem.id),
          onSelect: this.props.onSelect,
          onSelectAction: this.props.onSelectAction.bind(this, 'collectionrun'),
          observeSizeChange: this.observeSizeChange,
          unobserveSizeChange: this.unobserveSizeChange,
          index: data.index }))));



    }

    if (historyItem.type === 'websockethistory') {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "history-list__websocket", style: data.style }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_runtime_repl_request_websocket_history_sidebar_components_WebSocketHistorySidebarListItem__WEBPACK_IMPORTED_MODULE_7__["default"], _extends({},
        historyItem, {
          key: historyItem.id,
          isSelected: this.store.isItemSelected(historyItem.id),
          onSelect: this.props.onSelect,
          onSelectAction: this.props.onSelectAction.bind(this, 'websockethistory'),
          observeSizeChange: this.observeSizeChange,
          unobserveSizeChange: this.unobserveSizeChange,
          index: data.index }))));



    }

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "history-list__item", style: data.style }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_HistoryListItem__WEBPACK_IMPORTED_MODULE_11__["default"], _extends({},
      historyItem, {
        hideActions: _.size(this.store.getSelectedItems()) > 1,
        key: historyItem.id,
        selected: this.store.isItemSelected(historyItem.id),
        onSelect: this.props.onSelect,
        onSelectAction: this.props.onSelectAction.bind(this, 'request'),
        observeSizeChange: this.observeSizeChange,
        unobserveSizeChange: this.unobserveSizeChange,
        viewLargeBody: this.props.viewLargeBody,
        index: data.index }))));



  }

  getNotification() {
    if (this.store.showReloadNotification) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "history-sidebar-list__notification" }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_5__["Button"], {
          type: "primary",
          size: "small",
          className: "history-sidebar-list__refresh",
          onClick: this.handleRefresh }, /*#__PURE__*/

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_4__["Icon"], {
          name: "icon-action-refresh-stroke",
          color: "content-color-primary",
          size: "small",
          className: "pm-icon" }), "刷新")));





    }

    if (this.store.newHistoryIds.size) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "history-sidebar-list__notification" }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_5__["Button"], {
          type: "primary",
          size: "small",
          className: "history-sidebar-list__more-on-top",
          onClick: this.handleJumpToTop }, /*#__PURE__*/

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_4__["Icon"], {
          name: "icon-direction-up",
          color: "content-color-primary",
          size: "small",
          className: "pm-icon" }), /*#__PURE__*/

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null,
        this.store.newHistoryIds.size,
        ' ', "new",

        ' ',
        _postman_app_monolith_renderer_js_utils_PluralizeHelper__WEBPACK_IMPORTED_MODULE_6__["default"].pluralize({
          count: this.store.newHistoryIds.size,
          singular: '项',
          plural: '项' })))));





    }

    return null;
  }

  handleListScroll({ scrollOffset }) {
    if (scrollOffset === 0 && this.store.newHistoryIds.size) {
      this.store.showNewHistory();
    }

    this.store.setScrollOffset(scrollOffset);
  }

  handleItemsRender(data) {
    // No need to load more data
    if (this.store.scrolledToEnd || this.store.loadingMore || this.requesterSidebarStore.query) {
      return;
    }

    // Scrolled to the end or last history request is visible
    if (data.overscanStopIndex === data.visibleStopIndex) {
      this.store.loadMore();
    }
  }

  handleJumpToTop() {
    this.listRef && this.listRef.scrollTo(0);
  }

  handleRefresh() {
    this.listRef && this.listRef.scrollTo(0);
    this.store.load(true);
  }

  render() {
    const
    lister = (data) => /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mobx_react__WEBPACK_IMPORTED_MODULE_1__["Observer"], null,
    this.getListItem.bind(this, data)),


    sizer = ({ height, width }) => /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mobx_react__WEBPACK_IMPORTED_MODULE_1__["Observer"], null,
    () => /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_window__WEBPACK_IMPORTED_MODULE_2__["VariableSizeList"], {
      height: height,
      itemCount: this.store.historyItems.length,
      itemSize: this.getItemSize,
      width: width,
      ref: (ref) => {this.listRef = ref;},
      overscanCount: OVERSCAN_COUNT,
      onItemsRendered: this.handleItemsRenderDebounced,
      onScroll: this.handleListScrollDebounced },

    lister));





    if (_.isEmpty(this.store.historyItems)) {
      if (this.props.initializing || this.store.loading) {
        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "history-sidebar-list" }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_sidebar_SidebarLoadingState_SidebarLoadingState__WEBPACK_IMPORTED_MODULE_16__["default"], { hasHierarchy: true }));
      }

      if (this.store.loadError) {
        if (this.store.loadError.message === VIEW_HISTORY_PERMISSION_ERROR) {
          return /*#__PURE__*/(
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "history-sidebar-list-permission-error" }, /*#__PURE__*/
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_sidebar_SidebarEmptyState_SidebarEmptyState__WEBPACK_IMPORTED_MODULE_10__["default"], {
              illustration: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_4__["IllustrationNoPermission"], null),
              title: "您没有权限查看历史",
              message: "只有团队成员才能查看此工作区的历史" })));



        }

        return /*#__PURE__*/(
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "history-sidebar-list" }, /*#__PURE__*/
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_HistorySidebarErrorState__WEBPACK_IMPORTED_MODULE_15__["default"], { onRetry: () => this.store.load(true) })));


      }

      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "history-sidebar-list" }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_HistorySidebarListEmptyItem__WEBPACK_IMPORTED_MODULE_9__["default"], { query: this.store.searchQuery })));


    }

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "history-sidebar-list",
        ref: "history" },

      this.getNotification(), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_virtualized_auto_sizer__WEBPACK_IMPORTED_MODULE_3__["default"], null, sizer)));


  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 9719:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return WebSocketHistorySidebarListItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3737);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2293);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_Avatar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4190);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_Tooltips__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2326);
/* harmony import */ var _postman_app_monolith_renderer_js_containers_apps_requester_sidebar_SidebarListItem__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9023);
/* harmony import */ var _postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1601);
/* harmony import */ var _runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9714);
/* harmony import */ var _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4181);
var _class;










let


WebSocketHistorySidebarListItem = Object(mobx_react__WEBPACK_IMPORTED_MODULE_5__["observer"])(_class = class WebSocketHistorySidebarListItem extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      isTooltipVisible: false };


    this.userAvatar = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createRef();
    this.handleSelect = this.handleSelect.bind(this);
    this.handleAction = this.handleAction.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
    this.showTooltip = this.showTooltip.bind(this);
    this.hideTooltip = this.hideTooltip.bind(this);
    this.getLeftAlignedComponents = this.getLeftAlignedComponents.bind(this);
    this.getRightAlignedComponents = this.getRightAlignedComponents.bind(this);
  }


  componentDidMount() {
    this.selfNode = Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["findDOMNode"])(this);

    // Starts observing element
    this.props.observeSizeChange && this.props.observeSizeChange(this.selfNode);
  }

  componentWillUpdate(nextProps) {
    if (!this.props.selected && nextProps.selected) {
      const $node = Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["findDOMNode"])(this);

      $node && $node.scrollIntoViewIfNeeded && $node.scrollIntoViewIfNeeded();
    }
  }

  componentWillUnmount() {
    this.props.unobserveSizeChange && this.props.unobserveSizeChange(this.selfNode, this.props.index);
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_3___default()({
      'history-sidebar-list-item': true,
      'history-sidebar-list-item__websocket-history': true,
      'is-selected': this.props.selected });

  }

  getTooltipText(isDisabled, isOffline) {
    if (!isDisabled) {
      return '删除历史';
    }

    if (isOffline) {
      return _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_11__["DISABLED_TOOLTIP_IS_OFFLINE"];
    }

    return _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_11__["DISABLED_TOOLTIP_NO_PERMISSION"];
  }

  getLeftAlignedComponents(isHovered) {
    if (!isHovered) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "history-sidebar__indent" }));

    }

    const classNames = classnames__WEBPACK_IMPORTED_MODULE_3___default()({
      'history-sidebar-list-item-updatedBy': true,
      hovered: isHovered }),


    owner = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('CurrentUserStore').teamMembers.get(String(this.props.owner)),
    ownerName = owner && (owner.name || owner.username);

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: classNames,
        onMouseOver: this.showTooltip,
        onMouseLeave: this.hideTooltip },


      !this.props.owner || this.props.owner === '0' ? /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_4__["Icon"], { name: "icon-descriptive-user-stroke", color: "content-color-secondary" }) : /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Avatar__WEBPACK_IMPORTED_MODULE_6__["default"], {
        ref: this.userAvatar,
        size: "small",
        userId: this.props.owner }),




      this.userAvatar.current && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Tooltips__WEBPACK_IMPORTED_MODULE_7__["Tooltip"], {
        immediate: true,
        show: this.state.isTooltipVisible,
        target: this.userAvatar.current,
        placement: "right" }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Tooltips__WEBPACK_IMPORTED_MODULE_7__["TooltipBody"], null, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "history-sidebar-list-item-avatar-tooltip" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_4__["Text"], { type: "body-medium" }, ownerName), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_4__["Text"], { type: "body-medium" }, moment__WEBPACK_IMPORTED_MODULE_2___default()(this.props.createdAt).format('DD MMM YYYY, h:mm A')))))));







  }

  getRightAlignedComponents(isHovered) {
    const classNames = classnames__WEBPACK_IMPORTED_MODULE_3___default()({
      'sidebar-list-item__right-section-actions': true,
      hovered: isHovered });


    if (!isHovered) {
      return null;
    }

    const permissionStore = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('PermissionStore'),
    { userCanSave } = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_9__["getStore"])('OnlineStatusStore'),

    // NOTE: We are checking permission for 'history` instead of `websockethistory` as
    // there were no permissions registered for the same at the time of implementing this
    // @todo [WebSocket]: FIX THIS
    canDeleteHistory = userCanSave && permissionStore.can('delete', 'history');

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: classNames }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_4__["Button"], {
        type: "tertiary",
        icon: "icon-action-delete-stroke",
        onClick: this.handleDelete,
        isDisabled: !canDeleteHistory,
        tooltip: this.getTooltipText(!canDeleteHistory, !userCanSave) })));



  }

  showTooltip() {
    this.setState({ isTooltipVisible: true });
  }

  hideTooltip() {
    this.setState({ isTooltipVisible: false });
  }

  handleSelect(e) {
    e.stopPropagation();
    const modifiers = {
      ctrlKey: e.ctrlKey,
      metaKey: e.metaKey,
      shiftKey: e.shiftKey };


    this.props.onSelect && this.props.onSelect({ id: this.props.id, type: 'websockethistory' }, modifiers);
  }

  handleAction(action) {
    this.props.onSelectAction(action, { websockethistory: [this.props.id] });
  }

  handleDelete(e) {
    e.stopPropagation();
    this.handleAction(_runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_10__["ACTION_TYPE_DELETE"]);
  }

  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { "data-index": this.props.index }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_containers_apps_requester_sidebar_SidebarListItem__WEBPACK_IMPORTED_MODULE_8__["default"], {
        text: this.props.url,
        icon: "icon-entity-websocket-stroke",
        isSelected: this.props.isSelected,
        onClick: this.handleSelect,
        className: this.getClasses(),
        leftMetaComponent: this.getLeftAlignedComponents,
        rightMetaComponent: this.getRightAlignedComponents })));



  }}) || _class;

/***/ }),

/***/ 9720:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HistorySidebarListEmptyItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2293);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9);
/* harmony import */ var _postman_app_monolith_renderer_js_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3174);
/* harmony import */ var _postman_app_monolith_renderer_js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1810);
/* harmony import */ var _appsdk_sidebar_SidebarEmptyState_SidebarEmptyState__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9027);
/* harmony import */ var _appsdk_sidebar_SidebarNoResultsFound_SidebarNoResultsFound__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8228);
var _class;





let


HistorySidebarListEmptyItem = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class HistorySidebarListEmptyItem extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.handleShowMeHow = this.handleShowMeHow.bind(this);
  }

  handleShowMeHow() {
    // RunTaggedLesson('debugging', {
    //   signInModalOptions: {
    //     type: 'history',
    //     origin: 'history_sidebar_show_me_how'
    //   }
    // });

    Object(_postman_app_monolith_renderer_js_external_navigation_ExternalNavigationService__WEBPACK_IMPORTED_MODULE_4__["openExternalLink"])(_postman_app_monolith_renderer_js_constants_AppUrlConstants__WEBPACK_IMPORTED_MODULE_3__["SEND_FIRST_REQUEST_DOCS"], '_blank');
  }

  render() {
    if (this.props.query) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_sidebar_SidebarNoResultsFound_SidebarNoResultsFound__WEBPACK_IMPORTED_MODULE_6__["default"], { searchQuery: this.props.query, illustration: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_2__["IllustrationNoHistory"], null) }));

    }

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_sidebar_SidebarEmptyState_SidebarEmptyState__WEBPACK_IMPORTED_MODULE_5__["default"], {
        illustration: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_2__["IllustrationNoHistory"], null),
        title: "您尚未发送任何请求.",
        message: "您在此工作区中发送的任何请求都将显示在此处.",
        action: {
          label: '告诉我怎么做',
          handler: this.handleShowMeHow } }));



  }}) || _class;

/***/ }),

/***/ 9721:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HistoryListItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3737);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2293);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2325);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2845);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_Avatar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4190);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_Tooltips__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2326);
/* harmony import */ var _postman_app_monolith_renderer_js_containers_apps_requester_sidebar_SidebarListItem__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9023);
/* harmony import */ var _runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9714);
/* harmony import */ var _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4181);
/* harmony import */ var _runtime_repl_common_ScratchpadConstants__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4378);
/* harmony import */ var _postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1601);
/* harmony import */ var _runtime_repl_history_HistoryActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(9716);
/* harmony import */ var _runtime_repl_request_http_RequestIcon__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(2690);
/* harmony import */ var _postman_app_monolith_renderer_js_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(4332);
var _class;

















let


HistoryListItem = Object(mobx_react__WEBPACK_IMPORTED_MODULE_4__["observer"])(_class = class HistoryListItem extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      dropdownOpen: false,
      isTooltipVisible: false };


    this.userAvatar = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createRef();
    this.handleSelect = this.handleSelect.bind(this);
    this.handleDropdownToggle = this.handleDropdownToggle.bind(this);
    this.handleDropdownActionSelect = this.handleDropdownActionSelect.bind(this);
    this.handleAddRequestToCollectionClick = this.handleAddRequestToCollectionClick.bind(this);
    this.handleRemoveRequest = this.handleRemoveRequest.bind(this);
    this.showTooltip = this.showTooltip.bind(this);
    this.hideTooltip = this.hideTooltip.bind(this);
    this.getLeftAlignedComponents = this.getLeftAlignedComponents.bind(this);
    this.getRightAlignedComponents = this.getRightAlignedComponents.bind(this);
  }


  componentDidMount() {
    this.selfNode = Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["findDOMNode"])(this);

    // Starts observing element
    this.props.observeSizeChange && this.props.observeSizeChange(this.selfNode);
  }

  componentWillUnmount() {
    this.props.unobserveSizeChange && this.props.unobserveSizeChange(this.selfNode, this.props.index);
  }

  componentWillUpdate(nextProps) {
    if (!this.props.selected && nextProps.selected) {
      const $node = Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["findDOMNode"])(this);

      if (!$node) {
        return;
      }

      if ($node.scrollIntoViewIfNeeded) {
        $node.scrollIntoViewIfNeeded();
      } else {
        $node.scrollIntoView();
      }
    }
  }

  showTooltip() {
    this.setState({ isTooltipVisible: true });
  }

  hideTooltip() {
    this.setState({ isTooltipVisible: false });
  }

  handleSelect(e) {
    e.stopPropagation();
    const modifiers = {
      ctrlKey: e.ctrlKey,
      metaKey: e.metaKey,
      shiftKey: e.shiftKey };


    this.props.onSelect && this.props.onSelect({ id: this.props.id, type: 'request' }, modifiers);
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'history-sidebar-list-item': true,
      'history-sidebar-list-item__request': true,
      'is-hovered': this.state.dropdownOpen,
      'is-selected': this.props.selected });

  }

  handleDropdownToggle(value) {
    if (value === this.state.dropdownOpen) {
      return;
    }

    this.setState({ dropdownOpen: value });
  }

  handleDropdownActionSelect(action) {
    this.props.onSelectAction(action, {
      requests: [this.props.id],
      from: 'history_single' });

  }

  handleAddRequestToCollectionClick(e) {
    e.stopPropagation();
    this.handleDropdownActionSelect(_runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_11__["ACTION_TYPE_SAVE"], { from: 'history_single' });
  }

  handleRemoveRequest(e) {
    e.stopPropagation();
    this.handleDropdownActionSelect(_runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_11__["ACTION_TYPE_DELETE"]);
  }

  getTooltipText(isDisabled, isOffline) {
    if (!isDisabled) {
      return _runtime_repl_history_HistoryActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_15__["ACTION_TYPE_DELETE_REQUEST_TOOLTIP"];
    }

    if (isOffline) {
      return _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_12__["DISABLED_TOOLTIP_IS_OFFLINE"];
    }

    return _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_12__["DISABLED_TOOLTIP_NO_PERMISSION"];
  }

  getDisabledText(isDisabled, isOffline) {
    if (!isDisabled) {
      return;
    }

    if (isOffline) {
      return _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_12__["DISABLED_TOOLTIP_IS_OFFLINE"];
    }

    return _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_12__["DISABLED_TOOLTIP_NO_PERMISSION"];
  }

  getLeftAlignedComponents(isHovered, isMoreActionsDropdownOpen) {
    const classNames = classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'history-sidebar-list-item-updatedBy': true,
      hovered: isHovered });


    if (!isHovered && !isMoreActionsDropdownOpen) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "history-sidebar__indent" }));

    }

    const updatedByMember = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('CurrentUserStore').teamMembers.get(this.props.lastUpdatedBy),
    updatedByMemberName = updatedByMember && (updatedByMember.name || updatedByMember.username);

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: classNames,
        onMouseEnter: this.showTooltip,
        onMouseLeave: this.hideTooltip },


      !this.props.lastUpdatedBy || this.props.lastUpdatedBy === '0' ? /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_5__["Icon"], { name: "icon-descriptive-user-stroke", className: "pm-icon pm-icon-normal" }) : /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Avatar__WEBPACK_IMPORTED_MODULE_8__["default"], {
        ref: this.userAvatar,
        size: "small",
        userId: this.props.lastUpdatedBy }),




      this.userAvatar.current && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Tooltips__WEBPACK_IMPORTED_MODULE_9__["Tooltip"], {
        immediate: true,
        show: this.state.isTooltipVisible,
        target: this.userAvatar.current,
        placement: "right" }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Tooltips__WEBPACK_IMPORTED_MODULE_9__["TooltipBody"], null, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null,
      updatedByMemberName), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null,
      moment__WEBPACK_IMPORTED_MODULE_3___default()(this.props.createdAt).format('DD MMM YYYY, h:mm A')))))));








  }

  getRightAlignedComponents(isHovered, isMoreActionsDropdownOpen) {
    const classNames = classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'sidebar-list-item__right-section-actions': true,
      hovered: isHovered });


    if (!isHovered && !isMoreActionsDropdownOpen) return null;

    const permissionStore = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('PermissionStore'),
    { userCanSave } = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('OnlineStatusStore'),
    canDeleteHistory = userCanSave && permissionStore.can('delete', 'history', this.props.id);

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: classNames }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_6__["Button"], {
        className: "history-sidebar-list-item__button__add",
        type: "icon",
        onClick: this.handleAddRequestToCollectionClick,
        disabled: !userCanSave,
        tooltip: userCanSave ? _runtime_repl_history_HistoryActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_15__["ACTION_TYPE_SAVE_REQUEST_TOOLTIP"] : _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_12__["DISABLED_TOOLTIP_IS_OFFLINE"] }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_5__["Icon"], { size: "large", name: "icon-action-add-stroke", className: "history-sidebar-list-item__actions__add pm-icon pm-icon-normal" })), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_6__["Button"], {
        className: "history-sidebar-list-item__button__delete",
        type: "icon",
        onClick: this.handleRemoveRequest,
        disabled: !canDeleteHistory,
        tooltip: this.getTooltipText(!canDeleteHistory, !userCanSave) }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_5__["Icon"], {
        name: "icon-action-delete-stroke",
        size: "large",
        className: "history-sidebar-list-item__actions__delete pm-icon pm-icon-normal" }))));




  }

  getActionsMenuItems(canDeleteHistory) {
    const { userCanSave, userCanSaveAndSync } = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('OnlineStatusStore');

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["DropdownMenu"], {
        "align-right": true }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["MenuItem"], {
        refKey: _runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_11__["ACTION_TYPE_SAVE"],
        disabled: !userCanSave,
        disabledText: _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_12__["DISABLED_TOOLTIP_IS_OFFLINE"] }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "dropdown-menu-item-label" }, "保存请求")), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["MenuItem"], {
        refKey: _runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_11__["ACTION_TYPE_MONITOR"],
        disabled: !userCanSaveAndSync,
        disabledText: userCanSave ? _runtime_repl_common_ScratchpadConstants__WEBPACK_IMPORTED_MODULE_13__["DISABLED_IN_SCRATCHPAD_TOOLTIP"] : _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_12__["DISABLED_TOOLTIP_IS_OFFLINE"] }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "dropdown-menu-item-label" }, "监视请求")), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["MenuItem"], {
        refKey: _runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_11__["ACTION_TYPE_DOCUMENT"],
        disabled: !userCanSaveAndSync,
        disabledText: userCanSave ? _runtime_repl_common_ScratchpadConstants__WEBPACK_IMPORTED_MODULE_13__["DISABLED_IN_SCRATCHPAD_TOOLTIP"] : _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_12__["DISABLED_TOOLTIP_IS_OFFLINE"] }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "dropdown-menu-item-label" }, "请求文档")), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["MenuItem"], {
        refKey: _runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_11__["ACTION_TYPE_MOCK"],
        disabled: !userCanSaveAndSync,
        disabledText: userCanSave ? _runtime_repl_common_ScratchpadConstants__WEBPACK_IMPORTED_MODULE_13__["DISABLED_IN_SCRATCHPAD_TOOLTIP"] : _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_12__["DISABLED_TOOLTIP_IS_OFFLINE"] }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "dropdown-menu-item-label" }, "模拟请求")), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_7__["MenuItem"], {
        refKey: _runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_11__["ACTION_TYPE_DELETE"],
        disabled: !userCanSave || !canDeleteHistory,
        disabledText: this.getDisabledText(!canDeleteHistory, !userCanSave) }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "dropdown-menu-item-label" }, "删除"), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "dropdown-menu-item-shortcut" }, Object(_postman_app_monolith_renderer_js_controllers_ShortcutsList__WEBPACK_IMPORTED_MODULE_17__["getShortcutByName"])('delete')))));



  }

  render() {
    const permissionStore = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_14__["getStore"])('PermissionStore'),
    canDeleteHistory = permissionStore.can('delete', 'history', this.props.id);

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_containers_apps_requester_sidebar_SidebarListItem__WEBPACK_IMPORTED_MODULE_10__["default"], {
        "data-index": this.props.index,
        text: this.props.url,
        onClick: this.handleSelect,
        isSelected: this.props.selected,
        icon: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_runtime_repl_request_http_RequestIcon__WEBPACK_IMPORTED_MODULE_16__["default"], { method: this.props.method || 'GET' }),
        className: this.getClasses(),
        moreActions: this.getActionsMenuItems(canDeleteHistory),
        rightMetaComponent: this.getRightAlignedComponents,
        leftMetaComponent: this.getLeftAlignedComponents,
        onActionsDropdownSelect: this.handleDropdownActionSelect }));


  }}) || _class;

/***/ }),

/***/ 9722:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HistoryListMetaItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2325);
/* harmony import */ var _runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9714);
/* harmony import */ var _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4181);
/* harmony import */ var _postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1601);
/* harmony import */ var _runtime_repl_history_HistoryActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9716);
/* harmony import */ var _HistoryItemActionsDropdown__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9717);












const ADD_REQUEST_TO_COLLECTION_DISABLED_TOOLTIP = '不适用于集合运行项目';

class HistoryListMetaItem extends react__WEBPACK_IMPORTED_MODULE_0__["PureComponent"] {
  constructor(props) {
    super(props);
    this.state = {
      dropdownOpen: false,
      isHovered: false };


    this.store = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('HistorySidebarStore');

    this.handleToggleGroup = this.handleToggleGroup.bind(this);
    this.handleDropdownToggle = this.handleDropdownToggle.bind(this);
    this.handleDropdownActionSelect = this.handleDropdownActionSelect.bind(this);
    this.handleAddRequestToCollectionClick = this.handleAddRequestToCollectionClick.bind(this);
    this.handleRemoveRequest = this.handleRemoveRequest.bind(this);
    this.handleMouseEnter = this.handleMouseEnter.bind(this);
    this.handleMouseLeave = this.handleMouseLeave.bind(this);
  }

  handleMouseEnter() {
    this.setState({ isHovered: true });
  }

  handleMouseLeave() {
    !this.state.dropdownOpen && this.setState({ isHovered: false });
  }

  getCollapseButtonClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      caret: true,
      'pm-icon': true,
      'pm-icon-normal': true,
      'is-closed': this.store.isItemCollapsed(this.props.name) });

  }

  getMetaClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_1___default()({
      'history-sidebar-list-item-group__meta': true,
      'is-hovered': this.state.dropdownOpen });

  }

  handleToggleGroup() {
    const { name } = this.props;

    if (this.store.isItemCollapsed(name)) {
      return this.store.expandItem(name);
    }

    this.store.collapseItem(name);
  }

  handleDropdownToggle(value) {
    if (value === this.state.dropdownOpen) {
      return;
    }

    this.setState({ dropdownOpen: value });
  }

  handleDropdownActionSelect(action) {
    const modalOptions = {
      requests: _.reduce(this.props.items, (requests, item) => {
        item.type === 'request' && requests.push(item.id);

        return requests;
      }, []),
      runs: _.reduce(this.props.items, (runs, item) => {
        item.type === 'collectionrun' && runs.push(item.id);

        return runs;
      }, []),
      websockethistory: _.reduce(this.props.items, (wsHistory, item) => {
        item.type === 'websockethistory' && wsHistory.push(item.id);

        return wsHistory;
      }, []),
      defaultCollectionName: this.props.name,
      from: 'history_date_group' };


    if (action === _runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_4__["ACTION_TYPE_DELETE"]) {
      pm.mediator.trigger('showDeleteHistoryModal', () => {
        this.props.onSelectAction(action, modalOptions);
      }, {
        identifier: 'selected' });


      return;
    }

    this.props.onSelectAction(action, modalOptions);
  }

  handleAddRequestToCollectionClick(e) {
    e.stopPropagation();
    this.handleDropdownActionSelect(_runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_4__["ACTION_TYPE_SAVE"]);
  }

  handleRemoveRequest(e) {
    e.stopPropagation();
    this.handleDropdownActionSelect(_runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_4__["ACTION_TYPE_DELETE"]);
  }

  render() {
    const hideActions = _.size(this.store.getSelectedItems()) > 1,
    { userCanSave } = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_6__["getStore"])('OnlineStatusStore');

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "history-sidebar-list-item-group",
        onMouseEnter: this.handleMouseEnter,
        onMouseLeave: this.handleMouseLeave }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: this.getMetaClasses(),
        onClick: this.handleToggleGroup }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "history-sidebar-list-item-group__name" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_2__["Icon"], { name: "icon-direction-down", className: this.getCollapseButtonClasses() }), /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, this.props.name)),


      !hideActions && this.state.isHovered && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "history-sidebar-list-item-group__actions" }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_3__["Button"], {
        className: "history-sidebar-list-item__button__add",
        type: "icon",
        disabled: !userCanSave || this.props.disableRequestSpecificActions,
        onClick: this.handleAddRequestToCollectionClick,
        tooltip:
        userCanSave ?
        this.props.disableRequestSpecificActions ?
        ADD_REQUEST_TO_COLLECTION_DISABLED_TOOLTIP :
        _runtime_repl_history_HistoryActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_SAVE_REQUESTS_TOOLTIP"] : _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_5__["DISABLED_TOOLTIP_IS_OFFLINE"] }, /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_2__["Icon"], {
        name: "icon-action-add-stroke",
        className: "history-sidebar-list-item__actions__add pm-icon pm-icon-normal" })), /*#__PURE__*/


      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_3__["Button"], {
        className: "history-sidebar-list-item__button__delete",
        type: "icon",
        onClick: this.handleRemoveRequest,
        disabled: !userCanSave,
        tooltip: userCanSave ? _runtime_repl_history_HistoryActionsTooltipConstants__WEBPACK_IMPORTED_MODULE_7__["ACTION_TYPE_DELETE_REQUESTS_TOOLTIP"] : _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_5__["DISABLED_TOOLTIP_IS_OFFLINE"] }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_2__["Icon"], { name: "icon-action-delete-stroke", className: "history-sidebar-list-item__actions__delete pm-icon pm-icon-normal" })), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_HistoryItemActionsDropdown__WEBPACK_IMPORTED_MODULE_8__["default"], {
        count: _.size(this.props.items),
        onSelect: this.handleDropdownActionSelect,
        onToggle: this.handleDropdownToggle,
        disableRequestSpecificActions: this.props.disableRequestSpecificActions })))));







  }}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ }),

/***/ 9723:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HistoryListErrorItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);


/**
 * Error item for history list
 *
 * @param {Object} props - React props
 */
function HistoryListErrorItem(props) {
  return /*#__PURE__*/(
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "history-sidebar-list-item-group" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "history-sidebar-list-item-group__error" }, "无法加载项.",

    ' ', /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", { onClick: props.onRetry }, "重试"))));



}

/***/ }),

/***/ 9724:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HistoryListCollectionRunItem; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2312);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3737);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2293);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2325);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_Avatar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4190);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_Tooltips__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2326);
/* harmony import */ var _runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9714);
/* harmony import */ var _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4181);
/* harmony import */ var _postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1601);
/* harmony import */ var _postman_app_monolith_renderer_js_containers_apps_requester_sidebar_SidebarListItem__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9023);
var _class;














const ACTION_TYPE_DELETE_RUN_TOOLTIP = '删除集合运行';let


HistoryListCollectionRunItem = Object(mobx_react__WEBPACK_IMPORTED_MODULE_5__["observer"])(_class = class HistoryListCollectionRunItem extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      dropdownOpen: false,
      isTooltipVisible: false };


    this.userAvatar = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createRef();
    this.handleSelect = this.handleSelect.bind(this);
    this.handleDropdownToggle = this.handleDropdownToggle.bind(this);
    this.handleDropdownActionSelect = this.handleDropdownActionSelect.bind(this);
    this.handleRemoveRun = this.handleRemoveRun.bind(this);
    this.showTooltip = this.showTooltip.bind(this);
    this.hideTooltip = this.hideTooltip.bind(this);
    this.getRightAlignedComponents = this.getRightAlignedComponents.bind(this);
    this.getLeftAlignedComponents = this.getLeftAlignedComponents.bind(this);
  }


  componentDidMount() {
    this.selfNode = Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["findDOMNode"])(this);

    // Starts observing element
    this.props.observeSizeChange && this.props.observeSizeChange(this.selfNode);
  }

  componentWillUnmount() {
    this.props.unobserveSizeChange && this.props.unobserveSizeChange(this.selfNode, this.props.index);
  }

  componentWillUpdate(nextProps) {
    if (!this.props.selected && nextProps.selected) {
      const $node = Object(react_dom__WEBPACK_IMPORTED_MODULE_1__["findDOMNode"])(this);

      $node && $node.scrollIntoViewIfNeeded && $node.scrollIntoViewIfNeeded();
    }
  }

  showTooltip() {
    this.setState({ isTooltipVisible: true });
  }

  hideTooltip() {
    this.setState({ isTooltipVisible: false });
  }

  handleSelect(e) {
    e.stopPropagation();
    const modifiers = {
      ctrlKey: e.ctrlKey,
      metaKey: e.metaKey,
      shiftKey: e.shiftKey };


    this.props.onSelect && this.props.onSelect({ id: this.props.id, type: 'collectionrun' }, modifiers);
  }

  getClasses() {
    return classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'history-sidebar-list-item': true,
      'history-sidebar-list-item__collection': true,
      'is-hovered': this.state.dropdownOpen,
      'is-selected': this.props.selected });

  }

  handleDropdownToggle(value) {
    if (value === this.state.dropdownOpen) {
      return;
    }

    this.setState({ dropdownOpen: value });
  }

  handleDropdownActionSelect(action) {
    this.props.onSelectAction(action, {
      runs: [this.props.id] });

  }

  handleRemoveRun(e) {
    e.stopPropagation();
    this.handleDropdownActionSelect(_runtime_repl_history_HistoryActionsConstants__WEBPACK_IMPORTED_MODULE_9__["ACTION_TYPE_DELETE"]);
  }

  getTooltipText(isDisabled) {
    if (!isDisabled) {
      return ACTION_TYPE_DELETE_RUN_TOOLTIP;
    }

    if (!Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_11__["getStore"])('OnlineStatusStore').userCanSave) {
      return _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_10__["DISABLED_TOOLTIP_IS_OFFLINE"];
    }

    return _runtime_repl_common_DisabledTooltipConstants__WEBPACK_IMPORTED_MODULE_10__["DISABLED_TOOLTIP_NO_PERMISSION"];
  }

  getLeftAlignedComponents(isHovered, isMoreActionsDropdownOpen) {
    const classNames = classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'history-sidebar-list-item-updatedBy': true,
      hovered: isHovered });


    if (!isHovered && !isMoreActionsDropdownOpen) {
      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "history-sidebar__indent" }));

    }

    const owner = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_11__["getStore"])('CurrentUserStore').teamMembers.get(this.props.owner),
    ownerName = owner && (owner.name || owner.username);

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: classNames,
        onMouseEnter: this.showTooltip,
        onMouseLeave: this.hideTooltip },


      !this.props.owner || this.props.owner === '0' ? /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_3__["Icon"], { name: "icon-descriptive-user-stroke", className: "pm-icon pm-icon-normal" }) : /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Avatar__WEBPACK_IMPORTED_MODULE_7__["default"], {
        ref: this.userAvatar,
        size: "small",
        userId: this.props.owner }),




      this.userAvatar.current && /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Tooltips__WEBPACK_IMPORTED_MODULE_8__["Tooltip"], {
        immediate: true,
        show: this.state.isTooltipVisible,
        target: this.userAvatar.current,
        placement: "right" }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Tooltips__WEBPACK_IMPORTED_MODULE_8__["TooltipBody"], null, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null,
      ownerName), /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null,
      moment__WEBPACK_IMPORTED_MODULE_4___default()(this.props.createdAt).format('DD MMM YYYY, h:mm A')))))));








  }

  getRightAlignedComponents(isHovered, isMoreActionsDropdownOpen) {
    const classNames = classnames__WEBPACK_IMPORTED_MODULE_2___default()({
      'sidebar-list-item__right-section-actions': true,
      hovered: isHovered });


    if (!isHovered && !isMoreActionsDropdownOpen) return null;

    const permissionStore = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_11__["getStore"])('PermissionStore'),
    { userCanSave } = Object(_postman_app_monolith_renderer_js_stores_get_store__WEBPACK_IMPORTED_MODULE_11__["getStore"])('OnlineStatusStore'),
    canDeleteCollectionRun = userCanSave && permissionStore.can('delete', 'collectionrun', this.props.id);

    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: classNames }, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_6__["Button"], {
        className: "history-sidebar-list-item__button__delete",
        type: "icon",
        onClick: this.handleRemoveRun,
        disabled: !canDeleteCollectionRun,
        tooltip: this.getTooltipText(!canDeleteCollectionRun) }, /*#__PURE__*/

      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_3__["Icon"], {
        name: "icon-action-delete-stroke",
        className: "history-sidebar-list-item__actions__delete pm-icon pm-icon-normal" }))));




  }

  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_containers_apps_requester_sidebar_SidebarListItem__WEBPACK_IMPORTED_MODULE_12__["default"], {
        "data-index": this.props.index,
        text: this.props.name,
        icon: "icon-action-run-stroke",
        isSelected: this.props.selected,
        onClick: this.handleSelect,
        className: this.getClasses(),
        rightMetaComponent: this.getRightAlignedComponents,
        leftMetaComponent: this.getLeftAlignedComponents }));



  }}) || _class;

/***/ }),

/***/ 9725:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HistorySidebarErrorState; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _postman_app_monolith_renderer_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2325);



/**
 * Error state when loading history from server fails
 *
 * @param {Object} props - React props
 */
function HistorySidebarErrorState(props) {
  return /*#__PURE__*/(
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "history-sidebar-list-error" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h4", null, "无法加载历史"), /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", null, "尝试加载历史项目时出了点问题. 检查您的互联网,然后重试."), /*#__PURE__*/



    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_app_monolith_renderer_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_1__["Button"], {
      type: "secondary",
      onClick: props.onRetry }, "重试")));





}

/***/ })

}]);