(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[76],{

/***/ 17877:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return RelatedCollectionsCBController; });
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1595);
/* harmony import */ var _js_modules_services_RequestWithFileBodyService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2891);
/* harmony import */ var _runtime_repl_request_http_PrepareRequestService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2866);
/* harmony import */ var _runtime_repl_request_http_ResolveRequest__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2889);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1601);






class RelatedCollectionsCBController {
  /**
   * Returns resolved request with environment variables
   *
   * @param {*} editorId - Active editor id
   * @returns {String}
   */
  getResolvedRequest(editorId) {
    let request, editor;

    return Promise.resolve().
    then(() => {
      if (!editorId) {
        return Promise.reject(new Error('RelatedCollectionsCBController~getResolvedRequest: Incorrect Parameters.'));
      }

      editor = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_4__["getStore"])('EditorStore').find(editorId);

      if (!editor) {
        return Promise.reject(new Error('RelatedCollectionsCBController~getResolvedRequest: Editor not found.'));
      }

      request = editor.model && Object(_js_modules_services_RequestWithFileBodyService__WEBPACK_IMPORTED_MODULE_1__["getRequestWithFileBody"])(editor.model);
      if (!request) {
        return Promise.reject(new Error('RelatedCollectionsCBController~getResolvedRequest: Request not found.'));
      }

      // This is in case the editor is an example.
      // if (type === 'example' && request.requestObject) {
      //   return request.requestObject;
      // }

      return request;
    })

    // Get the complete request from db
    .then((request) => {
      return _runtime_repl_request_http_PrepareRequestService__WEBPACK_IMPORTED_MODULE_2__["default"].getPopulatedRequest(request);
    })


    // resolve the variables for the current request
    .then((preparedRequest) => {
      return _runtime_repl_request_http_ResolveRequest__WEBPACK_IMPORTED_MODULE_3__["default"].resolve(preparedRequest);
    }).

    then((resolvedRequest) => {
      if (!resolvedRequest) {
        return Promise.reject('RelatedCollectionsCBController~getResolvedRequest: Error in resolving request.');
      }

      return resolvedRequest.url.toString();
    });
  }}

/***/ })

}]);