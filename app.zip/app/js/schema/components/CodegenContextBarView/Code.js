(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[59],{

/***/ 14706:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Code; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2293);
/* harmony import */ var _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1812);
/* harmony import */ var _integrations_services_CodegenService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(14707);
/* harmony import */ var _js_services_NavigationService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1801);
/* harmony import */ var _services_SchemaService__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2258);
/* harmony import */ var _js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2325);
/* harmony import */ var _appsdk_components_link_Link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2687);
/* harmony import */ var _postman_aether__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9);
/* harmony import */ var _js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2845);
/* harmony import */ var _js_models_services_filesystem__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2000);
/* harmony import */ var _constants_SchemaEditorConstants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7472);
/* harmony import */ var _appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2862);
/* harmony import */ var _js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2322);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(515);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1601);
var _class;


// services





// components












const DOCS_URL = 'https://go.pstmn.io/docs-server-boilerplate-api',
DOCS_URL_CONTRACT_ONLY = 'https://go.pstmn.io/docs-server-boilerplate-api-contract-only';let


Code = Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(_class = class Code extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(props) {
    super(props);this.




















































































































































    handleToggleContract = (state) => {
      const { languageSelection } = this.state;

      let language = languageSelection.length ? languageSelection.split('-')[0] : '',
      variant = languageSelection.length ? languageSelection.split('-').slice(1).join('-') : '',
      origin = lodash__WEBPACK_IMPORTED_MODULE_14___default.a.get(this.props, 'contextData.editor') ? 'editor' : 'release';

      this.setState({
        contractOnly: state },
      () => {
        if (this.state.contractOnly) {
          _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_2__["default"].addEventV2({
            category: 'server_code',
            action: 'options',
            label: `${origin}_${language}_${variant}_contract_only`,
            value: 1 });

        }
      });
    };this.






    triggerGenerateCode = async () => {
      const { languageSelection, contractOnly, isRelease } = this.state,
      { apiName, schemaId, tagId } = this.getSchemaProperties(this.props.contextData);

      let language = languageSelection.split('-')[0],
      variant = languageSelection.split('-').slice(1).join('-'),
      origin = lodash__WEBPACK_IMPORTED_MODULE_14___default.a.get(this.props, 'contextData.editor') ? 'editor' : 'release',
      isLoggedIn = Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_15__["getStore"])('CurrentUserStore').isLoggedIn;

      _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_2__["default"].addEventV2({
        category: 'server_code',
        action: 'generate',
        label: `${origin}_${language}_${variant}`,
        value: 1 });


      // Show show Sign In Modal if user is not signed in
      if (!isLoggedIn) {
        return pm.mediator.trigger('showSignInModal', {
          type: 'generateServerCode',
          origin: 'server_code_generate_code_button',
          continueUrl: new URL(window.location.href) });

      }

      // hide download button
      this.setState({ zipUrl: null, filename: null, generating: true });

      try {
        const { url, filename } = await _integrations_services_CodegenService__WEBPACK_IMPORTED_MODULE_3__["default"].generate(apiName, schemaId, language, variant, contractOnly, tagId);

        this.downloadGeneratedCode(url, filename);
      } catch (error) {
        let errMsg = '无法生成服务器样板. 稍后再试.';

        if (error.code && error.code === 'parseError') {
          errMsg = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, "无法解析 OpenAPI 规范. 查看错误和警告在你的",
          isRelease ? '架构定义.' : /*#__PURE__*/
          react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", { className: "codegen__error-link", onClick: this.navigateToDefineTab }, "架构定义."));

        }
        this.setState({
          zipUrl: null, filename: null, generating: false, showError: true,
          errMsg });

        pm.logger.error(`Codegen~triggerGenerateCode - Error while waiting on response from generating code for ${apiName} - ${schemaId}: `, error);
      }

    };this.









    downloadGeneratedCode = (url, name) => {
      if (url) {
        fetch(url).
        then((response) => {
          response.arrayBuffer().then((data) => {
            Object(_js_models_services_filesystem__WEBPACK_IMPORTED_MODULE_10__["saveAndOpenFile"])(name, new Uint8Array(data), 'application/zip', (err, state) => {
              if (err) {
                pm.logger.error('Codegen~downloadGeneratedCode - Failed to download generated code.', err);
                pm.toasts.error('无法下载生成的代码');
                this.setState({
                  generating: false });

              } else {
                this.setState({ generating: false, showError: false });
                if (state === _js_models_services_filesystem__WEBPACK_IMPORTED_MODULE_10__["STATE"].SUCCESS && window.SDK_PLATFORM !== 'browser') {
                  pm.toasts.success('服务器样板已成功下载', { 'title': '代码已生成' });
                }
              }
            });
          });
        }).
        catch((err) => {
          pm.logger.error('Codegen~downloadGeneratedCode - Failed to download generated code.', err);
          pm.toasts.error('无法下载生成的代码');
          this.setState({
            generating: false });

        });
      } else
      {
        this.setState({
          generating: false, showError: true,
          errMsg: '出了些问题. 请再试一次.' });

        pm.logger.error('Codegen~downloadGeneratedCode - Invalid url given for download', url);
      }
    };this.











































    renderLanguageMenuItems = (isAPISupported) => {
      let { templates, languageSelection } = this.state,
      selected = 'Select',
      templateList = [];

      if (lodash__WEBPACK_IMPORTED_MODULE_14___default.a.isArray(templates)) {
        for (let template of templates) {
          if (!lodash__WEBPACK_IMPORTED_MODULE_14___default.a.isArray(template.variants)) {
            continue;
          }

          for (let variant of template.variants) {
            let id = template.key + '-' + variant.key;

            if (id === languageSelection) {
              selected = template.label + ' - ' + variant.label;
            }

            templateList.push( /*#__PURE__*/
            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_9__["MenuItem"], {
              key: id,
              refKey: id }, /*#__PURE__*/

            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "codegen__dropdown-menu-item-label" }, template.label, " - ", variant.label)));


          }
        }
      }

      return /*#__PURE__*/(
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_9__["Dropdown"], {
          className: "codegen__modal-dropdown",
          onSelect: this.handleDropdownActionSelect,
          keyMapHandlers: { 'quit': this.handleEscape } }, /*#__PURE__*/

        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_9__["DropdownButton"], { type: "secondary", size: "small" }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_6__["Button"], { disabled: !isAPISupported || templateList.length === 0 }, /*#__PURE__*/
        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "codegen__selected-label" }, selected))), /*#__PURE__*/


        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Dropdowns__WEBPACK_IMPORTED_MODULE_9__["DropdownMenu"], { "align-right": true, className: "codegen__dropdown-menu" },
        templateList)));



    };this.state = { showError: false, zipUrl: '', filename: '', errMsg: '', fetchingTemplates: true, templates: null, apiType: null, isRelease: false, contractOnly: false, languageSelection: 0, // default to first template in list
      generating: false, generateDisabled: true // true if Generate Code button is disabled, false if enabled
    };this.triggerGenerateCode = this.triggerGenerateCode.bind(this);this.downloadGeneratedCode = this.downloadGeneratedCode.bind(this);this.renderCodeSection = this.renderCodeSection.bind(this);this.handleDropdownActionSelect = this.handleDropdownActionSelect.bind(this);this.handleEscape = this.handleEscape.bind(this);this.handleToggleContract = this.handleToggleContract.bind(this);this.navigateToDefineTab = this.navigateToDefineTab.bind(this);}componentDidMount() {// This async block will make a GET request to the codegen service /templates endpoint to get the list
    // of template languages.
    (async () => {try {const templates = await _integrations_services_CodegenService__WEBPACK_IMPORTED_MODULE_3__["default"].getTemplates();this.setState({ templates: templates, fetchingTemplates: false });} catch (error) {this.setState({ templates: null, showError: true, fetchingTemplates: false, errMsg: '无法获取可用语言和框架的列表.' });pm.logger.error('Codegen~templates - Error while waiting on response from getting templates: ', error);}})(); // Fetch schema type if we are on a release page
    if (!lodash__WEBPACK_IMPORTED_MODULE_14___default.a.get(this.props, 'contextData.editor')) {this.setState({ isRelease: true });this.fetchSchemaType();} else {const apiType = this.getApiType(); // 'open' event only for editor view
      _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_2__["default"].addEventV2({ category: 'server_code', action: 'open', label: 'editor_' + apiType, value: 1 });}} /**
   * This function returns the apiId, versionId, schemaId and tagId depending on
   * whether we are on release page or api version page
   * @param {Object} context
   * @returns
   */getSchemaProperties(context) {if (lodash__WEBPACK_IMPORTED_MODULE_14___default.a.get(context.model, 'activeRelease')) {return { apiId: lodash__WEBPACK_IMPORTED_MODULE_14___default.a.get(context.model, 'api.id'), apiName: lodash__WEBPACK_IMPORTED_MODULE_14___default.a.get(context.model, 'api.name'), versionId: lodash__WEBPACK_IMPORTED_MODULE_14___default.a.get(context.model, 'apiVersion.id'), schemaId: lodash__WEBPACK_IMPORTED_MODULE_14___default.a.get(context.model, 'activeRelease.entities.schemas.0.entityId'), tagId: lodash__WEBPACK_IMPORTED_MODULE_14___default.a.get(context.model, 'activeRelease.entities.schemas.0.tag') };} else {return { apiId: lodash__WEBPACK_IMPORTED_MODULE_14___default.a.get(context, 'model.apiId'), apiName: lodash__WEBPACK_IMPORTED_MODULE_14___default.a.get(context, 'model.apiName'), versionId: lodash__WEBPACK_IMPORTED_MODULE_14___default.a.get(context, 'model.id'), schemaId: lodash__WEBPACK_IMPORTED_MODULE_14___default.a.get(context, 'model.schema.schemaId'), tagId: null };}} /**
   * Fetch schema type on Release page as it is not present in the contextData
   *
   * TODO: get schema type from contextData instead of making a network call
   */async fetchSchemaType() {const { apiId, versionId, schemaId, tagId } = this.getSchemaProperties(this.props.contextData);try {const response = await _services_SchemaService__WEBPACK_IMPORTED_MODULE_5__["default"].getReleaseSchema(apiId, versionId, schemaId, tagId, true);this.setState({ apiType: lodash__WEBPACK_IMPORTED_MODULE_14___default.a.get(response, 'type', null) }); // 'open' event for release view, here because we need the apiType
      _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_2__["default"].addEventV2({ category: 'server_code', action: 'open', label: 'release_' + lodash__WEBPACK_IMPORTED_MODULE_14___default.a.get(response, 'type', null), value: 1 });} catch (error) {pm.logger.error('Codegen~fetchSchemaType - Error while fetching schema type for Release: ', error);this.setState({ apiType: 'Unknown' });}} /**
   * Get the API type. In API Builder it is supplied in the `contextData`, while
   * on an API release page, we fetch it manually and store it in this.state
   * @returns {String}
   */getApiType() {if (lodash__WEBPACK_IMPORTED_MODULE_14___default.a.get(this.props, 'contextData.editor')) {return lodash__WEBPACK_IMPORTED_MODULE_14___default.a.get(this.props, 'contextData.editor.activeType');} else {return this.state.apiType;}}navigateToDefineTab() {const queryParams = { tab: 'define' },{ apiId, versionId } = this.getSchemaProperties(this.props.contextData); // Triggering navigation which will set the active tab to Define
    _js_services_NavigationService__WEBPACK_IMPORTED_MODULE_4__["default"].transitionTo('build.apiVersion', { apiId, versionId }, queryParams, { replace: true });}handleDropdownActionSelect(action) {this.setState({ languageSelection: action, generateDisabled: false, showError: false });}handleEscape() {this.props.onEscape && this.props.onEscape();} /**
   * This function will render the language template selection drop down. The response from the /templates returns JSON
   * like so:
     "templates": [
   {
      "key": "go",
      "label": "Go",
      "variants": [
        {
          "key": "chi-server",
          "label": "Chi server",
          "options": [
          {
            "name": "Docker",
            "id": "docker",
            "type": "boolean",
            "default": false,
            "description": "确定是否应生成 docker 容器",
            "extra": "docker"
          }
        }
      ]
    }]
     * The response is an array of 0 or more registered template generators. Each has the language it generates code in
   * as well as a list of variants, which are the frameworks the generated output may adhere to.
   *
   * @returns {JSX.Element}
   */renderCodeSection() {const { generating, generateDisabled, contractOnly, isRelease, fetchingTemplates } = this.state,apiType = this.getApiType();if (!apiType || fetchingTemplates) {return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "codegen__loader" }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_LoadingIndicator__WEBPACK_IMPORTED_MODULE_13__["default"], null));}const isAPISupported = apiType === 'openapi3',generateButtonText = generating ? '生成中...' : '生成代码',isSchemaValid = isRelease ? true : lodash__WEBPACK_IMPORTED_MODULE_14___default.a.get(this.props, 'contextData.schemaValid'),isSchemaSaved = isRelease ? true : !lodash__WEBPACK_IMPORTED_MODULE_14___default.a.get(this.props, 'contextData.editor.isDirty'),isSchemaCreated = isRelease ? true : !!lodash__WEBPACK_IMPORTED_MODULE_14___default.a.get(this.props, 'contextData.editor.schema'),canGenerateCode = lodash__WEBPACK_IMPORTED_MODULE_14___default.a.get(this.props, 'contextData.model.apiPermissionStore').canGenerateCode,tooltipMessage = !canGenerateCode ? '您没有执行此操作的权限' : !isSchemaCreated ? '添加架构以从中生成代码' : !isSchemaSaved ? '在生成代码之前保存您的更改.' : !isSchemaValid ? '添加有效架构以从中生成代码' : '';return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "codegen__container" }, !isAPISupported && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "codegen__banner" }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_8__["Banner"], null, "服务器样板生成仅支持 OpenAPI 3.0 格式.", apiType ? `此 API 使用 ${_constants_SchemaEditorConstants__WEBPACK_IMPORTED_MODULE_11__["SCHEMA_FORMAT_MAP"][apiType]}.` : '')), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: !isAPISupported ? 'codegen__disabled' : '' }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "codegen__description" }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, "从您的 API 架构生成服务器样板. "), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_components_link_Link__WEBPACK_IMPORTED_MODULE_7__["default"], { to: DOCS_URL, target: "_blank", onClick: () => {_js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_2__["default"].addEventV2({ category: 'server_code', action: 'learn_more', label: 'docs', value: 1 });} }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", { className: "codegen__learn-more-link" }, "了解更多"))), /*#__PURE__*/



    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "codegen__generate-text" }, "语言和框架"), /*#__PURE__*/

    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, this.renderLanguageMenuItems(isAPISupported)), /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "codegen__options-container" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_8__["Checkbox"], { isChecked: contractOnly, onChange: this.handleToggleContract, isDisabled: !isAPISupported }), /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", { className: "codegen__options-text" }, "只生成路由和接口. "), /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_components_link_Link__WEBPACK_IMPORTED_MODULE_7__["default"], {
      to: DOCS_URL_CONTRACT_ONLY,
      target: "_blank",
      onClick: () => {
        _js_modules_services_AnalyticsService__WEBPACK_IMPORTED_MODULE_2__["default"].addEventV2({
          category: 'server_code',
          action: 'learn_more',
          label: 'docs_contract_only',
          value: 1 });

      } }, /*#__PURE__*/

    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", { className: "codegen__learn-more-link" }, "了解更多"))), /*#__PURE__*/


    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "codegen__button-container" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_js_components_base_Buttons__WEBPACK_IMPORTED_MODULE_6__["Button"], { className: "codegen__generate-button",
      disabled: generating || generateDisabled || !isAPISupported || !isSchemaSaved || !isSchemaValid || !isSchemaCreated || !canGenerateCode,
      type: "secondary",
      tooltip: tooltipMessage,
      onClick: this.triggerGenerateCode }, " ",
    generateButtonText, " ")),

    this.state.showError && /*#__PURE__*/

    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { className: "codegen__banner" }, /*#__PURE__*/
    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_8__["Banner"], { status: "error", onDismiss: () => this.setState({ showError: false }) },
    this.state.errMsg))));






  }

  render() {
    return /*#__PURE__*/(
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, /*#__PURE__*/
      react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_appsdk_contextbar_ContextBarViewHeader__WEBPACK_IMPORTED_MODULE_12__["ContextBarViewHeader"], {
        title: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, "代码生成", /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_postman_aether__WEBPACK_IMPORTED_MODULE_8__["Badge"], { status: "info", text: "测试" })),
        onClose: this.props.onClose }),

      this.renderCodeSection()));


  }}) || _class;

/***/ }),

/***/ 14707:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var _js_modules_services_RemoteSyncRequestService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1798);
/* harmony import */ var _js_stores_get_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1601);



const SYNC_STATUS_TIMEOUT = 8 * 1000;

async function call(path, method, payload) {
  return _js_modules_services_RemoteSyncRequestService__WEBPACK_IMPORTED_MODULE_0__["default"].request('/ws/proxy', {
    method: 'post',
    data: {
      service: 'codegen',
      method: method,
      body: payload,
      path: path } });


}

/**
 * Calls the '/templates' endpoint of Codegen service
 *
 * @async
 * @returns {Object[]}
 * The format of the response is:
 * "templates": [
 * {
 *    "key": "go",
 *    "label": "Go",
 *    "variants": [
 *      {
 *        "key": "chi-server",
 *        "label": "Chi server",
 *        "options": [
 *        {
 *          "name": "Docker",
 *          "id": "docker",
 *          "type": "boolean",
 *          "default": false,
 *          "description": "确定是否应生成 docker 容器",
 *          "extra": "docker"
 *        }
 *      }
 *    ]
 *  }]
 */
async function getTemplates() {
  await Object(_js_stores_get_store__WEBPACK_IMPORTED_MODULE_1__["getStore"])('SyncStatusStore').onSyncAvailable({ timeout: SYNC_STATUS_TIMEOUT });
  const response = await call('/artifacts/server-code/options', 'get');
  return _.get(response, 'body.templates');
}

/**
 * Calls the '/artifacts/server-code' endpoint of Codegen service
 *
 * @async
 * @param {String} apiName - Name of the API
 * @param {String} apiId - Id of the API
 * @param {String} versionId - Id of the version
 * @param {String} schemaId - Id of the Schema
 * @param {String} language - Key of the language
 * @param {String} variant - Key of the variant
 * @param {String} contractOnly - Whether to generate only the contracts
 * @param {String} tagId - TagId of the Schema
 *
 * @returns {Object}
 * {
 *  url: URL of the generated zip file
 *  filename: Name of the generated zip file
 * }
 *
 * The structure of the request to be sent is as follows:
 {
    "apiName": "API"
    "tagId": "300",
    "schemaId": "200",
    "language": "go",
    "variant": "chi-server",
    "options": [{
        "id": "contract",
        "value": false
      }
    ]
}
 */
async function generate(apiName, schemaId, language, variant, contractOnly, tagId = '') {
  const payload = {
    apiName: apiName,
    tagId: tagId,
    schemaId: schemaId,
    language: language,
    variant: variant,
    options: [
    {
      id: 'contract',
      value: contractOnly }] };



  try {
    const response = await call('/artifacts/server-code', 'post', payload);
    const url = _.get(response, 'body.data.downloadLink');
    const filename = _.get(response, 'body.data.filename');

    return { url, filename };
  } catch (error) {
    if (error.error) {
      throw error.error;
    }
    throw error;
  }
}

/* harmony default export */ __webpack_exports__["default"] = ({
  getTemplates,
  generate });
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(515)))

/***/ })

}]);